////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.utils;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.ACCOUNT;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.ACCOUNT_BALANCE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.ACCOUNT_DETAIL;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.ACCOUNT_NO;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.ACCOUNT_NUMBER;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.ANNUAL_PREMIUM;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.BENEFIT_PERIOD;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.CLIENT;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.CLIENT_ACCOUNT_RELATIONSHIP;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.CLIENT_ACCOUNT_RELATIONSHIPS;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.CODE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.CODE_SHORT_DESCRIPTION;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.COMMENCEMENT_DATE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.ERROR_MESSAGE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.EXTERNAL_REFERENCES;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.GET_ACCOUNT_DETAILS_RESPONSE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.INSTALMENT_PREMIUM;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.INSURANCES;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LAST_RENEWAL_DATE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.NAME;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.PRODUCT;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.REFERENCE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.REFERENCE_CODE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.RELATIONSHIP_TYPE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.RIDER_TEMPLATE_DETAILS;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.RIDER_TYPE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.RISK_TERM_AGE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.STATUS;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.STATUS_CODE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.SUM_INSURED;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.WAIT_PERIOD;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

import au.com.suncorp.wealth.api.accounts.model.account.details.AccountDetailBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.AccountDetails;
import au.com.suncorp.wealth.api.accounts.model.account.details.AccountDetailsList;
import au.com.suncorp.wealth.api.accounts.model.account.details.AccountNumberInfo;
import au.com.suncorp.wealth.api.accounts.model.account.details.ClientAccountRelationshipBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.ClientAccountRelationshipIdentifierBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.ClientBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.CodeIdentifier;
import au.com.suncorp.wealth.api.accounts.model.account.details.ExternalReference;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetAccountDetailsResponse;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetAccountListDetailsResponseWrapperBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.ProductDetails;
import au.com.suncorp.wealth.api.accounts.model.account.details.RelationshipIdentifierBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.RiderDetails;
import au.com.suncorp.wealth.api.accounts.model.account.details.RiderTemplateDetails;

/**
 * The class {@code GetAccountDetailsResponseUtil} does this.
 *
 * @author U383754
 * @since 25Apr.,2018
 * @version 1.0
 */
public class GetAccountDetailsResponseUtil {

    public GetAccountListDetailsResponseWrapperBean parse(JsonNode jNode) {
        GetAccountListDetailsResponseWrapperBean wrapperBean = new GetAccountListDetailsResponseWrapperBean();
        GetAccountDetailsResponse accountDetailsResponse = parseJson(jNode);
        wrapperBean.setGetAccountDetailsResponse(accountDetailsResponse);
        return wrapperBean;
    }

    private GetAccountDetailsResponse parseJson(JsonNode jNode) {
        GetAccountDetailsResponse accountDetailsResponse = new GetAccountDetailsResponse();
        if (jNode.hasNonNull(GET_ACCOUNT_DETAILS_RESPONSE)) {
            JsonNode responseFields = jNode.get(GET_ACCOUNT_DETAILS_RESPONSE);
            if (responseFields.hasNonNull(ERROR_MESSAGE)) {
                accountDetailsResponse.setErrorMessage(responseFields.get(ERROR_MESSAGE).asText());
            } else {
                prepareResponse(accountDetailsResponse, responseFields);
            }
        }
        return accountDetailsResponse;
    }

    /**
     * Does this.
     *
     * @param accountDetailsResponse
     * @param responseFields
     */
    private void prepareResponse(GetAccountDetailsResponse accountDetailsResponse, JsonNode responseFields) {
        Iterator<String> fieldNames = responseFields.fieldNames();
        while (fieldNames.hasNext()) {
            String fieldName = fieldNames.next();
            JsonNode fieldValue = responseFields.get(fieldName);
            if (fieldValue.isArray()) {
                setAccountDetails(accountDetailsResponse, fieldValue);
            }
        }
    }

    /**
     * Does this.
     *
     * @param accountDetailsResponse
     * @param fieldValue
     */
    private void setAccountDetails(GetAccountDetailsResponse accountDetailsResponse, JsonNode fieldValue) {
        List<AccountDetailsList> accountDetailsList = new ArrayList<AccountDetailsList>();
        for (final JsonNode objNode : fieldValue) {
            setAccountFields(accountDetailsList, objNode);
        }
        accountDetailsResponse.setAccountDetailsList(accountDetailsList);
    }

    /**
     * Does this.
     *
     * @param accountDetailsList
     * @param objNode
     */
    private void setAccountFields(List<AccountDetailsList> accountDetailsList, final JsonNode objNode) {
        AccountDetailsList obj = new AccountDetailsList();
        if (objNode.hasNonNull(ACCOUNT)) {
            obj.setAccount(retrieveAccount(objNode.get(ACCOUNT)));
        }
        if (objNode.hasNonNull(ACCOUNT_DETAIL)) {
            obj.setAccountDetail(retrieveAccountDetail(objNode.get(ACCOUNT_DETAIL)));
        }
        if (objNode.hasNonNull(EXTERNAL_REFERENCES)) {
            obj.setExternalReferences(retreieveExternalReferences(objNode.get(EXTERNAL_REFERENCES)));
        }
        setAccounts(objNode, obj);
        accountDetailsList.add(obj);
    }

    /**
     * Does this.
     *
     * @param objNode
     * @param obj
     */
    private void setAccounts(final JsonNode objNode, AccountDetailsList obj) {
        if (objNode.hasNonNull(ACCOUNT_BALANCE)) {
            obj.setAccountBalance(objNode.get(ACCOUNT_BALANCE).asText());
        }
        if (objNode.hasNonNull(INSURANCES)) {
            obj.setInsurances(retrieveInsurances(objNode.get(INSURANCES)));
        }
        if (objNode.hasNonNull(PRODUCT)) {
            obj.setProduct(retrieveProduct(objNode.get(PRODUCT)));
        }
        if (objNode.hasNonNull(CLIENT_ACCOUNT_RELATIONSHIPS)) {
            obj.setClientAccountRelationships(retrieveClientAccountRelation(objNode.get(CLIENT_ACCOUNT_RELATIONSHIPS)));
        }
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private List<ClientAccountRelationshipBean> retrieveClientAccountRelation(final JsonNode jsonNode) {
        List<ClientAccountRelationshipBean> clientRelationList = new ArrayList<ClientAccountRelationshipBean>();
        for (final JsonNode obj : jsonNode) {
            ClientAccountRelationshipBean clientRel = new ClientAccountRelationshipBean();
            if (obj.hasNonNull(CLIENT_ACCOUNT_RELATIONSHIP)) {
                clientRel.setClientAccountRelationship(retrieveClientAccountRelationship(obj.get(CLIENT_ACCOUNT_RELATIONSHIP)));
            }
            clientRelationList.add(clientRel);
        }
        return clientRelationList;
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private ClientAccountRelationshipIdentifierBean retrieveClientAccountRelationship(final JsonNode jsonNode) {
        ClientAccountRelationshipIdentifierBean clientAcc = new ClientAccountRelationshipIdentifierBean();
        if (jsonNode.hasNonNull(CLIENT)) {
            clientAcc.setClient(retrieveClient(jsonNode.get(CLIENT)));
        }
        if (jsonNode.hasNonNull(RELATIONSHIP_TYPE)) {
            clientAcc.setRelationshipType(retrieveRelationshipType(jsonNode.get(RELATIONSHIP_TYPE)));
        }
        return clientAcc;
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private ClientBean retrieveClient(final JsonNode jsonNode) {
        ClientBean client = new ClientBean();
        if (jsonNode.hasNonNull(ID)) {
            client.setId(jsonNode.get(ID).asText());
        }
        return client;
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private RelationshipIdentifierBean retrieveRelationshipType(final JsonNode jsonNode) {
        RelationshipIdentifierBean relation = new RelationshipIdentifierBean();
        if (jsonNode.hasNonNull(NAME)) {
            relation.setName(jsonNode.get(NAME).asText());
        }
        if (jsonNode.hasNonNull(CODE)) {
            relation.setCode(jsonNode.get(CODE).asText());
        }
        return relation;
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private ProductDetails retrieveProduct(final JsonNode jsonNode) {
        ProductDetails prod = new ProductDetails();
        if (jsonNode.hasNonNull(ID)) {
            prod.setId(jsonNode.get(ID).asText());
        }
        return prod;
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private List<RiderDetails> retrieveInsurances(final JsonNode jsonNode) {
        List<RiderDetails> insuranceList = new ArrayList<RiderDetails>();
        for (final JsonNode obj : jsonNode) {
            RiderDetails insurance = new RiderDetails();
            if (obj.hasNonNull(ID)) {
                insurance.setId(obj.get(ID).asText());
            }
            if (obj.hasNonNull(LAST_RENEWAL_DATE)) {
                insurance.setLastRenewalDate(obj.get(LAST_RENEWAL_DATE).asText());
            }
            setInsurances(obj, insurance);
            insuranceList.add(insurance);
        }
        return insuranceList;
    }

    /**
     * Does this.
     *
     * @param obj
     * @param insurance
     */
    private void setInsurances(final JsonNode obj, RiderDetails insurance) {
        if (obj.hasNonNull(BENEFIT_PERIOD)) {
            insurance.setBenefitPeriod(obj.get(BENEFIT_PERIOD).asText());
        }
        if (obj.hasNonNull(WAIT_PERIOD)) {
            insurance.setWaitPeriod(obj.get(WAIT_PERIOD).asText());
        }
        if (obj.hasNonNull(ANNUAL_PREMIUM)) {
            insurance.setAnnualPremium(obj.get(ANNUAL_PREMIUM).asText());
        }
        if (obj.hasNonNull(INSTALMENT_PREMIUM)) {
            insurance.setInstalmentPremium(obj.get(INSTALMENT_PREMIUM).asText());
        }
        setOtherInsurances(obj, insurance);
    }

    /**
     * Does this.
     *
     * @param obj
     * @param insurance
     */
    private void setOtherInsurances(final JsonNode obj, RiderDetails insurance) {
        if (obj.hasNonNull(SUM_INSURED)) {
            insurance.setSumInsured(obj.get(SUM_INSURED).asText());
        }
        if (obj.hasNonNull(RISK_TERM_AGE)) {
            insurance.setRiskTermAge(obj.get(RISK_TERM_AGE).asText());
        }
        if (obj.hasNonNull(RIDER_TEMPLATE_DETAILS)) {
            insurance.setRiderTemplateDetails(retrieveRiderTemp(obj.get(RIDER_TEMPLATE_DETAILS)));
        }
        if (obj.hasNonNull(STATUS)) {
            insurance.setStatus(retrieveStatusCode(obj.get(STATUS)));
        }
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private RiderTemplateDetails retrieveRiderTemp(final JsonNode jsonNode) {
        RiderTemplateDetails riderTemp = new RiderTemplateDetails();
        if (jsonNode.hasNonNull(RIDER_TYPE)) {
            riderTemp.setRiderType(retrieveStatusCode(jsonNode.get(RIDER_TYPE)));
        }
        return riderTemp;
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private List<ExternalReference> retreieveExternalReferences(final JsonNode jsonNode) {
        List<ExternalReference> extRefList = new ArrayList<ExternalReference>();
        for (final JsonNode obj : jsonNode) {
            ExternalReference extRef = new ExternalReference();
            if (obj.hasNonNull(REFERENCE)) {
                extRef.setReference(obj.get(REFERENCE).asText());
            }
            if (obj.hasNonNull(REFERENCE_CODE)) {
                extRef.setReferenceCode(obj.get(REFERENCE_CODE).asText());
            }
            extRefList.add(extRef);
        }
        return extRefList;
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private AccountDetailBean retrieveAccountDetail(final JsonNode jsonNode) {
        AccountDetailBean accountDet = new AccountDetailBean();
        if (jsonNode.hasNonNull(COMMENCEMENT_DATE)) {
            accountDet.setCommencementDate(jsonNode.get(COMMENCEMENT_DATE).asText());
        }
        return accountDet;
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private AccountDetails retrieveAccount(final JsonNode jsonNode) {
        AccountDetails account = new AccountDetails();
        if (jsonNode.hasNonNull(ACCOUNT_NUMBER)) {
            account.setAccountNumber(retrieveAccountNumber(jsonNode.get(ACCOUNT_NUMBER)));
        }
        if (jsonNode.hasNonNull(STATUS_CODE)) {
            account.setStatusCode(retrieveStatusCode(jsonNode.get(STATUS_CODE)));
        }
        return account;
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private CodeIdentifier retrieveStatusCode(final JsonNode jsonNode) {
        CodeIdentifier code = new CodeIdentifier();
        if (jsonNode.hasNonNull(CODE_SHORT_DESCRIPTION)) {
            code.setCodeShortDescription(jsonNode.get(CODE_SHORT_DESCRIPTION).asText());
        }
        if (jsonNode.hasNonNull(CODE)) {
            code.setCode(jsonNode.get(CODE).asText());
        }
        return code;
    }

    /**
     * Does this.
     *
     * @param jsonNode
     * @return
     */
    private AccountNumberInfo retrieveAccountNumber(final JsonNode jsonNode) {
        AccountNumberInfo accNo = new AccountNumberInfo();
        if (jsonNode.hasNonNull(ACCOUNT_NO)) {
            accNo.setAccountNo(jsonNode.get(ACCOUNT_NO).asText());
        }
        return accNo;
    }
}
