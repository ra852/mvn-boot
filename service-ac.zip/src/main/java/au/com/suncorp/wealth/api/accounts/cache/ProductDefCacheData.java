////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.cache;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_NO_PRODUCT_DEF_DET_RES;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_NO_PRODUCT_DEF_RES;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_RUNTIME_ID;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import au.com.suncorp.wealth.api.accounts.model.Product;
import au.com.suncorp.wealth.api.accounts.rest.DomainApiService;
import au.com.suncorp.wealth.api.accounts.utils.AccountUtil;
import au.com.suncorp.wealth.api.accounts.utils.ProductDefUtil;
import net.jodah.expiringmap.ExpiringMap;

/**
 * The class {@code ProdctDefinitionCacheData} does this.
 *
 * @author U383754
 * @since 8Mar.,2018
 * @version 1.0
 */
public class ProductDefCacheData extends AccountUtil {
    private static Map<String, Product> productDefDataMap = ExpiringMap.builder().expiration(24, TimeUnit.HOURS).build();
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(ProductDefCacheData.class);

    public Product getProductDefinitionDetails(RestTemplate restTemplate, DomainApiService domainApiService, String productId, String accountNumber,
            ParameterBean pb) {
        APP_LOGGER.info("Product definition map in cache : " + productDefDataMap);
        if (productDefDataMap.containsKey(productId)) {
            return productDefDataMap.get(productId);
        } else {
            productDefDataMap = new ProductDefUtil().callPortfolioService(restTemplate, domainApiService, accountNumber, pb);
            if (productDefDataMap.containsKey(productId)) {
                return productDefDataMap.get(productId);
            } else {
                throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), LBL_NO_PRODUCT_DEF_RES, LBL_NO_PRODUCT_DEF_DET_RES, pb);
            }
        }
    }
}
