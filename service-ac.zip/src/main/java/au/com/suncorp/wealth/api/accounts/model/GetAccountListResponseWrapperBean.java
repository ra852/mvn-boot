////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model;

import com.google.gson.annotations.SerializedName;

/**
 * The class {@code GetAccountListResponseWrapperBean} does this.
 *
 * @author u201468
 * @since 20Feb.,2018
 * @version 1.0
 */
public class GetAccountListResponseWrapperBean {
    @SerializedName("GetAccountListResponse")
    private GetAccountListResponseBean getAccountListResponse;

    public GetAccountListResponseBean getGetAccountListResponse() {
        return getAccountListResponse;
    }

    public void setGetAccountListResponse(GetAccountListResponseBean getAccountListResponse) {
        this.getAccountListResponse = getAccountListResponse;
    }

}
