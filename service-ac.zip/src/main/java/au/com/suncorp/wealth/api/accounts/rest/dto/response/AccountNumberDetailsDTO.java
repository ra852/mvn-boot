////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.rest.dto.response;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

/**
 * The class {@code AccountNumberDetailsDTO} does this.
 *
 * @author U205452
 * @since 30Mar.,2018
 * @version 1.0
 */
public class AccountNumberDetailsDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    @NotBlank
    @Pattern(regexp = "^[0-9]{7,9}+$")
    private String accountNumber;

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
}
