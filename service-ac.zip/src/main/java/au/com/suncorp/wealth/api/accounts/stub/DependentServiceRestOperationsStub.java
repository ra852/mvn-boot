////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.stub;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import au.com.suncorp.wealth.api.common.rest.stub.JsonToObjectMapper;
import au.com.suncorp.wealth.api.common.rest.stub.RestOperationsStub;
import au.com.suncorp.wealth.api.accounts.provider.domain.CustomerResponseVO;

/**
 * The class {@code DependentServiceRestOperationsStub} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class DependentServiceRestOperationsStub extends RestOperationsStub {
    private JsonToObjectMapper<CustomerResponseVO> mapper = new JsonToObjectMapper<>(CustomerResponseVO.class);

    /**
     * Does this.
     *
     * @param url
     * @param method
     * @param requestEntity
     * @param responseType
     * @param uriVariables
     * @return
     */
    @SuppressWarnings("unchecked")
    @Override
    public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Object... uriVariables) {

        try {
            CustomerResponseVO response = buildCustomerResponseVO();
            return (ResponseEntity<T>) new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Builds customer response.
     */
    private CustomerResponseVO buildCustomerResponseVO() {
        CustomerResponseVO customerResponseVO = mapper.mapFromFile("/stubs/dependent-service-response.json");

        return customerResponseVO;
    }
}
