////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2018, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.interceptor;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.ENTITLEMENT_ID_FIELD_NAME;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.REQUEST_ID_FIELD_NAME;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.VERSION_ID_FIELD_NAME;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.beanvalidation.SpringValidatorAdapter;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import au.com.suncorp.wealth.api.common.rest.dto.request.ClientHeaderDetailsDTO;

/**
 * The class {@code ClientHeadersValidationInterceptor} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class ClientHeadersValidationInterceptor extends HandlerInterceptorAdapter {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Does this.
     *
     * @param request
     * @param response
     * @param handler
     * @return
     * @throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logger.debug("preHandle() - Start");

        String requestId = request.getHeader(REQUEST_ID_FIELD_NAME);
        String apiVersion = request.getHeader(VERSION_ID_FIELD_NAME);
        String entitlementInfo = request.getHeader(ENTITLEMENT_ID_FIELD_NAME);

        BindingResult bindingResult = validateHeader(entitlementInfo, requestId, apiVersion);

        if (bindingResult.hasErrors()) {
            logger.debug("preHandle() - Validation fail: {}", bindingResult);
            throw new BindException(bindingResult);
        }

        logger.debug("preHandle() - Validation pass");

        return true;
    }

    /**
     * Validates Header.
     *
     * @param authorization
     * @param xRequestId
     * @param xApiVersion
     * @return
     */
    @SuppressWarnings("rawtypes")
    private BindingResult validateHeader(String entitlementInfo, String xRequestId, String xApiVersion) {
        ClientHeaderDetailsDTO clientHeaderDetailsDTO = new ClientHeaderDetailsDTO();
        clientHeaderDetailsDTO.setApiVersion(xApiVersion);
        clientHeaderDetailsDTO.setRequestId(xRequestId);
        clientHeaderDetailsDTO.setEntitlmentInfo(entitlementInfo);

        ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
        Validator validator = validatorFactory.getValidator();

        BindingResult bindingResult = new MapBindingResult(new HashMap(), clientHeaderDetailsDTO.getClass().getSimpleName());
        SpringValidatorAdapter springValidatorAdapter = new SpringValidatorAdapter(validator);
        springValidatorAdapter.validate(clientHeaderDetailsDTO, bindingResult);

        return bindingResult;
    }
}
