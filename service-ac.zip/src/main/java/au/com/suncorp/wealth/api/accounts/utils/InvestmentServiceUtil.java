////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.utils;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_ACCOUNT_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_BAD_REQUEST_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_COULD_NOT_PROCESSED;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FAILED_ACC_INS_RES;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FAILED_PRODUCT_RESPONSE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_IDENTITY_NOT_FOUND;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_INVALID_REQUEST;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_INVALID_RESPONSE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_NOT_FOUND_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_NO_ACC_FOUND;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_NO_ACC_MAPPED;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_NO_TRANSACTION;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_RUNTIME_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_START_DATE;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;

import au.com.suncorp.wealth.api.accounts.config.properties.AccountServiceProperties;
import au.com.suncorp.wealth.api.accounts.constant.Constants;
import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.exception.InvalidRequestAccountRuntimeException;
import au.com.suncorp.wealth.api.accounts.exception.NotFoundAccountRuntimeException;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetInvestmentBalanceResponseBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetInvestmentBalanceResponseWrapperBean;

/**
 * The class {@code InvestmentServiceUtil} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class InvestmentServiceUtil extends AccountUtil {
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(InvestmentServiceUtil.class);

    /**
     * Calls Sil service.
     *
     * @param restTemplate
     * @param accountServiceProperties
     * @param accountNumber
     * @param pb
     * @return
     */
    public GetInvestmentBalanceResponseBean callInvestmentService(RestTemplate restTemplate, AccountServiceProperties accountServiceProperties,
            String accountNumber, ParameterBean pb) {
        log(APP_LOGGER, new StringBuilder("Entering callInvestmentService() -> ").append(accountNumber).toString());
        final String investmentBalendpoint = accountServiceProperties.getHostName() + Constants.GET_INVESTMENT_BALANCE_PATH;
        String formattedUrl = investmentBalendpoint.replace(LBL_ACCOUNT_ID, accountNumber).replace(LBL_START_DATE,
                new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
        log(APP_LOGGER, new StringBuilder("Calling SIL service: ").append(investmentBalendpoint).toString());
        try {
            ResponseEntity<JsonNode> responseEntity =
                    retrieveBackendServiceResponse(restTemplate, accountServiceProperties, formattedUrl, accountNumber, pb);
            return getSilResponse(responseEntity, accountNumber, pb);
        } catch (RestClientException e) {
            throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), LBL_INVALID_RESPONSE, LBL_FAILED_PRODUCT_RESPONSE, pb);
        }
    }

    /**
     * Get Sil response.
     *
     * @param responseEntity
     * @param accountNumber
     * @param pb
     * @return
     */
    private GetInvestmentBalanceResponseBean getSilResponse(ResponseEntity<JsonNode> responseEntity, String accountNumber, ParameterBean pb) {
        log(APP_LOGGER, new StringBuilder("Entering getSilResponse() -> ").append(accountNumber).toString());
        GetInvestmentBalanceResponseBean getInvestmentBalanceResponse;
        GetInvestmentBalanceResponseWrapperBean investmentResponseJavaObj =
                parseJsonToObj(responseEntity, accountNumber, pb, GetInvestmentBalanceResponseWrapperBean.class);
        getInvestmentBalanceResponse = investmentResponseJavaObj.getGetInvestmentBalanceResponse();
        return checkAndVerifySilResponse(getInvestmentBalanceResponse, responseEntity, accountNumber, pb);
    }

    /**
     * Check and verify Sil Response.
     *
     * @param getInvestmentBalanceResponse
     * @param responseEntity
     * @param accountNumber
     * @param pb
     * @return
     */
    private GetInvestmentBalanceResponseBean checkAndVerifySilResponse(GetInvestmentBalanceResponseBean getInvestmentBalanceResponse,
            ResponseEntity<JsonNode> responseEntity, String accountNumber, ParameterBean pb) {
        log(APP_LOGGER, new StringBuilder("Verifying SIL response -> ").append(accountNumber).toString());
        if (checkSilErrors(getInvestmentBalanceResponse)) {
            String silError = getInvestmentBalanceResponse.getErrorMessage();
            log(APP_LOGGER, new StringBuilder("SIL Error Message: ").append(silError).toString());
            if (silError != null && silError.contains(LBL_IDENTITY_NOT_FOUND)) {
                throw new NotFoundAccountRuntimeException(getLogId(LBL_NOT_FOUND_ID), LBL_NO_ACC_FOUND, LBL_NO_ACC_MAPPED, pb);
            } else if (400 == responseEntity.getStatusCodeValue()) {
                throw new InvalidRequestAccountRuntimeException(getLogId(LBL_BAD_REQUEST_ID), LBL_INVALID_REQUEST, LBL_INVALID_REQUEST, pb);
            } else if (silError != null && !silError.contains(LBL_IDENTITY_NOT_FOUND)) {
                throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), LBL_INVALID_REQUEST, LBL_FAILED_ACC_INS_RES, pb);
            } else {
                throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), LBL_INVALID_RESPONSE, LBL_FAILED_ACC_INS_RES, pb);
            }
        } else {
            log(APP_LOGGER, new StringBuilder("No error message found in SIL response -> ").append(accountNumber).toString());
            log(APP_LOGGER, new StringBuilder("Get investment balance response for ").append(accountNumber).append(" ")
                    .append(getInvestmentBalanceResponse).toString());
            return getInvestmentBalanceResponse;
        }
    }

    /**
     * Does this.
     *
     * @param getInvestmentBalanceResponse
     * @return
     */
    private boolean checkSilErrors(GetInvestmentBalanceResponseBean getInvestmentBalanceResponse) {
        return getInvestmentBalanceResponse != null && getInvestmentBalanceResponse.getErrorMessage() != null &&
                !getInvestmentBalanceResponse.getErrorMessage().equalsIgnoreCase(LBL_NO_TRANSACTION) &&
                !getInvestmentBalanceResponse.getErrorMessage().equalsIgnoreCase(LBL_COULD_NOT_PROCESSED);
    }
}
