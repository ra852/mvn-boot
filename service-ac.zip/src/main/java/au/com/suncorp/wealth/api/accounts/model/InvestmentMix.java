////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model;

import java.math.BigDecimal;

import org.beanio.annotation.Record;
import org.beanio.annotation.Segment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code InvestmentMix} does this.
 *
 * @author u201468
 * @since 15Jan.,2018
 * @version 1.0
 */
@Record(minOccurs = 1, name = "InvestmentMix")
@JsonInclude(Include.NON_EMPTY)
public class InvestmentMix {
    @ApiModelProperty(position = 1, example = "Suncorp Cash Fund Sup")
    private String fundName;
    @ApiModelProperty(position = 2, example = "11961.58")
    private BigDecimal units;
    @ApiModelProperty(position = 3)
    @Segment(name = "unitprice")
    private Amount unitprice;
    @ApiModelProperty(position = 4)
    @Segment(name = "dollarValue")
    private Amount dollarValue;
    @ApiModelProperty(position = 3, example = "29.13")
    private String percentageAllocated;

    /**
     * Accessor for property fundName.
     *
     * @return fundName of type String
     */
    public String getFundName() {
        return fundName;
    }

    /**
     * Mutator for property fundName.
     *
     * @param fundName of type String
     */

    public void setFundName(String fundName) {
        this.fundName = fundName;
    }

    /**
     * Accessor for property units.
     *
     * @return units of type BigDecimal
     */
    public BigDecimal getUnits() {
        return units;
    }

    /**
     * Mutator for property units.
     *
     * @param units of type BigDecimal
     */
    public void setUnits(BigDecimal units) {
        this.units = units;
    }

    /**
     * Accessor for property unitprice.
     *
     * @return unitprice of type AmountBean
     */
    public Amount getUnitprice() {
        return unitprice;
    }

    /**
     * Mutator for property unitprice.
     *
     * @param unitprice of type AmountBean
     */
    public void setUnitprice(Amount unitprice) {
        this.unitprice = unitprice;
    }

    /**
     * Accessor for property dollarValue.
     *
     * @return dollarValue of type AmountBean
     */
    public Amount getDollarValue() {
        return dollarValue;
    }

    /**
     * Mutator for property dollarValue.
     *
     * @param dollarValue of type AmountBean
     */
    public void setDollarValue(Amount dollarValue) {
        this.dollarValue = dollarValue;
    }

    /**
     * Accessor for property percentageAllocated.
     *
     * @return percentageAllocated of type String
     */
    public String getPercentageAllocated() {
        return percentageAllocated;
    }

    /**
     * Mutator for property percentageAllocated.
     *
     * @param percentageAllocated of type String
     */

    public void setPercentageAllocated(String percentageAllocated) {
        this.percentageAllocated = percentageAllocated;
    }

}
