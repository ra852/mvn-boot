////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

import java.util.List;

/**
 * The class {@code GetInvestmentBalanceResponseBean} is a java bean consisting of all the properties related to getInvestmentBalance functionality,
 * to be used for constructing response for end-client.
 * 
 * @author U384381
 * @since 30/12/2015
 * @version 1.0
 */
public class GetInvestmentBalanceResponseBean extends SILErrorMessage {
    private List<TransSummaryDetail> transSummaryDetails;
    private String totalOpeningBalance;
    private String totalClosingBalance;

    /**
     * Accessor for property transSummaryDetails.
     * 
     * @return transSummaryDetails of type List<TransSummaryDetail>
     */
    public List<TransSummaryDetail> getTransSummaryDetails() {
        return transSummaryDetails;
    }

    /**
     * Mutator for property transSummaryDetails.
     * 
     * @return transSummaryDetails of type List<TransSummaryDetail>
     */
    public void setTransSummaryDetails(List<TransSummaryDetail> transSummaryDetails) {
        this.transSummaryDetails = transSummaryDetails;
    }

    /**
     * Accessor for property totalOpeningBalance.
     * 
     * @return totalOpeningBalance of type String
     */
    public String getTotalOpeningBalance() {
        return totalOpeningBalance;
    }

    /**
     * Mutator for property totalOpeningBalance.
     * 
     * @return totalOpeningBalance of type String
     */
    public void setTotalOpeningBalance(String totalOpeningBalance) {
        this.totalOpeningBalance = totalOpeningBalance;
    }

    /**
     * Accessor for property totalClosingBalance.
     * 
     * @return totalClosingBalance of type String
     */
    public String getTotalClosingBalance() {
        return totalClosingBalance;
    }

    /**
     * Mutator for property totalClosingBalance.
     * 
     * @return totalClosingBalance of type String
     */
    public void setTotalClosingBalance(String totalClosingBalance) {
        this.totalClosingBalance = totalClosingBalance;
    }
}
