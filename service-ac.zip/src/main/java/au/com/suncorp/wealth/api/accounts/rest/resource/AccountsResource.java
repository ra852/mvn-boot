////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.rest.resource;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.ACCOUNT_NUMBER;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.AUTHORISATION_FIELD_NAME;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.INCLUDE_REQ_PARAM;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_ACCOUNTS;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_INSURANCES;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_PRODUCTS;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.REQUEST_ID_FIELD_NAME;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.VERSION_ID_FIELD_NAME;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.X_CHANNEL_INFO_FIELD_NAME;
import static au.com.suncorp.wealth.api.common.constant.CommonConstants.ACCEPT_APPLICATION_JSON_API_VALUE;
import static au.com.suncorp.wealth.api.common.constant.CommonConstants.APPLICATION_JSON_API_VALUE;
import static au.com.suncorp.wealth.api.common.constant.CommonConstants.ENTITLEMENT_ID_FIELD_NAME;
import static au.com.suncorp.wealth.api.common.constant.CommonConstants.REST_BASE_URL_PATTERN;
import static au.com.suncorp.wealth.api.common.constant.CommonConstants.X_CLIENT_ID_FIELD_NAME;
import static au.com.suncorp.wealth.api.common.constant.CommonConstants.X_CLIENT_VERSION_FIELD_NAME;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import au.com.suncorp.wealth.api.accounts.enums.AccountParams;
import au.com.suncorp.wealth.api.accounts.enums.ProductDefinition;
import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetAccountDetailsResponse;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetInvestmentBalanceResponseBean;
import au.com.suncorp.wealth.api.accounts.provider.AccountService;
import au.com.suncorp.wealth.api.accounts.provider.mapper.AccountReferenceMapper;
import au.com.suncorp.wealth.api.accounts.rest.DomainApiService;
import au.com.suncorp.wealth.api.accounts.rest.JwtService;
import au.com.suncorp.wealth.api.accounts.rest.UriHelperService;
import au.com.suncorp.wealth.api.accounts.rest.dto.response.AccountResponseDTO;
import au.com.suncorp.wealth.api.accounts.rest.dto.response.InsuranceResponseDTO;
import au.com.suncorp.wealth.api.accounts.rest.dto.response.ProductResponseDTO;
import au.com.suncorp.wealth.api.accounts.utils.AccountNoValidation;
import au.com.suncorp.wealth.api.accounts.utils.AccountUtil;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The class {@code AccountsResource} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@RestController
@RequestMapping(REST_BASE_URL_PATTERN)
public class AccountsResource {
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(AccountsResource.class);

    private final AccountService accountService;
    private final UriHelperService uriHelperService;
    private final JwtService jwtService;
    private final AccountUtil commonUtil;
    private final DomainApiService domainApiService;
    private final Environment env;

    private List<Map<String, String>> partyRefs;

    /**
     * Parameterised constructor.
     *
     * @param accountService
     * @param uriHelperService
     */
    @Autowired
    public AccountsResource(AccountService accountService, UriHelperService uriHelperService, JwtService jwtService, AccountUtil commonUtil,
            DomainApiService domainApiService, Environment env) {
        this.accountService = accountService;
        this.uriHelperService = uriHelperService;
        this.jwtService = jwtService;
        this.commonUtil = commonUtil;
        this.domainApiService = domainApiService;
        this.env = env;
    }

    /**
     * Get account operation.
     *
     * @param accountNumber
     * @param includeParams
     * @param authorizationHeader
     * @param requestId
     * @param apiVersion
     * @return
     */
    @ApiOperation(value = "Accounts", notes = "Retrieves account details", nickname = "account")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval of account details.", response = AccountResponseDTO.class),
            @ApiResponse(code = 400, message = "Bad input parameter"), @ApiResponse(code = 401, message = "Not authorised"),
            @ApiResponse(code = 404, message = "Not found"), @ApiResponse(code = 403, message = "Forbidden") })
    @ApiImplicitParam(value = "JSON API format", name = "Accept", allowableValues = APPLICATION_JSON_API_VALUE, paramType = "header", dataType = "String", required = true)
    @RequestMapping(value = "/{accountNumber}", method = RequestMethod.GET, headers = ACCEPT_APPLICATION_JSON_API_VALUE, produces = APPLICATION_JSON_API_VALUE)
    public ResponseEntity<AccountResponseDTO> account(@PathVariable(value = ACCOUNT_NUMBER) String accountNumber,
            @RequestParam(value = INCLUDE_REQ_PARAM, required = false) List<AccountParams> includeParams,
            @RequestHeader(value = AUTHORISATION_FIELD_NAME) String authorizationHeader,
            @RequestHeader(value = REQUEST_ID_FIELD_NAME, required = false) String requestId,
            @RequestHeader(value = VERSION_ID_FIELD_NAME, required = false) String apiVersion,
            @RequestHeader(value = ENTITLEMENT_ID_FIELD_NAME, required = false) String entitlementHeader,
            @RequestHeader(value = X_CLIENT_ID_FIELD_NAME, required = false) String clientId,
            @RequestHeader(value = X_CLIENT_VERSION_FIELD_NAME, required = false) String clientVersion,
            @RequestHeader(value = X_CHANNEL_INFO_FIELD_NAME, required = false) String channelInfo) {
        try {
            ParameterBean pb = commonUtil.constructParams(includeParams, requestId, apiVersion, LBL_ACCOUNTS, clientId, clientVersion);
            AccountNoValidation.validateAccountNumber(accountNumber, pb);
            AccountReferenceMapper accountReferenceMapper = new AccountReferenceMapper();
            commonUtil.log(APP_LOGGER, new StringBuilder("Request recieved for accountNumber ").append(accountNumber)
                    .append(" account with following params: ").append(REQUEST_ID_FIELD_NAME).append("= ").append(requestId).toString());
            commonUtil.log(APP_LOGGER,
                    new StringBuilder("JWT token received from API-GW: ").append("JWT Token ").append("= ").append(authorizationHeader).toString());
            commonUtil.log(APP_LOGGER, new StringBuilder("Entitlement JWT token received from API-GW: ").append("Entitlement Token ").append("= ")
                    .append(entitlementHeader).toString());
            if (new AccountUtil().isSuncorpIdentitySkip(jwtService) && !accountReferenceMapper.checkForHighTrustCall()) {
                partyRefs = accountReferenceMapper.map(entitlementHeader, accountNumber, env, pb);
            }
            CompletableFuture<GetAccountDetailsResponse> getAccountDetails = accountService.getAccountDetails(accountNumber, pb);
            CompletableFuture<GetInvestmentBalanceResponseBean> getInvestmentDetails = accountService.getInvestmentDetails(accountNumber, pb);
            CompletableFuture.allOf(getAccountDetails, getInvestmentDetails).join();
            GetAccountDetailsResponse getAccountDetailsResponse = new AccountUtil().get(getAccountDetails, accountNumber, pb);
            GetInvestmentBalanceResponseBean getInvestmentBalanceResponse = new AccountUtil().get(getInvestmentDetails, accountNumber, pb);
            if (new AccountUtil().isSuncorpIdentitySkip(jwtService) && !accountReferenceMapper.checkForHighTrustCall()) {
                accountReferenceMapper.doVerification(partyRefs, getAccountDetailsResponse, accountNumber, pb);
            }
            return accountService.accounts(uriHelperService.getUriForWealthAPI(), accountNumber, domainApiService, getAccountDetailsResponse,
                    getInvestmentBalanceResponse, pb);
        } catch (AccountServiceRuntimeException ex) {
            throw ex;
        }
    }

    /**
     * Get insurances operation.
     *
     * @param accountNumber
     * @param authorizationHeader
     * @param requestId
     * @param apiVersion
     * @return
     */
    @ApiOperation(value = "Insurances", notes = "Retrieves insurance details", nickname = "insurance")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval of insurance list", response = InsuranceResponseDTO.class),
            @ApiResponse(code = 400, message = "Bad input parameter"), @ApiResponse(code = 401, message = "Not authorised"),
            @ApiResponse(code = 404, message = "Not found"), @ApiResponse(code = 403, message = "Forbidden") })
    @ApiImplicitParam(value = "JSON API format", name = "Accept", allowableValues = APPLICATION_JSON_API_VALUE, paramType = "header", dataType = "String", required = true)
    @RequestMapping(value = "/{accountNumber}/insurances", method = RequestMethod.GET, headers = ACCEPT_APPLICATION_JSON_API_VALUE, produces = APPLICATION_JSON_API_VALUE)
    public ResponseEntity<InsuranceResponseDTO> insurance(@PathVariable String accountNumber,
            @RequestHeader(value = AUTHORISATION_FIELD_NAME) String authorizationHeader,
            @RequestHeader(value = REQUEST_ID_FIELD_NAME, required = false) String requestId,
            @RequestHeader(value = VERSION_ID_FIELD_NAME, required = false) String apiVersion,
            @RequestHeader(value = ENTITLEMENT_ID_FIELD_NAME, required = false) String entitlementHeader,
            @RequestHeader(value = X_CLIENT_ID_FIELD_NAME, required = false) String clientId,
            @RequestHeader(value = X_CLIENT_VERSION_FIELD_NAME, required = false) String clientVersion,
            @RequestHeader(value = X_CHANNEL_INFO_FIELD_NAME, required = false) String channelInfo) {
        try {
            ParameterBean pb = commonUtil.constructParams(null, requestId, apiVersion, LBL_INSURANCES, clientId, clientVersion);
            AccountNoValidation.validateAccountNumber(accountNumber, pb);
            AccountReferenceMapper accountReferenceMapper = new AccountReferenceMapper();
            commonUtil.log(APP_LOGGER, new StringBuilder("Request recieved for accountNumber ").append(accountNumber)
                    .append(" insurance with following params: ").append(REQUEST_ID_FIELD_NAME).append("= ").append(requestId).toString());
            if (new AccountUtil().isSuncorpIdentitySkip(jwtService) && !accountReferenceMapper.checkForHighTrustCall()) {
                partyRefs = accountReferenceMapper.map(entitlementHeader, accountNumber, env, pb);
            }
            CompletableFuture<GetAccountDetailsResponse> getAccountDetails = accountService.getAccountDetails(accountNumber, pb);
            GetAccountDetailsResponse getAccountDetailsResponse = new AccountUtil().get(getAccountDetails, accountNumber, pb);
            if (new AccountUtil().isSuncorpIdentitySkip(jwtService) && !accountReferenceMapper.checkForHighTrustCall()) {
                accountReferenceMapper.doVerification(partyRefs, getAccountDetailsResponse, accountNumber, pb);
            }
            return accountService.insurances(accountNumber, getAccountDetailsResponse, pb);
        } catch (AccountServiceRuntimeException ex) {
            throw ex;
        }
    }

    /**
     * Get products operation.
     *
     * @param accountNumber
     * @param authorizationHeader
     * @param requestId
     * @param apiVersion
     * @return
     */
    @ApiOperation(value = "Products", notes = "Retrieves product details", nickname = "product")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval of product details.", response = ProductResponseDTO.class),
            @ApiResponse(code = 400, message = "Bad input parameter"), @ApiResponse(code = 401, message = "Not authorised"),
            @ApiResponse(code = 404, message = "Not found"), @ApiResponse(code = 403, message = "Forbidden") })
    @ApiImplicitParam(value = "JSON API format", name = "Accept", allowableValues = APPLICATION_JSON_API_VALUE, paramType = "header", dataType = "String", required = true)
    @RequestMapping(value = "/{accountNumber}/products", method = RequestMethod.GET, headers = ACCEPT_APPLICATION_JSON_API_VALUE, produces = APPLICATION_JSON_API_VALUE)
    public ResponseEntity<ProductResponseDTO> product(@PathVariable String accountNumber,
            @RequestParam(value = INCLUDE_REQ_PARAM, required = false) List<ProductDefinition> includeParam,
            @RequestHeader(value = AUTHORISATION_FIELD_NAME) String authorizationHeader,
            @RequestHeader(value = REQUEST_ID_FIELD_NAME, required = false) String requestId,
            @RequestHeader(value = VERSION_ID_FIELD_NAME, required = false) String apiVersion,
            @RequestHeader(value = ENTITLEMENT_ID_FIELD_NAME, required = false) String entitlementHeader,
            @RequestHeader(value = X_CLIENT_ID_FIELD_NAME, required = false) String clientId,
            @RequestHeader(value = X_CLIENT_VERSION_FIELD_NAME, required = false) String clientVersion,
            @RequestHeader(value = X_CHANNEL_INFO_FIELD_NAME, required = false) String channelInfo) {
        try {
            ParameterBean pb = commonUtil.constructParams(includeParam, requestId, apiVersion, LBL_PRODUCTS, clientId, clientVersion);
            AccountNoValidation.validateAccountNumber(accountNumber, pb);
            AccountReferenceMapper accountReferenceMapper = new AccountReferenceMapper();
            commonUtil.log(APP_LOGGER, new StringBuilder("Request recieved for accountNumber ").append(accountNumber)
                    .append(" product with following params: ").append(REQUEST_ID_FIELD_NAME).append("= ").append(requestId).toString());
            if (new AccountUtil().isSuncorpIdentitySkip(jwtService) && !accountReferenceMapper.checkForHighTrustCall()) {
                partyRefs = accountReferenceMapper.map(entitlementHeader, accountNumber, env, pb);
            }
            CompletableFuture<GetAccountDetailsResponse> getAccountDetails = accountService.getAccountDetails(accountNumber, pb);
            GetAccountDetailsResponse getAccountDetailsResponse = new AccountUtil().get(getAccountDetails, accountNumber, pb);
            if (new AccountUtil().isSuncorpIdentitySkip(jwtService) && !accountReferenceMapper.checkForHighTrustCall()) {
                accountReferenceMapper.doVerification(partyRefs, getAccountDetailsResponse, accountNumber, pb);
            }
            return accountService.products(accountNumber, getAccountDetailsResponse, pb, domainApiService);
        } catch (AccountServiceRuntimeException ex) {
            throw ex;
        }
    }

}
