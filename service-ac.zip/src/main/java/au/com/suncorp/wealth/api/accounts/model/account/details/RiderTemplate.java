////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code RiderTemplate} is a java bean consisting of properties related to RiderTemplate Details.
 * 
 * @author u385424
 * @since 05/05/2016
 * @version 1.0
 */
public class RiderTemplate {
    private String id;
    private String name;
    private String shortName;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property shortName.
     * 
     * @return shortName of type String
     */
    public String getShortName() {
        return shortName;
    }

    /**
     * Mutator for property shortName.
     * 
     * @param shortName of type String
     */
    public void setShortName(String shortName) {
        this.shortName = shortName != null ? shortName : "";
    }

}
