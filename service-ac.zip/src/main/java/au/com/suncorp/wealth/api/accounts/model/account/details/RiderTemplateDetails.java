////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code RiderTemplateDetails} does this.
 * 
 * @author U386868
 * @since 17/05/2016
 * @version 1.0
 */
public class RiderTemplateDetails {

    private CodeIdentifier riderType;

    /**
     * Accessor for property riderType.
     * 
     * @return riderType of type CodeIdentifierDetails
     */
    public CodeIdentifier getRiderType() {
        return riderType;
    }

    /**
     * Mutator for property riderType.
     * 
     * @return riderType of type CodeIdentifierDetails
     */
    public void setRiderType(CodeIdentifier riderType) {
        this.riderType = riderType;
    }
}
