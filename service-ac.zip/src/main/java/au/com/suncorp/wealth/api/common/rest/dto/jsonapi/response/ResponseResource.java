////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.MoreObjects;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code ResponseResource} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 * @param <T>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public abstract class ResponseResource<T extends Object> extends ResponseBase {
    @ApiModelProperty(value = "Data", required = false)
    private ResponseData<T> data;

    public void setData(ResponseData<T> data) {
        this.data = data;
    }

    public ResponseData<T> getData() {
        return data;
    }

    protected MoreObjects.ToStringHelper toStringHelper() {
        return MoreObjects.toStringHelper(this).add("data", data);
    }

    @Override
    public String toString() {
        return toStringHelper().toString();
    }
}
