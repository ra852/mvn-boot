////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

import java.util.HashMap;
import java.util.Map;

/**
 * The class {@code InsuranceRiderInfo} does this.
 *
 * @author u201468
 * @since 2Feb.,2018
 * @version 1.0
 */
public final class InsuranceRiderInfo {
    private static final Map<String, String> INSURANCE_MAP = new HashMap<String, String>();

    private InsuranceRiderInfo() {
    }

    /**
     * Accessor for property insuranceMap.
     *
     * @return insurancemap of type Map<String,String>
     */
    public static Map<String, String> getInsurancemap() {
        INSURANCE_MAP.put("DETH", "Life Cover");
        INSURANCE_MAP.put("IP", "Income Protection");
        INSURANCE_MAP.put("TPD", "Total and Permanent Disablement Cover");
        INSURANCE_MAP.put("TD", "Income Protection");
        return INSURANCE_MAP;
    }

}
