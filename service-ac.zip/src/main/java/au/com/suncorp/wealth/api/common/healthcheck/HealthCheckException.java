////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.healthcheck;

import org.apache.commons.lang3.exception.ExceptionUtils;

/**
 * The class {@code HealthCheckException} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
public class HealthCheckException extends Exception {
    private final String endpoint;

    /**
     * Parameterised constructor.
     *
     * @param endpoint
     * @param e
     */
    public HealthCheckException(String endpoint, Exception e) {
        super(e.getMessage(), e);

        this.endpoint = endpoint;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public Throwable getRootCause() {
        return ExceptionUtils.getRootCause(getCause());
    }
}
