////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.context;

import java.util.concurrent.Callable;

import com.netflix.hystrix.strategy.concurrency.HystrixConcurrencyStrategy;

/**
 * The class {@code RequestContextHystrixConcurrencyStrategy} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class RequestContextHystrixConcurrencyStrategy extends HystrixConcurrencyStrategy {

    /**
     * Does this.
     *
     * @param callable
     * @return
     */
    @Override
    public <T> Callable<T> wrapCallable(final Callable<T> callable) {
        return new HystrixRequestContextCallable<>(callable);
    }
}
