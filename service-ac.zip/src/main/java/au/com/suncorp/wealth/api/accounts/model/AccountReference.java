////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The class {@code AccountReference} does this.
 *
 * @author u201468
 * @since 15Jan.,2018
 * @version 1.0
 */
public class AccountReference {
    private String brand;
    private String productType;
    private String productSystemId;
    private String productSystemPartyId;
    private String productNumber;

    /**
     * Does this.
     *
     * @param brand
     * @param productType
     * @param productSystemId
     * @param productSystemPartyId
     * @param productNumber
     */
    public AccountReference(String brand, String productType, String productSystemId, String productSystemPartyId, String productNumber) {
        super();
        this.brand = brand;
        this.productType = productType;
        this.productSystemId = productSystemId;
        this.productSystemPartyId = productSystemPartyId;
        this.productNumber = productNumber;
    }

    public AccountReference() {

    }

    /**
     * Accessor for property brand.
     *
     * @return brand of type String
     */
    public String getBrand() {
        return brand;
    }

    /**
     * Mutator for property brand.
     *
     * @param brand of type String
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * Accessor for property productType.
     *
     * @return productType of type String
     */
    public String getProductType() {
        return productType;
    }

    /**
     * Mutator for property productType.
     *
     * @param productType of type String
     */
    public void setProductType(String productType) {
        this.productType = productType;
    }

    /**
     * Accessor for property productSystemId.
     *
     * @return productSystemId of type String
     */
    public String getProductSystemId() {
        return productSystemId;
    }

    /**
     * Mutator for property productSystemId.
     *
     * @param productSystemId of type String
     */
    public void setProductSystemId(String productSystemId) {
        this.productSystemId = productSystemId;
    }

    /**
     * Accessor for property productSystemPartyId.
     *
     * @return productSystemPartyId of type String
     */
    public String getProductSystemPartyId() {
        return productSystemPartyId;
    }

    /**
     * Mutator for property productSystemPartyId.
     *
     * @param productSystemPartyId of type String
     */
    public void setProductSystemPartyId(String productSystemPartyId) {
        this.productSystemPartyId = productSystemPartyId;
    }

    /**
     * Accessor for property productNumber.
     *
     * @return productNumber of type String
     */
    public String getProductNumber() {
        return productNumber;
    }

    /**
     * Mutator for property productNumber.
     *
     * @param productNumber of type String
     */
    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    @JsonIgnore
    public boolean isPopulatedAccountReference() {
        return this.getBrand() != null && this.getProductSystemId() != null && this.getProductType() != null &&
                this.getProductSystemPartyId() != null;
    }

}
