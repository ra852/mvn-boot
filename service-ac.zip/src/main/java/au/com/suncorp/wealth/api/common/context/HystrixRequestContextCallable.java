////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.context;

import java.util.concurrent.Callable;

/**
 * The class {@code HystrixRequestContextCallable} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 * @param <T>
 */
public class HystrixRequestContextCallable<T> implements Callable<T> {
    private final Callable<T> callable;
    private final RequestContext parentRequestContext;

    /**
     * Parameterised constructor.
     *
     * @param callable
     */
    public HystrixRequestContextCallable(Callable<T> callable) {
        this.callable = callable;
        this.parentRequestContext = HystrixRequestContextHolder.get();
    }

    /**
     * Does this.
     *
     * @return
     * @throws Exception
     */
    @Override
    public T call() throws Exception {
        RequestContext originalRequestContext = HystrixRequestContextHolder.get();
        HystrixRequestContextHolder.set(parentRequestContext);

        try {
            return callable.call();
        } finally {
            HystrixRequestContextHolder.set(originalRequestContext);
        }
    }
}
