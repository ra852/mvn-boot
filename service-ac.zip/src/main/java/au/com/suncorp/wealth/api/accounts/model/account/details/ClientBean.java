////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code ClientBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class ClientBean {
    private String id;
    private String name;
    private MasterSchemeIdentifier masterScheme;
    private ReferenceIdentifier clientExternalRef;
    private String clientSurname;
    private String clientForename;
    private String clientForename2;
    private String clientTFN;
    private AuditIdentifier audit;
    private String globalIntermediaryIDNumber;

    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     *
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     *
     * @param name of type String
     */
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property masterScheme.
     *
     * @return masterScheme of type MasterSchemeIdentifier
     */
    public MasterSchemeIdentifier getMasterScheme() {
        return masterScheme;
    }

    /**
     * Mutator for property masterScheme.
     *
     * @param masterScheme of type MasterSchemeIdentifier
     */
    public void setMasterScheme(MasterSchemeIdentifier masterScheme) {
        this.masterScheme = masterScheme;
    }

    /**
     * Accessor for property clientExternalRef.
     *
     * @return clientExternalRef of type ReferenceIdentifier
     */
    public ReferenceIdentifier getClientExternalRef() {
        return clientExternalRef;
    }

    /**
     * Mutator for property clientExternalRef.
     *
     * @param clientExternalRef of type ReferenceIdentifier
     */
    public void setClientExternalRef(ReferenceIdentifier clientExternalRef) {
        this.clientExternalRef = clientExternalRef;
    }

    /**
     * Accessor for property clientSurname.
     *
     * @return clientSurname of type String
     */
    public String getClientSurname() {
        return clientSurname;
    }

    /**
     * Mutator for property clientSurname.
     *
     * @param clientSurname of type String
     */
    public void setClientSurname(String clientSurname) {
        this.clientSurname = clientSurname != null ? clientSurname : "";
    }

    /**
     * Accessor for property clientForename.
     *
     * @return clientForename of type String
     */
    public String getClientForename() {
        return clientForename;
    }

    /**
     * Mutator for property clientForename.
     *
     * @param clientForename of type String
     */
    public void setClientForename(String clientForename) {
        this.clientForename = clientForename != null ? clientForename : "";
    }

    /**
     * Accessor for property clientForename2.
     *
     * @return clientForename2 of type String
     */
    public String getClientForename2() {
        return clientForename2;
    }

    /**
     * Mutator for property clientForename2.
     *
     * @param clientForename2 of type String
     */
    public void setClientForename2(String clientForename2) {
        this.clientForename2 = clientForename2 != null ? clientForename2 : "";
    }

    /**
     * Accessor for property clientTFN.
     *
     * @return clientTFN of type String
     */
    public String getClientTFN() {
        return clientTFN;
    }

    /**
     * Mutator for property clientTFN.
     *
     * @param clientTFN of type String
     */
    public void setClientTFN(String clientTFN) {
        this.clientTFN = clientTFN != null ? clientTFN : "";
    }

    /**
     * Accessor for property audit.
     *
     * @return audit of type AuditIdentifier
     */
    public AuditIdentifier getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     *
     * @param audit of type AuditIdentifier
     */
    public void setAudit(AuditIdentifier audit) {
        this.audit = audit;
    }

    /**
     * Accessor for property globalIntermediaryIDNumber.
     *
     * @return globalIntermediaryIDNumber of type String
     */
    public String getGlobalIntermediaryIDNumber() {
        return globalIntermediaryIDNumber;
    }

    /**
     * Mutator for property globalIntermediaryIDNumber.
     *
     * @param globalIntermediaryIDNumber of type String
     */
    public void setGlobalIntermediaryIDNumber(String globalIntermediaryIDNumber) {
        this.globalIntermediaryIDNumber = globalIntermediaryIDNumber != null ? globalIntermediaryIDNumber : "";
    }

}
