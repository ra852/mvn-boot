////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.config.properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * The class {@code RestClientProperties} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@Configuration
public class RestClientProperties {

    private String wealthApiBaseUrl;
    private String contextPath;

    /**
     * Constructor for RestClientProperties.
     *
     * @param env
     */
    @Autowired
    public RestClientProperties(Environment env) {
        wealthApiBaseUrl = env.getRequiredProperty("rest.clients.wealth-api.base-url");
        contextPath = env.getRequiredProperty("server.context-path");
    }

    /**
     * Accessor for property wealthApiBaseUrl.
     *
     * @return wealthApiBaseUrl
     */
    public String getWealthApiBaseUrl() {
        return wealthApiBaseUrl;
    }

    /**
     * Accessor for property contextPath.
     *
     * @return contextPath
     */
    public String getContextPath() {
        return contextPath;
    }
}
