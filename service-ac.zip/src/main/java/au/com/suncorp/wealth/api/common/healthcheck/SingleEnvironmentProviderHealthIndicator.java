////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.healthcheck;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;

import au.com.suncorp.wealth.api.common.healthcheck.provider.SingleEnvironmentServiceProviderConfiguration;
import au.com.suncorp.wealth.api.common.healthcheck.util.HealthCheckUtil;

/**
 * The class {@code SingleEnvironmentProviderHealthIndicator} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public abstract class SingleEnvironmentProviderHealthIndicator implements HealthIndicator {
    private final Logger logger;
    private SingleEnvironmentServiceProviderConfiguration singleEnvironmentServiceProviderConfigure;

    /**
     * Parameterised constructor.
     *
     * @param singleEnvironmentServiceProviderConfigure
     * @param name
     */
    public SingleEnvironmentProviderHealthIndicator(SingleEnvironmentServiceProviderConfiguration singleEnvironmentServiceProviderConfigure,
            String name) {
        this.singleEnvironmentServiceProviderConfigure = singleEnvironmentServiceProviderConfigure;
        this.logger = LoggerFactory.getLogger(name);
    }

    @Override
    public Health health() {
        Health health;
        try {
            health = doCheck();
        } catch (Exception e) {
            health = handleErrorHealth(e);
        }
        return health;
    }

    protected abstract Health doCheck() throws HealthCheckException;

    /**
     * Hnadles error health.
     *
     * @param e
     * @return
     */
    private Health handleErrorHealth(Exception e) {
        Health health;
        String healthEndpoint = singleEnvironmentServiceProviderConfigure.getHealthEndpoint();
        if (singleEnvironmentServiceProviderConfigure.isBetweenExpectedDowntime()) {
            logger.warn("(Expected downtime period) " + HealthCheckUtil.formatErrorMessage(healthEndpoint, e), e);
            health = HealthCheckUtil.buildErrorHealth(healthEndpoint, Status.UNKNOWN, e);
        } else {
            logger.error(HealthCheckUtil.formatErrorMessage(healthEndpoint, e), e);
            health = HealthCheckUtil.buildErrorHealth(healthEndpoint, Status.OUT_OF_SERVICE, e);
        }
        return health;
    }
}
