////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.config.properties;

import au.com.suncorp.wealth.api.common.constant.CommonConstants;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * The class {@code CorsProperties} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@ConfigurationProperties(prefix = "api-common.cors")
public class CorsProperties {
    private String pathMappings = CommonConstants.REST_BASE_URL_PATTERN + "/**";
    private String allowedOrigins = "*";
    private String allowedMethods = "OPTIONS, GET, POST";
    private String allowedHeaders = "Content-Type, X-Requested-With, " +
            CommonConstants.X_CORRELATION_ID_FIELD_NAME + ", " +
            CommonConstants.X_CLIENT_ID_FIELD_NAME + ", " +
            CommonConstants.X_CLIENT_VERSION_FIELD_NAME;
    private boolean allowedCredentials = false;
    private Long maxAge = 3600L; // 60 minutes

    public String getPathMappings() {
        return pathMappings;
    }

    public void setPathMappings(String pathMappings) {
        this.pathMappings = pathMappings;
    }

    public String getAllowedOrigins() {
        return allowedOrigins;
    }

    public void setAllowedOrigins(String allowedOrigins) {
        this.allowedOrigins = allowedOrigins;
    }

    public String getAllowedMethods() {
        return allowedMethods;
    }

    public void setAllowedMethods(String allowedMethods) {
        this.allowedMethods = allowedMethods;
    }

    public String getAllowedHeaders() {
        return allowedHeaders;
    }

    public void setAllowedHeaders(String allowedHeaders) {
        this.allowedHeaders = allowedHeaders;
    }

    public boolean isAllowedCredentials() {
        return allowedCredentials;
    }

    public void setAllowedCredentials(boolean allowedCredentials) {
        this.allowedCredentials = allowedCredentials;
    }

    public Long getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(Long maxAge) {
        this.maxAge = maxAge;
    }
}
