////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.context;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * The class {@code RequestContext} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
public class RequestContext implements Serializable {
    private static final String X_CORRELATION_ID = "xCorrelationID";
    private static final String X_CLIENT_ID = "xClientID";
    private static final String X_CLIENT_VERSION = "xClientVersion";

    private final Map<String, String> contextMap = new HashMap<>();

    /**
     * Parameterised constructor.
     *
     * @param xCorrelationId
     * @param xClientId
     * @param xClientVersion
     */
    public RequestContext(String xCorrelationId, String xClientId, String xClientVersion) {
        contextMap.put(X_CORRELATION_ID, xCorrelationId);
        contextMap.put(X_CLIENT_ID, xClientId);
        contextMap.put(X_CLIENT_VERSION, xClientVersion);
    }

    public String getXCorrelationId() {
        return contextMap.get(X_CORRELATION_ID);
    }

    public String getXClientId() {
        return contextMap.get(X_CLIENT_ID);
    }

    public String getXClientVersion() {
        return contextMap.get(X_CLIENT_VERSION);
    }

    public void setContext(String key, String value) {
        contextMap.put(key, value);
    }

    public String getContext(String key) {
        return contextMap.get(key);
    }

    public Set<String> getContextKeys() {
        return contextMap.keySet();
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
