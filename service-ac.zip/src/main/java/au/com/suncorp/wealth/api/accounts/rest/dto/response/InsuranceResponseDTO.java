////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.rest.dto.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import au.com.suncorp.wealth.api.accounts.model.RiderInfo;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response.ResponseData;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response.ResponseResources;

/**
 * The class {@code InsuranceResponseDTO} does this.
 *
 * @author u201468
 * @since 17Jan.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
public class InsuranceResponseDTO extends ResponseResources<RiderInfo> implements Serializable {

    public static final String RESOURCE = "insurances";

    /**
     * Parameterised constructor.
     *
     * @param insuranceList
     */
    public InsuranceResponseDTO(List<RiderInfo> insuranceList) {
        List<ResponseData<RiderInfo>> data = new ArrayList<>();

        for (RiderInfo rider : insuranceList) {
            ResponseData<RiderInfo> insuranceData = new ResponseData<RiderInfo>(RESOURCE, rider.getId(), rider);
            data.add(insuranceData);
        }
        setData(data);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
