////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.provider.mapper;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.CURRENCY;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_BLANK;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_BPAY;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FUND_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_IN_FORCE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_OWNER;
import static au.com.suncorp.wealth.api.accounts.model.account.details.BillerConstant.EMPLOYER_SALARY_SACRIFICE_BILLER_CODE;
import static au.com.suncorp.wealth.api.accounts.model.account.details.BillerConstant.EMPLOYER_SALARY_SACRIFICE_CONTRIBUTION;
import static au.com.suncorp.wealth.api.accounts.model.account.details.BillerConstant.EMPLOYER_SGAWARD_BILLER_CODE;
import static au.com.suncorp.wealth.api.accounts.model.account.details.BillerConstant.EMPLOYER_SGAWARD_CONTRIBUTION;
import static au.com.suncorp.wealth.api.accounts.model.account.details.BillerConstant.EMPLOYER_VOLUNTARY_BILLER_CODE;
import static au.com.suncorp.wealth.api.accounts.model.account.details.BillerConstant.EMPLOYER_VOLUNTARY_CONTRIBUTION;
import static au.com.suncorp.wealth.api.accounts.model.account.details.BillerConstant.PERSONAL_BILLER_CODE;
import static au.com.suncorp.wealth.api.accounts.model.account.details.BillerConstant.PERSONAL_CONTRIBUTION;
import static au.com.suncorp.wealth.api.accounts.model.account.details.BillerConstant.SPOUSE_BILLER_CODE;
import static au.com.suncorp.wealth.api.accounts.model.account.details.BillerConstant.SPOUSE_CONTRIBUTION;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import au.com.suncorp.wealth.api.accounts.model.Account;
import au.com.suncorp.wealth.api.accounts.model.AccountRelationships;
import au.com.suncorp.wealth.api.accounts.model.Amount;
import au.com.suncorp.wealth.api.accounts.model.BillerCode;
import au.com.suncorp.wealth.api.accounts.model.InsuranceStatus;
import au.com.suncorp.wealth.api.accounts.model.InvestmentMix;
import au.com.suncorp.wealth.api.accounts.model.Product;
import au.com.suncorp.wealth.api.accounts.model.RiderInfo;
import au.com.suncorp.wealth.api.accounts.model.account.details.AccountDetailsList;
import au.com.suncorp.wealth.api.accounts.model.account.details.AccountStatusInfo;
import au.com.suncorp.wealth.api.accounts.model.account.details.CodeIdentifier;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetAccountDetailsResponse;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetInvestmentBalanceResponseBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.InsuranceRiderInfo;
import au.com.suncorp.wealth.api.accounts.model.account.details.ProductInfo;
import au.com.suncorp.wealth.api.accounts.model.account.details.RiderDetails;
import au.com.suncorp.wealth.api.accounts.model.account.details.TransSummaryDetail;
import au.com.suncorp.wealth.api.accounts.utils.AccountUtil;

/**
 * The class {@code AccountMapper} does this.
 *
 * @author u201468
 * @since 15Jan.,2018
 * @version 1.0
 */
@Component
public class AccountMapper {
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(AccountMapper.class);

    /**
     * Default constructor.
     *
     */
    public AccountMapper() {
    }

    /**
     * Does this.
     *
     * @param getAccountDetailsResponse
     * @param accountNumber
     * @param getAccountInsuranceDetailsResponse
     * @param getInvestmentBalanceResponse
     * @return accountResponse
     */
    public Account map(GetAccountDetailsResponse getAccountDetailsResponse, String accountNumber,
            GetInvestmentBalanceResponseBean getInvestmentBalanceResponse) {
        new AccountUtil().log(APP_LOGGER, new StringBuilder("Mapping attributes -> ").append(accountNumber).toString());
        Account accountResponse = new Account();
        if (getAccountDetailsResponse.getAccountDetailsList() != null) {
            AccountDetailsList accountDetails = getAccountDetailsResponse.getAccountDetailsList().stream()
                    .filter(x -> x.getAccount().getAccountNumber().getAccountNo().equalsIgnoreCase(accountNumber)).findFirst().get();
            mapAccountDetails(accountResponse, accountDetails);
            mapAccount(getInvestmentBalanceResponse, accountResponse, accountDetails);
            if (accountDetails.getExternalReferences() != null) {
                retrieveBpayReference(accountResponse, accountDetails);
            }
        }
        new AccountUtil().log(APP_LOGGER, new StringBuilder("Attributes mapped -> ").append(accountNumber).toString());
        return accountResponse;
    }

    /**
     * Does this.
     *
     * @param accountResponse
     * @param accountDetails
     */
    private void retrieveBpayReference(Account accountResponse, AccountDetailsList accountDetails) {
        if (accountDetails.getExternalReferences().stream().anyMatch(y -> y.getReferenceCode().equalsIgnoreCase(LBL_BPAY))) {
            String reference = accountDetails.getExternalReferences().stream().filter(e -> e.getReferenceCode().equalsIgnoreCase(LBL_BPAY)).findAny()
                    .get().getReference();
            accountResponse.setBpayCustomerRefNumber(reference);
        } else {
            accountResponse.setBpayCustomerRefNumber(null);
        }
    }

    /**
     * map AccountDetails.
     *
     * @param accountResponse
     * @param accountDetails
     */
    private void mapAccountDetails(Account accountResponse, AccountDetailsList accountDetails) {
        if (accountDetails.getAccount() != null && accountDetails.getAccountDetail() != null) {
            if (accountDetails.getAccount().getAccountNumber() != null && accountDetails.getAccount().getAccountNumber().getAccountNo() != null) {
                accountResponse.setAccountNumber(accountDetails.getAccount().getAccountNumber().getAccountNo());
            }
            otherAccountDetail(accountResponse, accountDetails);
        }
        if (accountDetails.getAccountBalance() != null) {
            accountResponse.setAccountBalance(retrieveAccountBalance(accountDetails));
        }
    }

    /**
     * Does this.
     *
     * @param accountResponse
     * @param accountDetails
     */
    private void otherAccountDetail(Account accountResponse, AccountDetailsList accountDetails) {
        if (accountDetails.getAccount().getStatusCode() != null && accountDetails.getAccount().getStatusCode().getCode() != null &&
                AccountStatusInfo.getStatusmap().containsKey(accountDetails.getAccount().getStatusCode().getCode())) {
            accountResponse.setAccountStatus(AccountStatusInfo.getStatusmap().get(accountDetails.getAccount().getStatusCode().getCode()));
        }
        if (accountDetails.getAccountDetail().getCommencementDate() != null) {
            accountResponse.setStartDate(accountDetails.getAccountDetail().getCommencementDate().substring(0,
                    accountDetails.getAccountDetail().getCommencementDate().indexOf("T")));
        }
    }

    /**
     * retrieves AccountBalance.
     *
     * @param accountDetails
     * @return
     */
    private Amount retrieveAccountBalance(AccountDetailsList accountDetails) {
        Amount accountBalance = new Amount();
        if (accountDetails.getAccountBalance() != null && !accountDetails.getAccountBalance().isEmpty()) {
            accountBalance.setAmount(new BigDecimal(accountDetails.getAccountBalance()));
        } else {
            accountBalance.setAmount(BigDecimal.ZERO);
        }
        accountBalance.setCurrency(CURRENCY);
        return accountBalance;
    }

    /**
     * maps Account.
     *
     * @param getAccountInsuranceDetailsResponse
     * @param getInvestmentBalanceResponse
     * @param accountResponse
     * @param accountDetails
     */
    private void mapAccount(GetInvestmentBalanceResponseBean getInvestmentBalanceResponse, Account accountResponse,
            AccountDetailsList accountDetails) {
        accountResponse.setBillerCodes(retrieveBillerCodes());
        if (getInvestmentBalanceResponse != null && getInvestmentBalanceResponse.getTransSummaryDetails() != null) {
            accountResponse.setInvestmentSummary(retrieveInvestmentSummary(getInvestmentBalanceResponse.getTransSummaryDetails()));
        }
    }

    /**
     * retrieve BillerCodes.
     * 
     * @param list
     *
     * @return billerList
     */
    private List<BillerCode> retrieveBillerCodes() {
        List<BillerCode> billerList = new ArrayList<>(Arrays.asList(new BillerCode(PERSONAL_CONTRIBUTION, PERSONAL_BILLER_CODE),
                new BillerCode(SPOUSE_CONTRIBUTION, SPOUSE_BILLER_CODE), new BillerCode(EMPLOYER_SGAWARD_CONTRIBUTION, EMPLOYER_SGAWARD_BILLER_CODE),
                new BillerCode(EMPLOYER_SALARY_SACRIFICE_CONTRIBUTION, EMPLOYER_SALARY_SACRIFICE_BILLER_CODE),
                new BillerCode(EMPLOYER_VOLUNTARY_CONTRIBUTION, EMPLOYER_VOLUNTARY_BILLER_CODE)));
        return billerList;
    }

    /**
     * retrieve InvestmentSummary.
     *
     * @param transSummaryDetails
     * @return investmentList
     */
    private List<InvestmentMix> retrieveInvestmentSummary(List<TransSummaryDetail> transSummaryDetails) {
        List<InvestmentMix> investmentList = new ArrayList<>();
        CsvReader csvReader = new CsvReader();
        for (TransSummaryDetail transDetail : transSummaryDetails) {
            if (transDetail != null && transDetail.getId() != null && !transDetail.getId().equalsIgnoreCase(LBL_FUND_ID)) {
                InvestmentMix investment = new InvestmentMix();
                retrieveFundName(csvReader, transDetail, investment);
                if (transDetail.getClosingUnits() != null) {
                    investment.setUnits(new BigDecimal(transDetail.getClosingUnits()));
                }
                investment.setUnitprice(retrieveUnitPrice(transDetail));
                investment.setDollarValue(retrieveDollarValue(transDetail));
                if (transDetail.getPercentage() != null) {
                    investment.setPercentageAllocated(transDetail.getPercentage());
                }
                investmentList.add(investment);
            }
        }
        return investmentList;
    }

    /**
     * Does this.
     *
     * @param csvReader
     * @param transDetail
     * @param investment
     */
    private void retrieveFundName(CsvReader csvReader, TransSummaryDetail transDetail, InvestmentMix investment) {
        if (transDetail.getId() != null && csvReader.csvMap().containsKey(transDetail.getId()) &&
                !csvReader.csvMap().get(transDetail.getId()).equalsIgnoreCase(LBL_BLANK)) {
            investment.setFundName(csvReader.csvMap().get(transDetail.getId()));
        } else {
            investment.setFundName(transDetail.getFundFullName());
        }
    }

    /**
     * retrieve DollarValue.
     *
     * @param transDetail
     * @return
     */
    private Amount retrieveDollarValue(TransSummaryDetail transDetail) {
        Amount amountBean = new Amount();
        if (transDetail.getClosingBalanceAmount() != null && !transDetail.getClosingBalanceAmount().isEmpty()) {
            amountBean.setAmount(new BigDecimal(transDetail.getClosingBalanceAmount()));
        } else {
            amountBean.setAmount(BigDecimal.ZERO);
        }
        amountBean.setCurrency(CURRENCY);
        return amountBean;
    }

    /**
     * retrieve UnitPrice.
     *
     * @param transDetail
     * @return
     */
    private Amount retrieveUnitPrice(TransSummaryDetail transDetail) {
        Amount amount = new Amount();
        if (transDetail.getClosingPrice() != null && !transDetail.getClosingPrice().isEmpty()) {
            amount.setAmount(new BigDecimal(transDetail.getClosingPrice()));
        } else {
            amount.setAmount(BigDecimal.ZERO);
        }
        amount.setCurrency(CURRENCY);
        return amount;
    }

    /**
     * map Insurance.
     *
     * @param getAccountInsuranceDetailsResponse
     * @return insuranceList
     */
    public List<RiderInfo> mapInsurance(GetAccountDetailsResponse getAccountDetailsResponse) {
        List<RiderInfo> insuranceList = new ArrayList<RiderInfo>();
        if (getAccountDetailsResponse.getAccountDetailsList() != null) {
            AccountDetailsList accountDetails = getAccountDetailsResponse.getAccountDetailsList().stream().findFirst().get();
            if (accountDetails.getInsurances() != null && accountDetails.getInsurances().size() > 0) {
                for (RiderDetails rider : accountDetails.getInsurances()) {
                    retrieveInsurance(insuranceList, rider);
                }
            }
        }
        return insuranceList;
    }

    /**
     * Does this.
     *
     * @param insuranceList
     * @param rider
     */
    private void retrieveInsurance(List<RiderInfo> insuranceList, RiderDetails rider) {
        if (rider.getStatus() != null && rider.getStatus().getCodeShortDescription() != null &&
                rider.getStatus().getCodeShortDescription().equalsIgnoreCase(LBL_IN_FORCE)) {
            RiderInfo insurance = new RiderInfo();
            mapInsurances(rider, insurance);
            insuranceList.add(insurance);
        }
    }

    /**
     * map Insurances.
     *
     * @param rider
     * @param insurance
     */
    private void mapInsurances(RiderDetails rider, RiderInfo insurance) {
        if (rider != null) {
            if (rider.getId() != null) {
                insurance.setId(rider.getId());
            }
            if (rider.getLastRenewalDate() != null) {
                insurance.setLastRenewalDate(rider.getLastRenewalDate().substring(0, rider.getLastRenewalDate().indexOf("T")));
            }
            if (rider.getBenefitPeriod() != null) {
                insurance.setBenefitPeriod(rider.getBenefitPeriod());
            }
            if (rider.getWaitPeriod() != null) {
                insurance.setWaitPeriod(rider.getWaitPeriod());
            }
            insurance.setAnnualPremium(retrieveAnnualPremium(rider));
            insurance.setMonthlyPremium(retrieveMonthlyPremium(rider));
            insurance.setCoverAmount(retrieveCoverAmount(rider));
            mapOtherInsurance(rider, insurance);
        }
    }

    /**
     * Does this.
     * 
     * @param rider
     * @param insurance
     */
    private void mapOtherInsurance(RiderDetails rider, RiderInfo insurance) {
        if (rider.getRiskTermAge() != null) {
            insurance.setExpiryAge(rider.getRiskTermAge());
        }
        if (rider.getRiderTemplateDetails() != null && rider.getRiderTemplateDetails().getRiderType() != null &&
                rider.getRiderTemplateDetails().getRiderType().getCode() != null &&
                InsuranceRiderInfo.getInsurancemap().containsKey(rider.getRiderTemplateDetails().getRiderType().getCode())) {
            insurance.setInsuranceType(InsuranceRiderInfo.getInsurancemap().get(rider.getRiderTemplateDetails().getRiderType().getCode()));
            insurance.setInsuranceTypeId(rider.getRiderTemplateDetails().getRiderType().getCode());
        }
        if (rider.getStatus() != null) {
            insurance.setInsuranceStatus(retrieveInsuranceStatus(rider.getStatus()));
        }
    }

    /**
     * retrieve InsuranceStatus.
     *
     * @param status
     * @return
     */
    private InsuranceStatus retrieveInsuranceStatus(CodeIdentifier status) {
        InsuranceStatus insuranceStatus = new InsuranceStatus();
        if (status.getCode() != null) {
            insuranceStatus.setCode(status.getCode());
        }
        if (status.getCodeShortDescription() != null) {
            insuranceStatus.setValue(status.getCodeShortDescription());
        }
        return insuranceStatus;
    }

    /**
     * retrieve CoverAmount.
     *
     * @param rider
     * @return
     */
    private Amount retrieveCoverAmount(RiderDetails rider) {
        Amount amountBean = new Amount();
        if (rider.getSumInsured() != null && !rider.getSumInsured().isEmpty()) {
            amountBean.setAmount(new BigDecimal(rider.getSumInsured()));
        } else {
            amountBean.setAmount(BigDecimal.ZERO);
        }
        amountBean.setCurrency(CURRENCY);
        return amountBean;
    }

    /**
     * retrieve MonthlyPremium.
     *
     * @param rider
     * @return
     */
    private Amount retrieveMonthlyPremium(RiderDetails rider) {
        Amount amount = new Amount();
        if (rider.getInstalmentPremium() != null && !rider.getInstalmentPremium().isEmpty()) {
            amount.setAmount(new BigDecimal(rider.getInstalmentPremium()));
        } else {
            amount.setAmount(BigDecimal.ZERO);
        }
        amount.setCurrency(CURRENCY);
        return amount;
    }

    /**
     * retrieve AnnualPremium.
     *
     * @param rider
     * @return
     */
    private Amount retrieveAnnualPremium(RiderDetails rider) {
        Amount amount = new Amount();
        if (rider.getAnnualPremium() != null && !rider.getAnnualPremium().isEmpty()) {
            amount.setAmount(new BigDecimal(rider.getAnnualPremium()));
        } else {
            amount.setAmount(BigDecimal.ZERO);
        }
        amount.setCurrency(CURRENCY);
        return amount;
    }

    /**
     * map Product.
     *
     * @param getAccountDetailsResponse
     * @param accountId
     * @return
     */
    public Product mapProduct(GetAccountDetailsResponse getAccountDetailsResponse) {
        Product product = new Product();
        if (getAccountDetailsResponse.getAccountDetailsList() != null) {
            AccountDetailsList accountDetail = getAccountDetailsResponse.getAccountDetailsList().stream().findFirst().get();
            if (accountDetail.getProduct().getId() != null && ProductInfo.getProductmap().containsKey(accountDetail.getProduct().getId())) {
                product = ProductInfo.getProductmap().get(accountDetail.getProduct().getId());
            }
        }
        return product;
    }

    /**
     * map Relationships.
     *
     * @param getAccountDetailsResponse
     * @param getAccountInsuranceDetailsResponse
     * @return
     */
    public AccountRelationships mapRelationships(GetAccountDetailsResponse getAccountDetailsResponse) {
        APP_LOGGER.info("Mapping relationships");
        AccountRelationships accountRelationships = new AccountRelationships();
        addProducts(getAccountDetailsResponse, accountRelationships);
        addInsurances(getAccountDetailsResponse, accountRelationships);
        addOwners(getAccountDetailsResponse, accountRelationships);
        APP_LOGGER.info("Relationships mapped");
        return accountRelationships;
    }

    /**
     * Does this.
     *
     * @param getAccountDetailsResponse
     * @param accountRelationships
     */
    private void addOwners(GetAccountDetailsResponse getAccountDetailsResponse, AccountRelationships accountRelationships) {
        if (getAccountDetailsResponse.getAccountDetailsList() != null) {
            AccountDetailsList accountDetails = getAccountDetailsResponse.getAccountDetailsList().stream().findFirst().get();
            if (accountDetails.getClientAccountRelationships() != null) {
                String owner = accountDetails.getClientAccountRelationships().stream()
                        .filter(o -> o.getClientAccountRelationship().getRelationshipType().getName().equalsIgnoreCase(LBL_OWNER)).findAny().get()
                        .getClientAccountRelationship().getClient().getId();
                accountRelationships.setOwners(owner);
            }
        }
    }

    /**
     * add Insurances.
     *
     * @param getAccountInsuranceDetailsResponse
     * @param accountRelationships
     */
    private void addInsurances(GetAccountDetailsResponse getAccountDetailsResponse, AccountRelationships accountRelationships) {
        List<RiderInfo> insuranceList = mapInsurance(getAccountDetailsResponse);
        Iterator<RiderInfo> insuranceIterator = insuranceList.iterator();
        List<String> insurances = new ArrayList<>();
        while (insuranceIterator.hasNext()) {
            RiderInfo obj = insuranceIterator.next();
            insurances.add(obj.getId());
        }
        accountRelationships.setInsurances(insurances);
    }

    /**
     * add Products.
     *
     * @param getAccountDetailsResponse
     * @param accountRelationships
     */
    private void addProducts(GetAccountDetailsResponse getAccountDetailsResponse, AccountRelationships accountRelationships) {
        if (mapProduct(getAccountDetailsResponse).getId() != null) {
            String products = null;
            products = (mapProduct(getAccountDetailsResponse).getId());
            accountRelationships.setProducts(products);
        }
    }
}
