////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.util.validator.impl;

import java.util.Arrays;
import java.util.List;

import au.com.suncorp.wealth.api.common.rest.util.validator.BrandValidator;
import au.com.suncorp.insurance.domain.Brand;
import au.com.suncorp.wealth.api.common.rest.exception.InvalidBrandException;

/**
 * The class {@code SupportBrandValidator} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class SupportBrandValidator implements BrandValidator {
    private List<Brand> supportBrands;

    /**
     * Default constructor.
     *
     * @param supportBrands
     */
    public SupportBrandValidator(List<Brand> supportBrands) {
        this.supportBrands = supportBrands;
    }

    @Override
    public void validate(Brand brand) throws InvalidBrandException {
        if (!supportBrands.contains(brand)) {
            throw new InvalidBrandException("Invalid brand: " + brand.name() + ". Support brands are " + Arrays.toString(supportBrands.toArray()));
        }
    }
}
