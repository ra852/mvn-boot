////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code ProductDetails} does this.
 * 
 * @author U383754
 * @since 02/02/2016
 * @version 1.0
 */
public class ProductDetails {
    private String id;
    private String name;
    private String shortName;
    private ReferenceIdentifier productRef;
    private ReferenceIdentifier productExternalRef;
    private AuditIdentifier audit;
    private String sourceSystem;
    private String productType;
    private String productGroup;

    /**
     * Accessor for property productExternalRef.
     *
     * @return productExternalRef of type ReferenceIdentifier
     */
    public ReferenceIdentifier getProductExternalRef() {
        return productExternalRef;
    }

    /**
     * Mutator for property productExternalRef.
     *
     * @param productExternalRef of type ReferenceIdentifier
     */
    public void setProductExternalRef(ReferenceIdentifier productExternalRef) {
        this.productExternalRef = productExternalRef;
    }

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property shortName.
     * 
     * @return shortName of type String
     */
    public String getShortName() {
        return shortName;
    }

    /**
     * Mutator for property shortName.
     * 
     * @return shortName of type String
     */
    public void setShortName(String shortName) {
        this.shortName = shortName != null ? shortName : "";
    }

    /**
     * Accessor for property productRef.
     * 
     * @return productRef of type ReferenceIdentifier
     */
    public ReferenceIdentifier getProductRef() {
        return productRef;
    }

    /**
     * Mutator for property productRef.
     * 
     * @return productRef of type ReferenceIdentifier
     */
    public void setProductRef(ReferenceIdentifier productRef) {
        this.productRef = productRef;
    }

    /**
     * Accessor for property audit.
     * 
     * @return audit of type AuditIdentifier
     */
    public AuditIdentifier getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     * 
     * @return audit of type AuditIdentifier
     */
    public void setAudit(AuditIdentifier audit) {
        this.audit = audit;
    }

    /**
     * Accessor for property sourceSystem.
     * 
     * @return sourceSystem of type String
     */
    public String getSourceSystem() {
        return sourceSystem;
    }

    /**
     * Mutator for property sourceSystem.
     * 
     * @param sourceSystem of type String
     */
    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    /**
     * Accessor for property productType.
     * 
     * @return productType of type String
     */
    public String getProductType() {
        return productType;
    }

    /**
     * Mutator for property productType.
     * 
     * @param productType of type String
     */
    public void setProductType(String productType) {
        this.productType = productType != null ? productType : "";
    }

    /**
     * Accessor for property productGroup.
     * 
     * @return productGroup of type String
     */
    public String getProductGroup() {
        return productGroup;
    }

    /**
     * Mutator for property productGroup.
     * 
     * @param productGroup of type String
     */
    public void setProductGroup(String productGroup) {
        this.productGroup = productGroup != null ? productGroup : "";
    }

}
