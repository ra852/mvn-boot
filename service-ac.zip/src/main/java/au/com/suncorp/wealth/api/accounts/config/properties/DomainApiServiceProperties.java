////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.config.properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * The class {@code DomainApiServiceProperties} does this.
 *
 * @author U383754
 * @since 8Mar.,2018
 * @version 1.0
 */
@Configuration
public class DomainApiServiceProperties {
    private String productDefinitionHostName;

    @Autowired
    public DomainApiServiceProperties(Environment env) {
        productDefinitionHostName = env.getRequiredProperty("domain-api-service.product-definition-hostName");
    }

    public String getProductDefinitionHostName() {
        return productDefinitionHostName;
    }
}
