////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code SILErrorMessage} does this.
 * @author u384380
 * @since 29/10/2015
 * @version 1.0
 */
public class SILErrorMessage {
    private String errorMessage;

    /**
     * Accessor for property errorMessage.
     * @return errorMessage of type String
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * Mutator for property errorMessage.
     * @return errorMessage of type String
     */
    @XmlElement(name = "errorMessage")
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
