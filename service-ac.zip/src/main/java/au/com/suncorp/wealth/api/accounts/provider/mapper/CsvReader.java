////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.provider.mapper;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FUND_DETAIL_CSV;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FUND_NAME_EXCEPTION;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_INVALID_RESPONSE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_RUNTIME_ID;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvParser;

import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.utils.AccountUtil;

/**
 * The class {@code ExcelReader} does this.
 *
 * @author u201468
 * @since 14Feb.,2018
 * @version 1.0
 */
public class CsvReader {

    private static final ClassPathResource FUND_DETAILS = new ClassPathResource(LBL_FUND_DETAIL_CSV);
    private static final Map<String, String> FUND_MAP = new HashMap<String, String>();
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(CsvReader.class);

    public Map<String, String> readFundFromCsv() {
        final CsvMapper csvMapper = new CsvMapper();
        csvMapper.enable(CsvParser.Feature.WRAP_AS_ARRAY);
        MappingIterator<String[]> it;
        InputStream iStream = null;
        try {
            if (FUND_DETAILS != null) {
                iStream = FUND_DETAILS.getInputStream();
                it = csvMapper.readerFor(String[].class).readValues(iStream);
                while (it.hasNext()) {
                    String[] row = it.next();
                    FUND_MAP.put(row[0], row[2]);
                }
            }
        } catch (IOException e) {
            throw new AccountServiceRuntimeException(new AccountUtil().getLogId(LBL_RUNTIME_ID), LBL_INVALID_RESPONSE, LBL_FUND_NAME_EXCEPTION);
        } finally {
            if (iStream != null) {
                safeClose(iStream);
            }
        }
        return FUND_MAP;
    }

    private void safeClose(InputStream iStream) {
        try {
            if (iStream != null) {
                iStream.close();
            }
        } catch (IOException e) {
            new AccountUtil().log(APP_LOGGER, "Exception caught under finally block");
        }
    }

    public Map<String, String> csvMap() {
        if (FUND_MAP.isEmpty()) {
            return readFundFromCsv();
        } else {
            return FUND_MAP;
        }
    }
}
