////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.config.properties;

import javax.annotation.PostConstruct;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * The class {@code ApiCommonProperties} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@ConfigurationProperties(prefix = "api-common")
public class ApiCommonProperties {
    private GlobalErrorResponse globalErrorResponse;

    /**
     * Accessor for property globalErrorResponse.
     *
     * @return globalErrorResponse of type GlobalErrorResponse
     */
    public GlobalErrorResponse getGlobalErrorResponse() {
        return globalErrorResponse;
    }

    /**
     * Mutator for property globalErrorResponse.
     *
     * @param globalErrorResponse of type GlobalErrorResponse
     */
    public void setGlobalErrorResponse(GlobalErrorResponse globalErrorResponse) {
        this.globalErrorResponse = globalErrorResponse;
    }

    /**
     * The class {@code GlobalErrorResponse} does this.
     *
     * @author u201468
     * @since 9Feb.,2018
     * @version 1.0
     */
    public static class GlobalErrorResponse {
        private boolean includeCause;
        private boolean propagateHttpStatusOfHttpClientErrorException;

        public boolean isIncludeCause() {
            return includeCause;
        }

        public void setIncludeCause(boolean includeCause) {
            this.includeCause = includeCause;
        }

        public boolean isPropagateHttpStatusOfHttpClientErrorException() {
            return propagateHttpStatusOfHttpClientErrorException;
        }

        public void setPropagateHttpStatusOfHttpClientErrorException(boolean propagateHttpStatusOfHttpClientErrorException) {
            this.propagateHttpStatusOfHttpClientErrorException = propagateHttpStatusOfHttpClientErrorException;
        }
    }

    @PostConstruct
    public void postContruct() {
        if (globalErrorResponse == null) {
            globalErrorResponse = new GlobalErrorResponse();
        }
    }
}
