////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

import java.util.List;

/**
 * The class {@code GetAccountDetailsResponse} does this.
 * 
 * @author u386898
 * @since 15/12/2015
 * @version 1.0
 */
public class GetAccountDetailsResponse extends SILErrorMessage {

    private String accountNumber;
    private String externalReference;
    private String externalReferenceCode;
    private List<AccountDetailsList> accountDetails;

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Mutator for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Accessor for property externalReference.
     * 
     * @return externalReference of type String
     */
    public String getExternalReference() {
        return externalReference;
    }

    /**
     * Mutator for property externalReference.
     * 
     * @return externalReference of type String
     */
    public void setExternalReference(String externalReference) {
        this.externalReference = externalReference;
    }

    /**
     * Accessor for property externalReferenceCode.
     * 
     * @return externalReferenceCode of type String
     */

    public String getExternalReferenceCode() {
        return externalReferenceCode;
    }

    /**
     * Mutator for property externalReferenceCode.
     * 
     * @return externalReferenceCode of type String
     */
    public void setExternalReferenceCode(String externalReferenceCode) {
        this.externalReferenceCode = externalReferenceCode;
    }

    /**
     * Accessor for property accountDetailsList.
     *
     * @return accountDetailsList of type List<AccountDetailsList>
     */
    public List<AccountDetailsList> getAccountDetailsList() {
        return accountDetails;
    }

    /**
     * Mutator for property accountDetailsList.
     *
     * @param accountDetailsList of type List<AccountDetailsList>
     */
    public void setAccountDetailsList(List<AccountDetailsList> accountDetails) {
        this.accountDetails = accountDetails;
    }
}
