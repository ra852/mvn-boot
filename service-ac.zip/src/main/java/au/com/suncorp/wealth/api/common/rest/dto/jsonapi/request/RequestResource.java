////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.request;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * The class {@code RequestResource} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 * @param <T>
 */
public abstract class RequestResource<T extends Object> {
    @ApiModelProperty(value = "Data", required = true)
    @Valid
    @NotNull
    private RequestData<T> data;

    public void setData(RequestData<T> jsonApiData) {
        data = jsonApiData;
    }

    @SuppressWarnings("rawtypes")
    public RequestData getData() {
        return data;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
