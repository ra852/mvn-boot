////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code BillerConstant} does this.
 *
 * @author u201468
 * @since 19Jan.,2018
 * @version 1.0
 */
public final class BillerConstant {
    public static final String PERSONAL_CONTRIBUTION = "Personal contribution";
    public static final String PERSONAL_BILLER_CODE = "256602";
    public static final String SPOUSE_CONTRIBUTION = "Spouse contribution";
    public static final String SPOUSE_BILLER_CODE = "256628";
    public static final String EMPLOYER_SGAWARD_CONTRIBUTION = "Employer SG/Award contribution";
    public static final String EMPLOYER_SGAWARD_BILLER_CODE = "256594";
    public static final String EMPLOYER_SALARY_SACRIFICE_CONTRIBUTION = "Employer salary sacrifice contribution";
    public static final String EMPLOYER_SALARY_SACRIFICE_BILLER_CODE = "256610";
    public static final String EMPLOYER_VOLUNTARY_CONTRIBUTION = "Employer voluntary contribution";
    public static final String EMPLOYER_VOLUNTARY_BILLER_CODE = "256636";

    private BillerConstant() {
    }
}
