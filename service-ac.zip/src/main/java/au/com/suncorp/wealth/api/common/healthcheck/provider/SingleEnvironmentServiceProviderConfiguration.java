////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.healthcheck.provider;

/**
 * The class {@code SingleEnvironmentServiceProviderConfiguration} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class SingleEnvironmentServiceProviderConfiguration extends BaseServiceProviderConfiguration {
    private String healthEndpoint;

    /**
     * Parameterised constructor.
     *
     * @param downtimeEnabled
     * @param downtimePeriod
     * @param healthEndpoint
     */
    public SingleEnvironmentServiceProviderConfiguration(boolean downtimeEnabled, String downtimePeriod, String healthEndpoint) {
        super(downtimeEnabled, downtimePeriod);
        this.healthEndpoint = healthEndpoint;
    }

    /**
     * Parameterised constructor.
     *
     * @param healthEndpoint
     */
    public SingleEnvironmentServiceProviderConfiguration(String healthEndpoint) {
        this(false, "", healthEndpoint);
    }

    public String getHealthEndpoint() {
        return healthEndpoint;
    }
}
