////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.utils;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_BAD_REQUEST_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_INPUT_VALIDATION_FAILED;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_VALIDATION_FAILED;

import java.util.HashMap;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.lang.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.BindingResult;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.beanvalidation.SpringValidatorAdapter;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import au.com.suncorp.wealth.api.accounts.exception.InvalidRequestAccountRuntimeException;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import au.com.suncorp.wealth.api.accounts.rest.dto.response.AccountNumberDetailsDTO;

/**
 * The class {@code AccountNoValidation} does this.
 *
 * @author U205452
 * @since 30Mar.,2018
 * @version 1.0
 */
public class AccountNoValidation extends HandlerInterceptorAdapter {
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountNoValidation.class);

    /**
     * 
     * Does this.
     *
     * @param accountNumber
     * @param pb
     */
    public static void validateAccountNumber(String accountNumber, ParameterBean pb) {
        LOGGER.info("validateAccountNumber() - Start");
        AccountNumberDetailsDTO accountNumberDetailsDTO = new AccountNumberDetailsDTO();
        accountNumberDetailsDTO.setAccountNumber(accountNumber);

        ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
        Validator validator = validatorFactory.getValidator();

        BindingResult bindingResult = new MapBindingResult(new HashMap<>(), accountNumberDetailsDTO.getClass().getSimpleName());
        SpringValidatorAdapter springValidatorAdapter = new SpringValidatorAdapter(validator);
        springValidatorAdapter.validate(accountNumberDetailsDTO, bindingResult);
        if (bindingResult.hasErrors()) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("validateAccountNumber() - Validation fail: {}", bindingResult);
            }
            throw new InvalidRequestAccountRuntimeException(new AccountUtil().getLogId(LBL_BAD_REQUEST_ID), LBL_VALIDATION_FAILED,
                    LBL_INPUT_VALIDATION_FAILED + "_" + StringEscapeUtils.escapeHtml(accountNumber), pb);
        }
        LOGGER.info("validateAccountNumber() - Validation pass");
    }
}
