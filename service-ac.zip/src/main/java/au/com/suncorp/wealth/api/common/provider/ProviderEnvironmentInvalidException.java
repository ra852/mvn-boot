////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.provider;

import au.com.suncorp.wealth.api.common.rest.exception.BadRequestException;

/**
 * The class {@code ProviderEnvironmentInvalidException} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
public class ProviderEnvironmentInvalidException extends BadRequestException {

    /**
     * Parametrised constructor
     *
     * @param message
     */
    public ProviderEnvironmentInvalidException(String message) {
        super(message);
    }
}
