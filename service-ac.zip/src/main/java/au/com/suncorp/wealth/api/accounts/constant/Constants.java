////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.constant;

public final class Constants {
    public static final String SPRING_PROFILE_TEST = "test";
    public static final String SPRING_PROFILE_LOCAL = "local";
    public static final String SPRING_PROFILE_DEVELOPMENT = "dev";
    public static final String SPRING_PROFILE_PRODUCTION = "prod";

    public static final String SPRING_PROFILE_AXWAY_NONPROD = "axway-nonprod";
    public static final String SPRING_PROFILE_AXWAY_PROD = "axway-prod";

    public static final String REQUEST_ID_FIELD_NAME = "X-Request-Id";
    public static final String VERSION_ID_FIELD_NAME = "X-API-Version";
    public static final String AUTHORISATION_FIELD_NAME = "Authorization";
    public static final String ENTITLEMENT_ID_FIELD_NAME = "X-Entitlement-Info";
    public static final String AUTHORIZATION_PREFIX = "Bearer ";
    public static final String ACCEPT = "Accept";
    public static final String INCLUDE_REQ_PARAM = "include";
    public static final String ACCOUNT_NUMBER = "accountNumber";

    public static final String GET_ACCOUNT_DETAILS_LIST_PATH =
            "/services/account/accountservice/getaccountlistdetails?accountNumber={accountNumber}" +
                    "&includeProduct=true&includeAccountDetail=true&includeBalance=true&includeExternalReference=true" +
                    "&includeClientAccountRelationship=true&includeInsurance=true";
    public static final String GET_ACCOUNT_INSURANCE_DETAILS_PATH =
            "/services/insurance/insuranceservice/getaccountinsurancedetails?accountNumber={accountNumber}";
    public static final String GET_INVESTMENT_BALANCE_PATH = "/services/account/accountservice/getinvestmentbalance?accountNumber={accountNumber}" +
            "&skipTransactionFundGrouping=true&startDate={startDate}";
    public static final String GET_ACCOUNT_LIST_PATH = "/services/client/clientservice/getaccountlist?clientId={clientId}&includeProduct=true";
    public static final String GET_PRODUCT_DEF_URI = "/product-definition-api/product-definitions?filter[productType]=Wealth";

    public static final String LBL_ACCOUNTS = "accounts";
    public static final String LBL_INSURANCES = "insurances";
    public static final String LBL_PRODUCTS = "products";
    public static final String LBL_ID_PREFIX = "wealth_accounts_{accountNumber}";
    public static final String LBL_ACCOUNT_ID = "{accountNumber}";
    public static final String LBL_START_DATE = "{startDate}";
    public static final String LBL_UNAUTHORIZED = "Unauthorized";
    public static final String LBL_TOKEN_EXPIRED = "Token expired";
    public static final String LBL_UNSUPPORTED_JWT_TOKEN = "Unsupported JWT token";
    public static final String LBL_MALFORMED_JWT_TOKEN = "Malformed JWT token";
    public static final String LBL_INVALID_TOKEN = "Invalid token";
    public static final String LBL_FORBIDDEN = "Forbidden";
    public static final String LBL_TOKEN_VAL_FAILED = "Token validation failed";
    public static final String LBL_INVALID_RESPONSE = "Invalid response";
    public static final String LBL_FAILED_GET_ACC_DET_RES = "Failed to get account details from backend Service";
    public static final String LBL_FAILED_ACC_INS_RES = "Failed to get account details from backend Service";
    public static final String LBL_FAILED_PRODUCT_RESPONSE = "Failed to get account details from backend Service";
    public static final String LBL_IDENTITY_NOT_FOUND = "IdentityNotFoundException";
    public static final String LBL_NO_ACC_FOUND = "No Account(s) Found";
    public static final String LBL_NO_ACC_MAPPED = "Cannot find specified account";
    public static final String LBL_INVALID_REQUEST = "Invalid Request";
    public static final String LBL_NO_TRANSACTION = "No transactions found for the given account";
    public static final String LBL_COULD_NOT_PROCESSED = "GetInvestmentBalance response could not be processed.";
    public static final String LBL_NO_BPAY_FOUND = "This account number does not contain any BPAY data.";
    public static final String CURRENCY = "AUD";
    public static final String LBL_IN_FORCE = "In Force";
    public static final String LBL_FUND_NAME_EXCEPTION = "Unable to retrieve Fund Name";
    public static final String LBL_FUND_DETAIL_CSV = "fund_details.csv";
    public static final String LBL_CLIENT_ID = "{clientId}";
    public static final String LBL_JWT_AUTH = "jwt_auth";
    public static final String LBL_NO_CLIENT_DETAIL = "ClientId: {clientId} is not present in source system";
    public static final String LBL_NO_ACC_EXISTS = "No Account Exists for the Given Client";
    public static final String LBL_NO_ACC_DETAIL = "ClientId: {clientId} doesn't have any account mapped.";
    public static final String LBL_TITLE_INVALID_RES = "Client not present";
    public static final String LBL_TITLE_NO_ACC_EXISTS = "No account exist";
    public static final String LBL_TITLE_INVALID_REQ = "Invalid Request";
    public static final String LBL_INVALID_DEP_REQ_DETAIL = "Invalid dependent service request";
    public static final String LBL_FAILED_RES_DETAIL = "Failed to get details from source system";
    public static final String LBL_DOMAIN = "SNT";
    public static final String LBL_SEPERATOR = ":";
    public static final String LBL_DATA_PARTY_REF = "data.partyRefs";
    public static final String LBL_SIGNING_KEY = "d2h5";
    public static final String LBL_WEALTH_CLIENT_ABSENT = "Wealth client identifier not present";
    public static final String LBL_BPAY = "BPAY";
    public static final String BACKEND_SERVER_UNAVAILABLE = "Backend services are not available";
    public static final String LBL_OWNER = "Owner";
    public static final String LBL_FUND_ID = "41000001";
    public static final String LBL_BLANK = "";
    public static final String LBL_NO_PRODUCT_DEF_RES = "No Product Definition data found in response";
    public static final String LBL_NO_PRODUCT_DEF_DET_RES = "No Product Definition data found in response";
    public static final String LBL_FAILED_PRODUCT_DEF_RES = "Failed to get product definition response from Service";
    public static final String LBL_DATA = "data";
    public static final String LBL_ATTRIBUTES = "attributes";
    public static final String LBL_PRODUCT_SYS_SUB_CODE = "productSystemProductSubCode";
    public static final String LBL_MP_PRODUCT_TYPE = "marketplaceProductType";
    public static final String LBL_PRODUCT_SYS_CODE = "productSystemCode";
    public static final String LBL_PRODUCT_SYS_PRODUCT_CODE = "productSystemProductCode";
    public static final String LBL_PRODUCT_DEF_DOMAIN = "domain";
    public static final String LBL_DESCRIPTION = "description";
    public static final String LBL_BRAND = "brand";
    public static final String LBL_ID = "id";
    public static final String LBL_PARAMETERS = "parameters";
    public static final String LBL_PARSE = "Unable to convert to RSA public key";
    public static final String LBL_PRODUCT_SYS_ID = "productSystemId";
    public static final String LBL_PRODUCT_SYS_PARTY_ID = "productSystemPartyId";
    public static final String LBL_VALIDATION_FAILED = "Bad input";
    public static final String LBL_INPUT_VALIDATION_FAILED = "Bad input parameter";
    public static final String LBL_PRODUCT_SYSTEM_PARTY_ID = "productSystemPartyId";
    public static final String LBL_OWNER_CODE = "OWNR";
    public static final String X_CHANNEL_INFO_FIELD_NAME = "X-Channel-Info";
    public static final String LBL_RUNTIME_ID = "ERR01";
    public static final String LBL_UNAUTHORIZED_ID = "ERR02";
    public static final String LBL_FORBIDDEN_ID = "ERR03";
    public static final String LBL_BAD_REQUEST_ID = "ERR04";
    public static final String LBL_NOT_FOUND_ID = "ERR05";
    public static final String LBL_TOTAL_OPENING_BAL = "totalOpeningBalance";
    public static final String LBL_TOTAL_CLOSING_BAL = "totalClosingBalance";
    public static final String LBL_CLOSING_BAL_AMT = "closingBalanceAmount";
    public static final String LBL_CLOSING_PRICE = "closingPrice";
    public static final String LBL_CLOSING_UNITS = "closingUnits";
    public static final String LBL_FUND_NAME = "fundFullName";
    public static final String LBL_OPENING_BAL_AMT = "openingBalanceAmount";
    public static final String LBL_OPENING_PRICE = "openingPrice";
    public static final String LBL_OPENING_UNITS = "openingUnits";
    public static final String LBL_PERCENTAGE = "percentage";
    public static final String LBL_UNIT_PRICE_EFF_DATE = "unitPriceEffectiveDate";
    public static final String LBL_ERROR_MSG = "errorMessage";
    public static final String LBL_GET_INVESTMENT_BAL = "GetInvestmentBalanceResponse";
    public static final String GET_ACCOUNT_DETAILS_RESPONSE = "GetAccountDetailsResponse";
    public static final String ERROR_MESSAGE = "errorMessage";
    public static final String ACCOUNT = "account";
    public static final String ACCOUNT_DETAIL = "accountDetail";
    public static final String EXTERNAL_REFERENCES = "externalReferences";
    public static final String ACCOUNT_BALANCE = "accountBalance";
    public static final String INSURANCES = "insurances";
    public static final String PRODUCT = "product";
    public static final String CLIENT_ACCOUNT_RELATIONSHIPS = "clientAccountRelationships";
    public static final String CLIENT_ACCOUNT_RELATIONSHIP = "clientAccountRelationship";
    public static final String CLIENT = "client";
    public static final String RELATIONSHIP_TYPE = "relationshipType";
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String LAST_RENEWAL_DATE = "lastRenewalDate";
    public static final String BENEFIT_PERIOD = "benefitPeriod";
    public static final String WAIT_PERIOD = "waitPeriod";
    public static final String ANNUAL_PREMIUM = "annualPremium";
    public static final String INSTALMENT_PREMIUM = "instalmentPremium";
    public static final String SUM_INSURED = "sumInsured";
    public static final String STATUS = "status";
    public static final String REFERENCE = "reference";
    public static final String REFERENCE_CODE = "referenceCode";
    public static final String COMMENCEMENT_DATE = "commencementDate";
    public static final String STATUS_CODE = "statusCode";
    public static final String CODE_SHORT_DESCRIPTION = "codeShortDescription";
    public static final String RISK_TERM_AGE = "riskTermAge";
    public static final String CODE = "code";
    public static final String ACCOUNT_NO = "accountNo";
    public static final String FALIED_RES_HEALTH_MSG = "Failed to get details from health checker";
    public static final String HEALTH = "health";
    public static final String RIDER_TEMPLATE_DETAILS = "riderTemplateDetails";
    public static final String RIDER_TYPE = "riderType";

    /**
     * Default Constructor.
     */
    private Constants() {
    }
}
