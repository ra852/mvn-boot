////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code CodeIdentifier} does this.
 * 
 * @author U383847
 * @since 25/01/2016
 * @version 1.0
 */
public class CodeIdentifier {
    private String id;
    private String code;
    private String codeType;
    private String codeDescription;
    private String codeShortDescription;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property code.
     * 
     * @return code of type String
     */
    public String getCode() {
        return code;
    }

    /**
     * Mutator for property code.
     * 
     * @param code of type String
     */
    public void setCode(String code) {
        this.code = code != null ? code : "";
    }

    /**
     * Accessor for property codeType.
     * 
     * @return codeType of type String
     */
    public String getCodeType() {
        return codeType;
    }

    /**
     * Mutator for property codeType.
     * 
     * @param codeType of type String
     */
    public void setCodeType(String codeType) {
        this.codeType = codeType != null ? codeType : "";
    }

    /**
     * Accessor for property codeDescription.
     * 
     * @return codeDescription of type String
     */
    public String getCodeDescription() {
        return codeDescription;
    }

    /**
     * Mutator for property codeDescription.
     * 
     * @param codeDescription of type String
     */
    public void setCodeDescription(String codeDescription) {
        this.codeDescription = codeDescription != null ? codeDescription : "";
    }

    /**
     * Accessor for property codeShortDescription.
     * 
     * @return codeShortDescription of type String
     */
    public String getCodeShortDescription() {
        return codeShortDescription;
    }

    /**
     * Mutator for property codeShortDescription.
     * 
     * @param codeShortDescription of type String
     */
    public void setCodeShortDescription(String codeShortDescription) {
        this.codeShortDescription = codeShortDescription != null ? codeShortDescription : "";
    }
}
