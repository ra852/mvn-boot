////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.links;

/**
 * The class {@code SelfLinks} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public interface SelfLinks extends Links {

    String getSelf();

    void setSelf(String self);

}
