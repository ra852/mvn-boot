////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.common.filter;

import java.io.IOException;
import java.util.regex.Pattern;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import au.com.suncorp.wealth.api.common.constant.CommonConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.access.AccessDeniedHandlerImpl;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * The class {@code StatelessCsrfFilter} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class StatelessCsrfFilter extends OncePerRequestFilter {
    protected static final String XSRF_TOKEN = "XSRF-TOKEN";
    protected static final String X_XSRF_TOKEN = "X-XSRF-TOKEN";
    protected static final String MISSING_OR_NON_MATCHING_XSRF_TOKEN = "Missing or non-matching XSRF-TOKEN";

    private static final String PATH_MAPPING = CommonConstants.REST_BASE_URL_PATTERN + "/**";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final RequestMatcher requireCsrfProtectionMatcher = new DefaultRequiresXsrfMatcher();
    private final AccessDeniedHandler accessDeniedHandler = new AccessDeniedHandlerImpl();

    /**
     * Does this.
     *
     * @param request
     * @param response
     * @param filterChain
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String servletPath = request.getServletPath();

        logger.debug("doFilter() - servletPath=" + servletPath);

        if (requireCsrfProtectionMatcher.matches(request) && isPathMatched(servletPath)) {
            final String xsrfTokenValue = request.getHeader(X_XSRF_TOKEN);
            String xsrfCookieValue = getXsrfCookieValue(request.getCookies());

            if (xsrfTokenValue == null || !xsrfTokenValue.equals(xsrfCookieValue)) {
                accessDeniedHandler.handle(request, response, new AccessDeniedException(MISSING_OR_NON_MATCHING_XSRF_TOKEN));
                return;
            }
        }

        filterChain.doFilter(request, response);
    }

    /**
     * Does this.
     *
     * @param path
     * @return
     */
    private boolean isPathMatched(String path) {
        if (path != null) {
            AntPathMatcher matcher = new AntPathMatcher();

            if (matcher.match(PATH_MAPPING, path)) {
                return true;
            }
        }

        return false;
    }

    /**
     * get xsrf cookie value.
     *
     * @param cookies
     * @return
     */
    private String getXsrfCookieValue(Cookie[] cookies) {
        String xsrfCookieValue = null;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(XSRF_TOKEN)) {
                    xsrfCookieValue = cookie.getValue();
                }
            }
        }

        return xsrfCookieValue;
    }

    public static final class DefaultRequiresXsrfMatcher implements RequestMatcher {
        private final Pattern allowedMethods = Pattern.compile("^(GET|HEAD|TRACE|OPTIONS)$");

        @Override
        public boolean matches(HttpServletRequest request) {
            return !allowedMethods.matcher(request.getMethod()).matches();
        }
    }
}
