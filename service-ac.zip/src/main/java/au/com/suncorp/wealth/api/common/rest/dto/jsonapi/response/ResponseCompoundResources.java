////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.links.Links;
import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code ResponseCompoundResources} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 * @param <T>
 * @param <V>
 * @param <Z>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "data", "included" })
public abstract class ResponseCompoundResources<T extends Object, V extends Object, Z extends Object> extends ResponseBase {
    @ApiModelProperty(value = "Data", required = false)
    private List<ResponseCompoundData<T, V>> data = null;

    @ApiModelProperty(value = "Included resources", required = false)
    private List<ResponseData<Z>> included;

    private Links links;

    public List<ResponseCompoundData<T, V>> getData() {
        return data;
    }

    public void setData(List<ResponseCompoundData<T, V>> data) {
        this.data = data;
    }

    public void addData(ResponseCompoundData<T, V> data) {
        if (this.data == null) {
            this.data = new ArrayList<>();
        }

        this.data.add(data);
    }

    public List<ResponseData<Z>> getIncluded() {
        return included;
    }

    public void addIncluded(ResponseData<Z> data) {
        if (this.included == null) {
            this.included = new ArrayList<>();
        }

        included.add(data);
    }

    public void setIncluded(List<ResponseData<Z>> included) {
        this.included = included;
    }

    public Links getLinks() {
        return links;
    }

    public void setLinks(Links links) {
        this.links = links;
    }
}
