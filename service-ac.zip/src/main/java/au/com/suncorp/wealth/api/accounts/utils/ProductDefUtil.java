////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.utils;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.BACKEND_SERVER_UNAVAILABLE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.GET_PRODUCT_DEF_URI;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_ATTRIBUTES;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_BRAND;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_DATA;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_DESCRIPTION;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FAILED_ACC_INS_RES;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_MP_PRODUCT_TYPE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_PARAMETERS;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_PRODUCT_DEF_DOMAIN;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_PRODUCT_SYS_CODE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_PRODUCT_SYS_PRODUCT_CODE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_PRODUCT_SYS_SUB_CODE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_RUNTIME_ID;
import static au.com.suncorp.wealth.api.common.constant.CommonConstants.APPLICATION_JSON_API_VALUE;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;

import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.exception.handler.AccountServiceErrorHandler;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import au.com.suncorp.wealth.api.accounts.model.Product;
import au.com.suncorp.wealth.api.accounts.rest.DomainApiService;
import net.jodah.expiringmap.ExpiringMap;

/**
 * The class {@code PortfolioUtil} does this.
 *
 * @author U383754
 * @since 7Mar.,2018
 * @version 1.0
 */
public class ProductDefUtil extends AccountUtil {
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(ProductDefUtil.class);

    /**
     * Does this.
     *
     * @param restTemplate
     * @param accountServiceProperties
     * @return
     */
    public Map<String, Product> callPortfolioService(RestTemplate restTemplate, DomainApiService domainApiService, String accountNumber,
            ParameterBean pb) {
        return getProductDefData(restTemplate, domainApiService, accountNumber, pb);
    }

    /**
     * Does this.
     *
     * @param restTemplate
     * @param domainApiService
     * @param productDefDataMap
     */
    private Map<String, Product> getProductDefData(RestTemplate restTemplate, DomainApiService domainApiService, String accountNumber,
            ParameterBean pb) {
        ResponseEntity<JsonNode> responseEntity = callProductDefAndGetResponse(restTemplate, domainApiService, accountNumber, pb);
        return prepareProductDefMap(responseEntity);
    }

    /**
     * Does this.
     *
     * @param productDefDataMapgit
     * @param response
     */
    private Map<String, Product> prepareProductDefMap(ResponseEntity<JsonNode> responseEntity) {
        Map<String, Product> productDefDataMap = ExpiringMap.builder().expiration(24, TimeUnit.HOURS).build();
        JsonNode response = responseEntity.getBody();
        if (response != null && response.isArray()) {
            for (final JsonNode objNode : response) {
                Product p = new Product();
                if (objNode.hasNonNull(LBL_DATA)) {
                    JsonNode dataNode = objNode.get(LBL_DATA);
                    createAndPutDataInMap(productDefDataMap, p, dataNode);
                }
            }
            log(APP_LOGGER, new StringBuilder("Product Subcode Map : ").append(productDefDataMap).toString());
        }
        return productDefDataMap;
    }

    /**
     * Does this.
     *
     * @param productDefDataMap
     * @param p
     * @param dataNode
     */
    private void createAndPutDataInMap(Map<String, Product> productDefDataMap, Product p, JsonNode dataNode) {
        setId(p, dataNode);
        setAttributes(productDefDataMap, p, dataNode);
    }

    private void setId(Product p, JsonNode dataNode) {
        if (dataNode.hasNonNull(LBL_ID)) {
            p.setId(String.valueOf(dataNode.get(LBL_ID)).split("\\.")[0]);
        }
    }

    private void setAttributes(Map<String, Product> productDefDataMap, Product p, JsonNode dataNode) {
        if (dataNode.hasNonNull(LBL_ATTRIBUTES)) {
            JsonNode attributesNode = dataNode.get(LBL_ATTRIBUTES);
            setBrand(p, attributesNode);
            setDescription(p, attributesNode);
            setDomain(p, attributesNode);
            setProductSystemProductCode(p, attributesNode);
            setProductSystemCode(p, attributesNode);
            setMarketplaceProductType(p, attributesNode);
            setProductSystemProductSubCode(productDefDataMap, p, attributesNode);
            prepareMap(productDefDataMap, p, attributesNode);
        }
    }

    /**
     * Does this.
     *
     * @param productDefDataMap
     * @param p
     * @param attributesMap
     */
    private void prepareMap(Map<String, Product> productDefDataMap, Product p, JsonNode attributesNode) {
        if (attributesNode.hasNonNull(LBL_PRODUCT_SYS_SUB_CODE)) {
            String productSystemProductSubCode = attributesNode.get(LBL_PRODUCT_SYS_SUB_CODE).asText();
            productDefDataMap.put(productSystemProductSubCode, p);
        }
    }

    /**
     * Does this.
     *
     * @param productDefDataMap
     * @param p
     * @param attributesNode
     */
    private void setProductSystemProductSubCode(Map<String, Product> productDefDataMap, Product p, JsonNode attributesNode) {
        if (attributesNode.hasNonNull(LBL_PRODUCT_SYS_SUB_CODE)) {
            p.setProductSystemProductSubCode(attributesNode.get(LBL_PRODUCT_SYS_SUB_CODE).asText());
        }
    }

    /**
     * Does this.
     *
     * @param p
     * @param attributesNode
     */
    private void setMarketplaceProductType(Product p, JsonNode attributesNode) {
        if (attributesNode.hasNonNull(LBL_MP_PRODUCT_TYPE)) {
            p.setMarketplaceProductType(attributesNode.get(LBL_MP_PRODUCT_TYPE).asText());
        }
    }

    /**
     * Does this.
     *
     * @param p
     * @param attributesNode
     */
    private void setProductSystemCode(Product p, JsonNode attributesNode) {
        if (attributesNode.hasNonNull(LBL_PRODUCT_SYS_CODE)) {
            p.setProductSystemCode(attributesNode.get(LBL_PRODUCT_SYS_CODE).asText());
        }
    }

    /**
     * Does this.
     *
     * @param p
     * @param attributesNode
     */
    private void setProductSystemProductCode(Product p, JsonNode attributesNode) {
        if (attributesNode.hasNonNull(LBL_PRODUCT_SYS_PRODUCT_CODE)) {
            p.setProductSystemProductCode(attributesNode.get(LBL_PRODUCT_SYS_PRODUCT_CODE).asText());
        }
    }

    /**
     * Does this.
     *
     * @param p
     * @param attributesNode
     */
    private void setDomain(Product p, JsonNode attributesNode) {
        if (attributesNode.hasNonNull(LBL_PRODUCT_DEF_DOMAIN)) {
            p.setDomain(attributesNode.get(LBL_PRODUCT_DEF_DOMAIN).asText());
        }
    }

    /**
     * Does this.
     *
     * @param p
     * @param attributesNode
     */
    private void setDescription(Product p, JsonNode attributesNode) {
        if (attributesNode.hasNonNull(LBL_DESCRIPTION)) {
            p.setDescription(attributesNode.get(LBL_DESCRIPTION).asText());
        }
    }

    /**
     * Does this.
     *
     * @param p
     * @param attributesNode
     */
    private void setBrand(Product p, JsonNode attributesNode) {
        if (attributesNode.hasNonNull(LBL_BRAND)) {
            p.setBrand(attributesNode.get(LBL_BRAND).asText());
        }
    }

    /**
     * Does this.
     *
     * @param restTemplate
     * @param domainApiService
     * @return
     */
    private ResponseEntity<JsonNode> callProductDefAndGetResponse(RestTemplate restTemplate, DomainApiService domainApiService, String accountNumber,
            ParameterBean pb) {
        String formattedUrl = domainApiService.getProductDefinitionHostName() + GET_PRODUCT_DEF_URI;
        log(APP_LOGGER, new StringBuilder("Calling portfolio service : ").append(formattedUrl).toString());
        HttpEntity<String> httpEntity = prepareDomainApiServiceHeader();
        restTemplate.setErrorHandler(new AccountServiceErrorHandler());
        try {
            ResponseEntity<JsonNode> responseEntity = restTemplate.exchange(formattedUrl, HttpMethod.GET, httpEntity, JsonNode.class);
            return responseEntity;
        } catch (ResourceAccessException e) {
            throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), BACKEND_SERVER_UNAVAILABLE, LBL_FAILED_ACC_INS_RES, pb);
        }
    }

    /**
     * Does this.
     *
     * @return
     */
    private HttpEntity<String> prepareDomainApiServiceHeader() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.set(HttpHeaders.ACCEPT, APPLICATION_JSON_API_VALUE);
        HttpEntity<String> httpEntity = new HttpEntity<String>(LBL_PARAMETERS, headers);
        return httpEntity;
    }
}
