////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.context;

import org.slf4j.MDC;

/**
 * The class {@code RequestContextHolder} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public final class RequestContextHolder {

    private static final InheritableThreadLocal<RequestContext> REQUEST_CONTEXT_THREAD_LOCAL = new InheritableThreadLocal<>();

    /**
     * Default constructor.
     */
    private RequestContextHolder() {
    }

    public static RequestContext get() {
        return REQUEST_CONTEXT_THREAD_LOCAL.get();
    }

    public static void set(RequestContext requestContext) {
        REQUEST_CONTEXT_THREAD_LOCAL.set(requestContext);

        if (requestContext != null) {
            setMDC(requestContext);
        }
    }

    public static void clear() {
        REQUEST_CONTEXT_THREAD_LOCAL.remove();
        clearMDC();
    }

    private static void setMDC(RequestContext requestContext) {
        for (String key : requestContext.getContextKeys()) {
            MDC.put(key, requestContext.getContext(key));
        }
    }

    public static void clearMDC() {
        MDC.clear();
    }
}
