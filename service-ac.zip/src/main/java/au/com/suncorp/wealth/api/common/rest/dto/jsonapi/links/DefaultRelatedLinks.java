////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.links;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.MoreObjects;

/**
 * The class {@code DefaultRelatedLinks} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DefaultRelatedLinks implements RelatedLinks {

    private String related;

    /**
     * Parameterised constructor.
     *
     * @param related
     */
    public DefaultRelatedLinks(String related) {
        this.related = related;
    }

    @Override
    public String getRelated() {
        return related;
    }

    @Override
    public void setRelated(String related) {
        this.related = related;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DefaultRelatedLinks that = (DefaultRelatedLinks) o;
        return Objects.equals(related, that.related);
    }

    @Override
    public int hashCode() {
        return Objects.hash(related);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("related", related)
                .toString();
    }
}
