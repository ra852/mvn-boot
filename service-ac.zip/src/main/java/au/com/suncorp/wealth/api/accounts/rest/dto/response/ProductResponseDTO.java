////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.rest.dto.response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude;

import au.com.suncorp.wealth.api.accounts.cache.ProductDefCacheData;
import au.com.suncorp.wealth.api.accounts.enums.ProductDefinition;
import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import au.com.suncorp.wealth.api.accounts.model.Product;
import au.com.suncorp.wealth.api.accounts.rest.DomainApiService;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response.ResponseCompoundData;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response.ResponseCompoundResource;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response.ResponseData;

/**
 * The class {@code ProductResponseDTO} does this.
 *
 * @author u201468
 * @since 22Jan.,2018
 * @version 1.0
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ProductResponseDTO extends ResponseCompoundResource<Product, Object, Product> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProductResponseDTO.class);
    private static final String PRODUCT_RESOURCE = "products";
    private static final String PRODUCTS_DEF_RESOURCE = "productDefinition";

    /**
     * parameterised constructor.
     *
     * @param product
     */
    public ProductResponseDTO(Product product, ParameterBean pb, RestTemplate restTemplate, DomainApiService domainApiService, String accountNumber) {
        ResponseCompoundData<Product, Object> data = new ResponseCompoundData<Product, Object>(PRODUCT_RESOURCE, product.getId(), product);
        setData(data);
        if (pb.getIncludeParams() != null && !pb.getIncludeParams().isEmpty() &&
                pb.getIncludeParams().contains(ProductDefinition.productDefinition)) {
            String productId = product.getId();
            try {
                Product productDefData =
                        new ProductDefCacheData().getProductDefinitionDetails(restTemplate, domainApiService, productId, accountNumber, pb);
                ResponseData<Product> productDefResData = new ResponseData<Product>(PRODUCTS_DEF_RESOURCE, productDefData.getId(), productDefData);
                addIncluded(productDefResData);
            } catch (AccountServiceRuntimeException ae) {
                LOGGER.info("Exception while calling Product Definition service");
            }
        }
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
