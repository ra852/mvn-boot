////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountNumbers} is a pure java bean consisting of properties related to GetAccountList's response.
 * 
 * @author U385424
 * @since 16/11/2015
 * @version 1.0
 */
public class AccountNumbers {
    private String accountNumber;
    private String productName;
    private String accountBalance;
    private ProductDetails productDetails;
    private CodeIdentifier status;

    /**
     * Accessor for property accountNumber.
     * 
     * @return code of type String
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Mutator for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    @XmlElement(name = "accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Accessor for property productName.
     * 
     * @return productName of type String
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Mutator for property productName.
     * 
     * @return codeType of type String
     */
    @XmlElement(name = "productName")
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * Accessor for property accountBalance.
     * 
     * @return accountBalance of type String
     */
    public String getAccountBalance() {
        return accountBalance;
    }

    /**
     * Mutator for property accountBalance.
     * 
     * @param accountBalance of type String
     */
    @XmlElement(name = "accountBalance")
    public void setAccountBalance(String accountBalance) {
        this.accountBalance = accountBalance;
    }

    /**
     * Accessor for property productDetails.
     * 
     * @return productDetails of type ProductDetails
     */
    public ProductDetails getProductDetails() {
        return productDetails;
    }

    /**
     * Mutator for property productDetails.
     * 
     * @param productDetails of type ProductDetails
     */
    @XmlElement(name = "productDetails")
    public void setProductDetails(ProductDetails productDetails) {
        this.productDetails = productDetails;
    }

    /**
     * Accessor for property status.
     * 
     * @return status of type CodeIdentifier
     */
    public CodeIdentifier getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     * 
     * @param status of type CodeIdentifier
     */
    @XmlElement(name = "status")
    public void setStatus(CodeIdentifier status) {
        this.status = status;
    }
}
