////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.utils;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_ACCOUNT_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_BAD_REQUEST_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FAILED_GET_ACC_DET_RES;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_IDENTITY_NOT_FOUND;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_INVALID_REQUEST;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_INVALID_RESPONSE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_NOT_FOUND_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_NO_ACC_FOUND;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_NO_ACC_MAPPED;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_RUNTIME_ID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;

import au.com.suncorp.wealth.api.accounts.config.properties.AccountServiceProperties;
import au.com.suncorp.wealth.api.accounts.constant.Constants;
import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.exception.InvalidRequestAccountRuntimeException;
import au.com.suncorp.wealth.api.accounts.exception.NotFoundAccountRuntimeException;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetAccountDetailsResponse;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetAccountListDetailsResponseWrapperBean;

/**
 * The class {@code GetAccountDetailsUtil} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class GetAccountDetailsUtil extends AccountUtil {
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(GetAccountDetailsUtil.class);

    /**
     * Calls Sil service.
     *
     * @param restTemplate
     * @param accountServiceProperties
     * @param accountNumber
     * @param pb
     * @return
     */
    public GetAccountDetailsResponse callAccountDetailsService(RestTemplate restTemplate, AccountServiceProperties accountServiceProperties,
            String accountNumber, ParameterBean pb) {
        log(APP_LOGGER, new StringBuilder("Entering callAccountDetailsService() -> ").append(accountNumber).toString());
        final String accountDetailendpoint = accountServiceProperties.getHostName() + Constants.GET_ACCOUNT_DETAILS_LIST_PATH;
        String formattedUrl = accountDetailendpoint.replace(LBL_ACCOUNT_ID, accountNumber);
        log(APP_LOGGER, new StringBuilder("Calling SIL service: ").append(accountDetailendpoint).toString());
        try {
            ResponseEntity<JsonNode> responseEntity =
                    retrieveBackendServiceResponse(restTemplate, accountServiceProperties, formattedUrl, accountNumber, pb);
            return getSilResponse(accountNumber, responseEntity, pb);
        } catch (RestClientException rce) {
            throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), LBL_INVALID_RESPONSE, LBL_FAILED_GET_ACC_DET_RES, pb);
        }
    }

    /**
     * Get Sil response.
     *
     * @param accountNumber
     * @param responseEntity
     * @param pb
     * @return
     */
    private GetAccountDetailsResponse getSilResponse(String accountNumber, ResponseEntity<JsonNode> responseEntity, ParameterBean pb) {
        log(APP_LOGGER, new StringBuilder("Entering getSilResponse() -> ").append(accountNumber).toString());
        GetAccountListDetailsResponseWrapperBean accountResponseJavaObj =
                parseJsonToObj(responseEntity, accountNumber, pb, GetAccountListDetailsResponseWrapperBean.class);
        GetAccountDetailsResponse getAccountDetailsResponse = accountResponseJavaObj.getGetAccountDetailsResponse();
        return checkAndVerifySilResponse(getAccountDetailsResponse, responseEntity, accountNumber, pb);
    }

    /**
     * Check and verify Sil Response.
     *
     * @param getAccountDetailsResponse
     * @param responseEntity
     * @param accountNumber
     * @param pb
     * @return
     */
    private GetAccountDetailsResponse checkAndVerifySilResponse(GetAccountDetailsResponse getAccountDetailsResponse,
            ResponseEntity<JsonNode> responseEntity, String accountNumber, ParameterBean pb) {
        log(APP_LOGGER, new StringBuilder("Verifying SIL response -> ").append(accountNumber).toString());
        if (checkSilErrors(getAccountDetailsResponse)) {
            String silError = getAccountDetailsResponse.getErrorMessage();
            log(APP_LOGGER, new StringBuilder("SIL Error Message: ").append(silError).toString());
            if (silError != null && silError.contains(LBL_IDENTITY_NOT_FOUND)) {
                throw new NotFoundAccountRuntimeException(getLogId(LBL_NOT_FOUND_ID), LBL_NO_ACC_FOUND, LBL_NO_ACC_MAPPED, pb);
            } else if (400 == responseEntity.getStatusCodeValue()) {
                throw new InvalidRequestAccountRuntimeException(getLogId(LBL_BAD_REQUEST_ID), LBL_INVALID_REQUEST, LBL_INVALID_REQUEST, pb);
            } else if (silError != null && !silError.contains(LBL_IDENTITY_NOT_FOUND)) {
                throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), LBL_INVALID_REQUEST, LBL_FAILED_GET_ACC_DET_RES, pb);
            } else {
                throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), LBL_INVALID_RESPONSE, LBL_FAILED_GET_ACC_DET_RES, pb);
            }
        } else {
            log(APP_LOGGER, new StringBuilder("No error message found in SIL response -> ").append(accountNumber).toString());
            log(APP_LOGGER, new StringBuilder("Get account details response for ").append(accountNumber).append(" ").append(getAccountDetailsResponse)
                    .toString());
            return getAccountDetailsResponse;
        }
    }

    /**
     * Does this.
     *
     * @param getAccountDetailsResponse
     * @return
     */
    private boolean checkSilErrors(GetAccountDetailsResponse getAccountDetailsResponse) {
        return getAccountDetailsResponse != null && getAccountDetailsResponse.getErrorMessage() != null;
    }
}
