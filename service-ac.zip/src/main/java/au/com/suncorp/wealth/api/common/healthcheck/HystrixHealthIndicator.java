////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.common.healthcheck;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;

import com.netflix.hystrix.HystrixCircuitBreaker;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandKey;
import com.netflix.hystrix.HystrixCommandMetrics;

/**
 * The class {@code HystrixHealthIndicator} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class HystrixHealthIndicator extends org.springframework.cloud.netflix.hystrix.HystrixHealthIndicator {
    private static final Status HYSTRIX_DISABLED = new Status("DISABLED");
    private static final String OPEN_CIRCUIT_BREAKERS = "openCircuitBreakers";
    private static final String CLOSED_CIRCUIT_BREAKERS = "closedCircuitBreakers";

    @Value("${spring.cloud.circuit.breaker.enabled:false}")
    private boolean hystrixEnabled;

    /**
     * Does health check.
     *
     * @param builder
     * @throws Exception
     */
    @Override
    protected void doHealthCheck(Health.Builder builder) throws Exception {
        List<String> openCircuitBreakers = new ArrayList<String>();
        List<String> closeCircuitBreakers = new ArrayList<String>();

        // Collect all open circuit breakers from Hystrix
        for (HystrixCommandMetrics metrics : HystrixCommandMetrics.getInstances()) {
            HystrixCommandGroupKey commandGroup = metrics.getCommandGroup();
            HystrixCommandKey commandKey = metrics.getCommandKey();
            HystrixCircuitBreaker circuitBreaker = HystrixCircuitBreaker.Factory.getInstance(commandKey);

            String commandGroupKeyName = commandGroup.name() + "::" + commandKey.name();

            if (circuitBreaker.isOpen()) {
                openCircuitBreakers.add(commandGroupKeyName);
            } else {
                closeCircuitBreakers.add(commandGroupKeyName);
            }
        }

        buildStatus(builder, closeCircuitBreakers, openCircuitBreakers);
    }

    /**
     * Build status.
     *
     * @param builder
     * @param closeCircuitBreakers
     * @param openCircuitBreakers
     */
    private void buildStatus(Health.Builder builder, List<String> closeCircuitBreakers, List<String> openCircuitBreakers) {
        if (!hystrixEnabled) {
            builder.status(HYSTRIX_DISABLED);
        } else {
            // If there is at least one open circuit report OUT_OF_SERVICE
            if (!openCircuitBreakers.isEmpty()) {
                builder.outOfService();
            } else {
                builder.up();
            }

            // Show closed circuit breakers
            if (!closeCircuitBreakers.isEmpty()) {
                builder.withDetail(CLOSED_CIRCUIT_BREAKERS, closeCircuitBreakers);
            }

            // Show open circuit breakers
            if (!openCircuitBreakers.isEmpty()) {
                builder.withDetail(OPEN_CIRCUIT_BREAKERS, openCircuitBreakers);
            }
        }
    }
}
