////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model;

import org.beanio.annotation.Record;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code BillerCode} does this.
 *
 * @author u201468
 * @since 17Jan.,2018
 * @version 1.0
 */
@Record(minOccurs = 1, name = "BillerCode")
@JsonInclude(Include.NON_EMPTY)
public class BillerCode {
    @ApiModelProperty(position = 1, example = "Personal contribution")
    private String bpayContributionType;
    @ApiModelProperty(position = 2, example = "256602")
    private String billerCode;

    /**
     * Default constructor.
     *
     */
    public BillerCode() {
    }

    /**
     * Does this.
     *
     * @param bpayContributionType
     * @param billerCode
     */
    public BillerCode(String bpayContributionType, String billerCode) {
        super();
        this.bpayContributionType = bpayContributionType;
        this.billerCode = billerCode;
    }

    /**
     * Accessor for property bpayContributionType.
     *
     * @return bpayContributionType of type String
     */
    public String getBpayContributionType() {
        return bpayContributionType;
    }

    /**
     * Mutator for property bpayContributionType.
     *
     * @param bpayContributionType of type String
     */
    public void setBpayContributionType(String bpayContributionType) {
        this.bpayContributionType = bpayContributionType;
    }

    /**
     * Accessor for property billerCode.
     *
     * @return billerCode of type String
     */
    public String getBillerCode() {
        return billerCode;
    }

    /**
     * Mutator for property billerCode.
     *
     * @param billerCode of type String
     */
    public void setBillerCode(String billerCode) {
        this.billerCode = billerCode;
    }

}
