////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.provider;

import org.springframework.boot.actuate.health.Health;

import au.com.suncorp.wealth.api.common.healthcheck.HealthCheckException;
import au.com.suncorp.wealth.api.common.healthcheck.SingleEnvironmentProviderHealthIndicator;
import au.com.suncorp.wealth.api.common.healthcheck.checker.SpringBootHealthChecker;
import au.com.suncorp.wealth.api.common.healthcheck.provider.SingleEnvironmentServiceProviderConfiguration;

/**
 * The class {@code DependentServiceHealthIndicator} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class DependentServiceHealthIndicator extends SingleEnvironmentProviderHealthIndicator {
    private final SpringBootHealthChecker springBootHealthChecker;
    private final SingleEnvironmentServiceProviderConfiguration providerConfiguration;

    /**
     * Parameterised constructor.
     *
     * @param providerConfiguration
     * @param name
     * @param springBootHealthChecker
     */
    public DependentServiceHealthIndicator(SingleEnvironmentServiceProviderConfiguration providerConfiguration, String name,
            SpringBootHealthChecker springBootHealthChecker) {
        super(providerConfiguration, name);
        this.providerConfiguration = providerConfiguration;
        this.springBootHealthChecker = springBootHealthChecker;
    }

    /**
     * Does health check.
     *
     * @throws HealthCheckException
     */
    @Override
    protected Health doCheck() throws HealthCheckException {
        return springBootHealthChecker.check(providerConfiguration.getHealthEndpoint());
    }
}
