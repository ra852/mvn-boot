////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.exception;

/**
 * The class {@code InvalidBrandException} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
public class InvalidBrandException extends Exception {

    /**
     * Parameterised constructor.
     *
     * @param message
     */
    public InvalidBrandException(String message) {
        super(message);
    }
}
