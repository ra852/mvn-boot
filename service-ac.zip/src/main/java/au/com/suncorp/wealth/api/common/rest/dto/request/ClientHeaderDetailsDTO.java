////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2018, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.common.rest.dto.request;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

/**
 * The class {@code ClientHeaderDetailsDTO} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class ClientHeaderDetailsDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    @Pattern(regexp = "^[a-zA-Z0-9-]{0,36}+$")
    private String requestId;
    @Pattern(regexp = "^[a-zA-Z0-9- \\._+/=]+$")
    private String entitlementInfo;
  
    @Pattern(regexp = "^[a-zA-Z0-9\\.-]{0,10}+$")
    private String apiVersion;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
    public String getEntitlmentInfo() {
        return entitlementInfo;
    }

    public void setEntitlmentInfo(String entitlementInfo) {
        this.entitlementInfo = entitlementInfo;
    }
    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }
}
