////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code ResponseCompoundData} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 * @param <T>
 * @param <V>
 */
@SuppressWarnings("serial")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "type", "id", "attributes", "relationships" })
public class ResponseCompoundData<T extends Object, V extends Object> implements Serializable {
    @ApiModelProperty(value = "Resource type", required = false, example = "Accounts", position = 1)
    private String type;

    @ApiModelProperty(value = "Resource ID", required = false, example = "900000001", position = 2)
    private String id;

    @ApiModelProperty(value = "Resource data content", required = false, position = 3)
    private T attributes;

    @ApiModelProperty(value = "Resource relationship content to included resource", required = false, position = 4)
    private V relationships;

    /**
     * Parameterised constructor.
     *
     * @param type
     * @param id
     * @param attributes
     */
    public ResponseCompoundData(String type, String id, T attributes) {
        this.attributes = attributes;
        this.type = type;
        this.id = id;
    }

    /**
     * Parameterised constructor.
     *
     * @param type
     * @param id
     */
    public ResponseCompoundData(String type, String id) {
        this(type, id, null);
    }

    /**
     * Parameterised constructor
     *
     * @param type
     * @param attributes
     */
    public ResponseCompoundData(String type, T attributes) {
        this(type, null, attributes);
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public T getAttributes() {
        return attributes;
    }

    public void setAttributes(T attributes) {
        this.attributes = attributes;
    }

    public V getRelationships() {
        return relationships;
    }

    public void setRelationships(V relationships) {
        this.relationships = relationships;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
