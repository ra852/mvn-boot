////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.common.config;

import java.util.Arrays;
import org.apache.catalina.Context;
import org.apache.catalina.connector.Connector;
import org.springframework.boot.context.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.boot.context.embedded.tomcat.TomcatContextCustomizer;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * The class {@code TomcatSecurityConfiguration} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@Configuration
public class TomcatSecurityConfiguration {

    /**
     * Servlet Container.
     *
     * @return factory
     */
    @Bean
    public TomcatEmbeddedServletContainerFactory servletContainer() {
        TomcatEmbeddedServletContainerFactory factory = new TomcatEmbeddedServletContainerFactory();
        factory.setTomcatContextCustomizers(Arrays.asList(new CustomCustomizer()));
        factory.setTomcatConnectorCustomizers(Arrays.asList(new ConnectorCustomizer()));
        return factory;
    }

    /**
     * The class {@code CustomCustomizer} does this.
     *
     * @author u201468
     * @since 9Feb.,2018
     * @version 1.0
     */
    static class CustomCustomizer implements TomcatContextCustomizer {
        @Override
        public void customize(Context context) {
            context.setUseHttpOnly(true);
        }
    }

    /**
     * The class {@code ConnectorCustomizer} does this.
     *
     * @author u201468
     * @since 9Feb.,2018
     * @version 1.0
     */
    static class ConnectorCustomizer implements TomcatConnectorCustomizer {
        @Override
        public void customize(Connector connector) {
            connector.setProperty("server", "Server");
        }
    }
}
