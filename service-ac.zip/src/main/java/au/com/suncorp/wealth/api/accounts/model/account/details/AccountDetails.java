////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code AccountDetails} does this.
 * 
 * @author U383754
 * @since 02/02/2016
 * @version 1.0
 */
public class AccountDetails {
    private String id;
    private String name;
    private AccountNumberInfo accountNumber;
    private ReferenceIdentifier accountExternalRef;
    private CodeIdentifier statusCode;
    private AuditIdentifier audit;
    private MasterSchemeIdentifier masterScheme;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property accountExternalRef.
     * 
     * @return accountExternalRef of type ReferenceIdentifier
     */
    public ReferenceIdentifier getAccountExternalRef() {
        return accountExternalRef;
    }

    /**
     * Mutator for property accountExternalRef.
     * 
     * @return accountExternalRef of type ReferenceIdentifier
     */
    public void setAccountExternalRef(ReferenceIdentifier accountExternalRef) {
        this.accountExternalRef = accountExternalRef;
    }

    /**
     * Accessor for property statusCode.
     * 
     * @return statusCode of type CodeIdentifier
     */
    public CodeIdentifier getStatusCode() {
        return statusCode;
    }

    /**
     * Mutator for property statusCode.
     * 
     * @return statusCode of type CodeIdentifier
     */
    public void setStatusCode(CodeIdentifier statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Accessor for property audit.
     * 
     * @return audit of type AuditIdentifier
     */
    public AuditIdentifier getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     * 
     * @return audit of type AuditIdentifier
     */
    public void setAudit(AuditIdentifier audit) {
        this.audit = audit;
    }

    /**
     * Accessor for property masterScheme.
     * 
     * @return masterScheme of type MasterSchemeIdentifier
     */
    public MasterSchemeIdentifier getMasterScheme() {
        return masterScheme;
    }

    /**
     * Mutator for property masterScheme.
     * 
     * @return masterScheme of type MasterSchemeIdentifier
     */
    public void setMasterScheme(MasterSchemeIdentifier masterScheme) {
        this.masterScheme = masterScheme;
    }

    /**
     * @return the accountNumber
     */
    public AccountNumberInfo getAccountNumber() {
        return accountNumber;
    }

    /**
     * @param accountNumber the accountNumber to set
     */
    public void setAccountNumber(AccountNumberInfo accountNumber) {
        this.accountNumber = accountNumber;
    }

}
