////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.utils;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_UNAUTHORIZED;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_UNAUTHORIZED_ID;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

import au.com.suncorp.api.identity.context.EntitlementContext;
import au.com.suncorp.api.identity.context.EntitlementContextHolder;
import au.com.suncorp.api.identity.context.IdentityContextHolder;
import au.com.suncorp.wealth.api.accounts.exception.JwtAuthAccountRuntimeException;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import io.jsonwebtoken.Claims;

/**
 * The class {@code EntitlementJwtUtil} does this.
 *
 * @author u387938
 * @since 9Feb.,2018
 * @version 1.0
 */
public class EntitlementJwtUtil extends AccountUtil {
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(EntitlementJwtUtil.class);

    /**
     * this method is to get entitlement partyrefs.
     * 
     * @param jwtToken
     * @param reqAccountId
     * @param env
     * @param pb
     * @return
     */
    @SuppressWarnings("unchecked")
    public List<Map<String, String>> decodeJWTAndGetPartyRefs(String jwtToken, String reqAccountId, Environment env, ParameterBean pb) {
        APP_LOGGER.info("Entering decodeJWTAndGetPartyRefs");
        EntitlementContext entitlementContextHolder = EntitlementContextHolder.get();
        Claims claims = entitlementContextHolder.getEntitlementClaims();
        if (claims != null && claims.containsKey("data.partyrefs")) {
            return (List<Map<String, String>>) claims.get("data.partyrefs");
        } else {
            throw new JwtAuthAccountRuntimeException(getLogId(LBL_UNAUTHORIZED_ID), LBL_UNAUTHORIZED, LBL_UNAUTHORIZED, pb);
        }
    }

    public Boolean checkForHighTrustCall() {
        APP_LOGGER.info("Entering checkForHighTrustCall");
        String callerType = "User";
        if (IdentityContextHolder.get() != null && IdentityContextHolder.get().getIdentityClaims() != null) {
            callerType = String.valueOf(IdentityContextHolder.get().getIdentityClaims().get("sub_type"));
            APP_LOGGER.info(String.valueOf(IdentityContextHolder.get().getIdentityClaims().get("sub_type")));
        }
        if (callerType.equalsIgnoreCase("application")) {
            return true;
        }
        return false;
    }

}
