////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code TransSummaryDetail} is an entity POJO for GetAccountTransactionSummary service.
 * 
 * @author U384381
 * @since 30/12/2015
 * @version 1.0
 */
public class TransSummaryDetail {
    private String id;
    private String fundFullName;
    private String unitPriceEffectiveDate;
    private String percentage;
    private String openingBalanceAmount;
    private String closingBalanceAmount;
    private String openingPrice;
    private String closingPrice;
    private String openingUnits;
    private String closingUnits;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFundFullName() {
        return fundFullName;
    }

    public void setFundFullName(String fundFullName) {
        this.fundFullName = fundFullName;
    }

    public String getUnitPriceEffectiveDate() {
        return unitPriceEffectiveDate;
    }

    public void setUnitPriceEffectiveDate(String unitPriceEffectiveDate) {
        this.unitPriceEffectiveDate = unitPriceEffectiveDate;
    }

    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    public String getOpeningBalanceAmount() {
        return openingBalanceAmount;
    }

    public void setOpeningBalanceAmount(String openingBalanceAmount) {
        this.openingBalanceAmount = openingBalanceAmount;
    }

    public String getClosingBalanceAmount() {
        return closingBalanceAmount;
    }

    public void setClosingBalanceAmount(String closingBalanceAmount) {
        this.closingBalanceAmount = closingBalanceAmount;
    }

    public String getOpeningPrice() {
        return openingPrice;
    }

    public void setOpeningPrice(String openingPrice) {
        this.openingPrice = openingPrice;
    }

    public String getClosingPrice() {
        return closingPrice;
    }

    public void setClosingPrice(String closingPrice) {
        this.closingPrice = closingPrice;
    }

    public String getOpeningUnits() {
        return openingUnits;
    }

    public void setOpeningUnits(String openingUnits) {
        this.openingUnits = openingUnits;
    }

    public String getClosingUnits() {
        return closingUnits;
    }

    public void setClosingUnits(String closingUnits) {
        this.closingUnits = closingUnits;
    }

}
