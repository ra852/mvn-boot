////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import au.com.suncorp.wealth.api.accounts.config.properties.DomainApiServiceProperties;

/**
 * The class {@code DomainApiService} does this.
 *
 * @author U383754
 * @since 8Mar.,2018
 * @version 1.0
 */
@Component
public class DomainApiService {
    private DomainApiServiceProperties domainApiServiceProperties;

    @Autowired
    public DomainApiService(DomainApiServiceProperties domainApiServiceProperties) {
        this.domainApiServiceProperties = domainApiServiceProperties;
    }

    public String getProductDefinitionHostName() {
        return domainApiServiceProperties.getProductDefinitionHostName();
    }
}
