////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.common.provider;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.Assert;

import au.com.suncorp.wealth.api.common.context.RequestContext;
import au.com.suncorp.wealth.api.common.context.RequestContextHolder;

/**
 * The class {@code EnvironmentSwitchableServiceProvider} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 * @param <T>
 */
public class EnvironmentSwitchableServiceProvider<T> implements ServiceProvider<T> {
    private final String httpHeaderKeyForSwitchEnvironment;
    private final T activeService;

    private final Map<String, T> environmentToServicesMap;

    /**
     * Parameterised constructor.
     *
     * @param httpHeaderKeyForSwitchEnvironment
     * @param environmentIdToServicesMap
     */
    public EnvironmentSwitchableServiceProvider(String httpHeaderKeyForSwitchEnvironment, LinkedHashMap<String, T> environmentIdToServicesMap) {
        this(httpHeaderKeyForSwitchEnvironment, environmentIdToServicesMap, null);
    }

    /**
     * Parameterised constructor.
     *
     * @param httpHeaderKeyForSwitchEnvironment
     * @param environmentIdToServicesMap
     * @param activeEnvironment
     */
    public EnvironmentSwitchableServiceProvider(String httpHeaderKeyForSwitchEnvironment, LinkedHashMap<String, T> environmentIdToServicesMap,
            String activeEnvironment) {
        Assert.notEmpty(environmentIdToServicesMap, "Error: environmentIdToServicesMap variable is empty");
        this.httpHeaderKeyForSwitchEnvironment = httpHeaderKeyForSwitchEnvironment;
        this.environmentToServicesMap = environmentIdToServicesMap;
        if (StringUtils.isNotBlank(activeEnvironment)) {
            this.activeService = serviceByEnvironment(activeEnvironment);
        } else {
            this.activeService = firstOne(environmentIdToServicesMap);
        }
    }

    public T firstOne(Map<String, T> environmentToServicesMap) {
        return environmentToServicesMap.values().iterator().next();
    }

    /**
     * Does this.
     *
     * @return
     */
    public T get() {
        String environment = getEnvironmentSpecifiedInHTTPRequest();
        if (environmentSpecifiedInHttpRequest(environment)) {
            return serviceByEnvironment(environment);
        } else {
            return activeService;
        }
    }

    /**
     * Does this.
     *
     * @param environmentSpecifiedInHttpRequest
     * @return
     */
    private boolean environmentSpecifiedInHttpRequest(String environmentSpecifiedInHttpRequest) {
        return StringUtils.isNotBlank(environmentSpecifiedInHttpRequest);
    }

    /**
     * Service by environment.
     *
     * @param environment
     * @return
     */
    private T serviceByEnvironment(String environment) {
        T configuration;
        configuration = environmentToServicesMap.get(environment);

        if (configuration == null) {
            throw new ProviderEnvironmentInvalidException("Unknown environment: " + environment);
        }
        return configuration;
    }

    /**
     * Get environment specified in HTTP request.
     *
     * @return
     */
    private String getEnvironmentSpecifiedInHTTPRequest() {
        String environment = null;

        RequestContext requestContext = RequestContextHolder.get();

        if (requestContext != null) {
            environment = requestContext.getContext(httpHeaderKeyForSwitchEnvironment);
        }

        return environment;
    }
}
