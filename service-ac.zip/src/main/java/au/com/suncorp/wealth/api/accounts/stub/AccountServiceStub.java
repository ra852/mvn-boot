////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.stub;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;

import au.com.suncorp.wealth.api.common.util.JsonUtils;
import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;

/**
 * The class {@code AccountServiceStub} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class AccountServiceStub extends RestTemplate {

    private static final Logger APP_LOGGER = LoggerFactory.getLogger(AccountServiceStub.class);

    /**
     * Does this.
     *
     * @param url
     * @param method
     * @param requestEntity
     * @param responseType
     * @param uriVariables
     * @return
     */
    @SuppressWarnings("unchecked")
    @Override
    public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Object... uriVariables) {
        try {
            JsonNode responseJson = null;
            if (url.indexOf("getaccountlist") != -1) {
                responseJson = JsonUtils.getJsonNodeFromFile("stubs/get-account-list-response.json");
            }
            APP_LOGGER.info("Response json :" + responseJson);
            return (ResponseEntity<T>) new ResponseEntity<>(responseJson, HttpStatus.OK);
        } catch (IOException e) {
            APP_LOGGER.error("Error in forming the responseJson :\n {}");
            throw new AccountServiceRuntimeException(e.getMessage());
        }
    }
}
