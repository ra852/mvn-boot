////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code ExpenseGroupDetails} does this.
 * 
 * @author U383754
 * @since 02/02/2016
 * @version 1.0
 */
public class ExpenseGroupDetails {
    private IdentityIdentifier expenseGroup;
    private String effectiveDate;
    private IdNameIdentifier outlet;
    private String consentDate;

    /**
     * Accessor for property expenseGroup.
     * 
     * @return expenseGroup of type IdentityIdentifier
     */
    public IdentityIdentifier getExpenseGroup() {
        return expenseGroup;
    }

    /**
     * Mutator for property expenseGroup.
     * 
     * @return expenseGroup of type IdentityIdentifier
     */
    public void setExpenseGroup(IdentityIdentifier expenseGroup) {
        this.expenseGroup = expenseGroup;
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }

    /**
     * Accessor for property consentDate.
     * 
     * @return consentDate of type String
     */
    public String getConsentDate() {
        return consentDate;
    }

    /**
     * Mutator for property consentDate.
     * 
     * @return consentDate of type String
     */
    public void setConsentDate(String consentDate) {
        this.consentDate = consentDate != null ? consentDate : "";
    }

    /**
     * Accessor for property outlet.
     *
     * @return outlet of type IdNameIdentifier
     */
    public IdNameIdentifier getOutlet() {
        return outlet;
    }

    /**
     * Mutator for property outlet.
     *
     * @param outlet of type IdNameIdentifier
     */
    public void setOutlet(IdNameIdentifier outlet) {
        this.outlet = outlet;
    }

}
