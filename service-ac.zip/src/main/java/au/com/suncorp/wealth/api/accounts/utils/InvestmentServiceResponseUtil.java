////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.utils;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_CLOSING_BAL_AMT;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_CLOSING_PRICE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_CLOSING_UNITS;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_ERROR_MSG;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FUND_NAME;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_GET_INVESTMENT_BAL;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_OPENING_BAL_AMT;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_OPENING_PRICE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_OPENING_UNITS;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_PERCENTAGE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_TOTAL_CLOSING_BAL;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_TOTAL_OPENING_BAL;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_UNIT_PRICE_EFF_DATE;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

import au.com.suncorp.wealth.api.accounts.model.account.details.GetInvestmentBalanceResponseBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetInvestmentBalanceResponseWrapperBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.TransSummaryDetail;

/**
 * The class {@code InvestmentServiceResponseUtil} does this.
 *
 * @author U383754
 * @since 25Apr.,2018
 * @version 1.0
 */
public class InvestmentServiceResponseUtil {

    public GetInvestmentBalanceResponseWrapperBean parse(JsonNode jNode) {
        GetInvestmentBalanceResponseWrapperBean wrapperBean = new GetInvestmentBalanceResponseWrapperBean();
        GetInvestmentBalanceResponseBean investmentResponseBean = parseJson(jNode);
        wrapperBean.setGetInvestmentBalanceResponse(investmentResponseBean);
        return wrapperBean;
    }

    private GetInvestmentBalanceResponseBean parseJson(JsonNode jsonNode) {
        GetInvestmentBalanceResponseBean investmentResponseBean = new GetInvestmentBalanceResponseBean();
        if (jsonNode.hasNonNull(LBL_GET_INVESTMENT_BAL)) {
            JsonNode responseFields = jsonNode.get(LBL_GET_INVESTMENT_BAL);
            if (responseFields.hasNonNull(LBL_ERROR_MSG)) {
                investmentResponseBean.setErrorMessage(responseFields.get(LBL_ERROR_MSG).asText());
            } else {
                prepareResponse(investmentResponseBean, responseFields);
            }
        }
        return investmentResponseBean;
    }

    /**
     * Does this.
     *
     * @param investmentResponseBean
     * @param responseFields
     */
    public void prepareResponse(GetInvestmentBalanceResponseBean investmentResponseBean, JsonNode responseFields) {
        Iterator<String> fieldNames = responseFields.fieldNames();
        while (fieldNames.hasNext()) {
            String fieldName = fieldNames.next();
            JsonNode fieldValue = responseFields.get(fieldName);
            if (fieldValue.isArray()) {
                setTransDetails(investmentResponseBean, fieldValue);
            } else {
                setObjects(investmentResponseBean, fieldName, fieldValue);
            }
        }
    }

    /**
     * Does this.
     *
     * @param investmentResponseBean
     * @param fieldValue
     */
    public void setTransDetails(GetInvestmentBalanceResponseBean investmentResponseBean, JsonNode fieldValue) {
        List<TransSummaryDetail> transSummaryDetails = new ArrayList<TransSummaryDetail>();
        for (final JsonNode objNode : fieldValue) {
            settrasFields(transSummaryDetails, objNode);
        }
        investmentResponseBean.setTransSummaryDetails(transSummaryDetails);
    }

    /**
     * Does this.
     *
     * @param transSummaryDetails
     * @param objNode
     */
    public void settrasFields(List<TransSummaryDetail> transSummaryDetails, final JsonNode objNode) {
        TransSummaryDetail obj = new TransSummaryDetail();
        setClosingBalanceAmount(objNode, obj);
        setClosingPrice(objNode, obj);
        setClosingUnits(objNode, obj);
        setFundFullName(objNode, obj);
        setId(objNode, obj);
        setOpeningBalanceAmount(objNode, obj);
        setOpeningPrice(objNode, obj);
        setOpeningUnits(objNode, obj);
        setPercentage(objNode, obj);
        setUnitPriceEffectiveDate(objNode, obj);
        transSummaryDetails.add(obj);
    }

    /**
     * Does this.
     *
     * @param objNode
     * @param obj
     */
    public void setUnitPriceEffectiveDate(final JsonNode objNode, TransSummaryDetail obj) {
        if (objNode.hasNonNull(LBL_UNIT_PRICE_EFF_DATE)) {
            obj.setUnitPriceEffectiveDate(objNode.get(LBL_UNIT_PRICE_EFF_DATE).asText());
        }
    }

    /**
     * Does this.
     *
     * @param objNode
     * @param obj
     */
    public void setPercentage(final JsonNode objNode, TransSummaryDetail obj) {
        if (objNode.hasNonNull(LBL_PERCENTAGE)) {
            obj.setPercentage(objNode.get(LBL_PERCENTAGE).asText());
        }
    }

    /**
     * Does this.
     *
     * @param objNode
     * @param obj
     */
    public void setOpeningUnits(final JsonNode objNode, TransSummaryDetail obj) {
        if (objNode.hasNonNull(LBL_OPENING_UNITS)) {
            obj.setOpeningUnits(objNode.get(LBL_OPENING_UNITS).asText());
        }
    }

    /**
     * Does this.
     *
     * @param objNode
     * @param obj
     */
    public void setOpeningPrice(final JsonNode objNode, TransSummaryDetail obj) {
        if (objNode.hasNonNull(LBL_OPENING_PRICE)) {
            obj.setOpeningPrice(objNode.get(LBL_OPENING_PRICE).asText());
        }
    }

    /**
     * Does this.
     *
     * @param objNode
     * @param obj
     */
    public void setOpeningBalanceAmount(final JsonNode objNode, TransSummaryDetail obj) {
        if (objNode.hasNonNull(LBL_OPENING_BAL_AMT)) {
            obj.setOpeningBalanceAmount(objNode.get(LBL_OPENING_BAL_AMT).asText());
        }
    }

    /**
     * Does this.
     *
     * @param objNode
     * @param obj
     */
    public void setId(final JsonNode objNode, TransSummaryDetail obj) {
        if (objNode.hasNonNull(LBL_ID)) {
            obj.setId(objNode.get(LBL_ID).asText());
        }
    }

    /**
     * Does this.
     *
     * @param objNode
     * @param obj
     */
    public void setFundFullName(final JsonNode objNode, TransSummaryDetail obj) {
        if (objNode.hasNonNull(LBL_FUND_NAME)) {
            obj.setFundFullName(objNode.get(LBL_FUND_NAME).asText());
        }
    }

    /**
     * Does this.
     *
     * @param objNode
     * @param obj
     */
    public void setClosingUnits(final JsonNode objNode, TransSummaryDetail obj) {
        if (objNode.hasNonNull(LBL_CLOSING_UNITS)) {
            obj.setClosingUnits(objNode.get(LBL_CLOSING_UNITS).asText());
        }
    }

    /**
     * Does this.
     *
     * @param objNode
     * @param obj
     */
    public void setClosingPrice(final JsonNode objNode, TransSummaryDetail obj) {
        if (objNode.hasNonNull(LBL_CLOSING_PRICE)) {
            obj.setClosingPrice(objNode.get(LBL_CLOSING_PRICE).asText());
        }
    }

    /**
     * Does this.
     *
     * @param objNode
     * @param obj
     */
    public void setClosingBalanceAmount(final JsonNode objNode, TransSummaryDetail obj) {
        if (objNode.hasNonNull(LBL_CLOSING_BAL_AMT)) {
            obj.setClosingBalanceAmount(objNode.get(LBL_CLOSING_BAL_AMT).asText());
        }
    }

    /**
     * Does this.
     *
     * @param investmentResponseBean
     * @param fieldName
     * @param fieldValue
     */
    public void setObjects(GetInvestmentBalanceResponseBean investmentResponseBean, String fieldName, JsonNode fieldValue) {
        if (fieldName.equalsIgnoreCase(LBL_TOTAL_CLOSING_BAL)) {
            investmentResponseBean.setTotalClosingBalance(fieldValue.asText());
        } else if (fieldName.equalsIgnoreCase(LBL_TOTAL_OPENING_BAL)) {
            investmentResponseBean.setTotalOpeningBalance(fieldValue.asText());
        }
    }
}
