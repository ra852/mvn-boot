////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.provider.mapper;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.AUTHORIZATION_PREFIX;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_DOMAIN;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FORBIDDEN;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FORBIDDEN_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_OWNER_CODE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_PRODUCT_SYSTEM_PARTY_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_PRODUCT_SYS_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_TOKEN_VAL_FAILED;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_WEALTH_CLIENT_ABSENT;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.core.env.Environment;

import au.com.suncorp.wealth.api.accounts.exception.JwtAuthAccForbiddenRuntimeException;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetAccountDetailsResponse;
import au.com.suncorp.wealth.api.accounts.utils.AccountUtil;
import au.com.suncorp.wealth.api.accounts.utils.EntitlementJwtUtil;

/**
 * The class {@code AccountReferenceMapper} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class AccountReferenceMapper extends AccountUtil {

    /**
     * 
     * Does this.
     *
     * @param entitlementHeader
     * @param accountService
     * @param reqAccountId
     * @param env
     * @param pb
     */
    public List<Map<String, String>> map(String entitlementHeader, String reqAccountId, Environment env, ParameterBean pb) {
        String token = entitlementHeader.substring(AUTHORIZATION_PREFIX.length());
        List<Map<String, String>> partyRefs = new EntitlementJwtUtil().decodeJWTAndGetPartyRefs(token, reqAccountId, env, pb);
        if (partyRefs == null) {
            throw new JwtAuthAccForbiddenRuntimeException(getLogId(LBL_FORBIDDEN_ID), LBL_FORBIDDEN, LBL_WEALTH_CLIENT_ABSENT, pb);
        } else if (partyRefs != null && partyRefs.isEmpty()) {
            throw new JwtAuthAccForbiddenRuntimeException(getLogId(LBL_FORBIDDEN_ID), LBL_FORBIDDEN, LBL_WEALTH_CLIENT_ABSENT, pb);
        }
        return checkPartyRefs(partyRefs, reqAccountId, pb);
    }

    /**
     * 
     * This method check if the call can be categorised as high trust call or not.
     *
     * @return
     */
    public Boolean checkForHighTrustCall() {
        Boolean highTrustCallCheck = new EntitlementJwtUtil().checkForHighTrustCall();
        return highTrustCallCheck;
    }

    /**
     * 
     * Does this.
     *
     * @param partyRefs
     * @param accountService
     * @param reqAccountId
     * @param pb
     */
    private List<Map<String, String>> checkPartyRefs(List<Map<String, String>> partyRefs, String reqAccountId, ParameterBean pb) {
        List<Map<String, String>> tempPartyRefs =
                partyRefs.stream().filter(x -> x.get(LBL_PRODUCT_SYS_ID).equals(LBL_DOMAIN)).collect(Collectors.toList());
        if (tempPartyRefs.isEmpty()) {
            throw new JwtAuthAccForbiddenRuntimeException(getLogId(LBL_FORBIDDEN_ID), LBL_FORBIDDEN, LBL_TOKEN_VAL_FAILED, pb);
        }
        return tempPartyRefs;
    }

    /**
     * 
     * Does this.
     *
     * @param partyRefs
     * @param getAccountDetailsRes
     * @param reqAccountId
     * @param pb
     */
    public void doVerification(List<Map<String, String>> partyRefs, GetAccountDetailsResponse getAccountDetailsRes, String reqAccountId,
            ParameterBean pb) {
        String clientId = getAccountDetailsRes.getAccountDetailsList().stream().iterator().next().getClientAccountRelationships().stream()
                .filter(y -> y.getClientAccountRelationship().getRelationshipType().getCode().equals(LBL_OWNER_CODE)).findAny().get()
                .getClientAccountRelationship().getClient().getId();
        if (!partyRefs.stream().anyMatch(x -> x.get(LBL_PRODUCT_SYSTEM_PARTY_ID).equals(clientId))) {
            throw new JwtAuthAccForbiddenRuntimeException(getLogId(LBL_FORBIDDEN_ID), LBL_FORBIDDEN, LBL_TOKEN_VAL_FAILED, pb);
        }
    }
}
