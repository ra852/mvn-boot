////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.context;

import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The class {@code HystrixRequestContextHolder} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public final class HystrixRequestContextHolder {
    private static final Logger LOGGER = LoggerFactory.getLogger(HystrixRequestContextHolder.class);
    private static final ThreadLocal<HystrixRequestContext> HYSTRIX_REQUEST_CONTEXT_THREAD_LOCAL = new ThreadLocal<>();

    /**
     * Default constructor.
     */
    private HystrixRequestContextHolder() {
    }

    /**
     * Does this.
     * 
     * @param requestContext
     */
    public static void init(RequestContext requestContext) {
        if (HYSTRIX_REQUEST_CONTEXT_THREAD_LOCAL.get() != null) {
            LOGGER.warn("The RequestContext was not cleared correctly. Forced to shutdown.");

            HYSTRIX_REQUEST_CONTEXT_THREAD_LOCAL.get().shutdown();
        }

        HYSTRIX_REQUEST_CONTEXT_THREAD_LOCAL.set(HystrixRequestContext.initializeContext());
        RequestContextHolder.set(requestContext);
    }

    public static RequestContext get() {
        return RequestContextHolder.get();
    }

    public static void set(RequestContext requestContext) {
        RequestContextHolder.set(requestContext);
    }

    public static void clear() {
        RequestContextHolder.clear();

        if (HYSTRIX_REQUEST_CONTEXT_THREAD_LOCAL.get() != null) {
            HYSTRIX_REQUEST_CONTEXT_THREAD_LOCAL.get().shutdown();
            HYSTRIX_REQUEST_CONTEXT_THREAD_LOCAL.remove();
        }
    }

    /**
     * Used only for unit test.
     */
    static HystrixRequestContext getHystrixRequestContext() {
        return HYSTRIX_REQUEST_CONTEXT_THREAD_LOCAL.get();
    }

    /**
     * Used only for unit test.
     */
    static void setHystrixRequestContext(HystrixRequestContext hystrixRequestContext) {
        HYSTRIX_REQUEST_CONTEXT_THREAD_LOCAL.set(hystrixRequestContext);
    }
}
