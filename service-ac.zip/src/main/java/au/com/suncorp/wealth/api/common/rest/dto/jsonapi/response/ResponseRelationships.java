////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.google.common.base.MoreObjects;

import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.links.Links;
import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code ResponseRelationships} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
public class ResponseRelationships implements Serializable {
    @ApiModelProperty(value = "Relationship data")
    private List<ResponseRelationshipData> data = new ArrayList<>();

    @ApiModelProperty(value = "Relationship links")
    private Links links;

    public List<ResponseRelationshipData> getData() {
        return data;
    }

    public void addData(ResponseRelationshipData data) {
        this.data.add(data);
    }

    public void setData(List<ResponseRelationshipData> data) {
        this.data = data;
    }

    public Links getLinks() {
        return links;
    }

    public void setLinks(Links links) {
        this.links = links;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this).add("data", data).add("links", links).toString();
    }
}
