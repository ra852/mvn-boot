////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code ClientAccountRelationshipIdentifierBean} is used as a bean class.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class ClientAccountRelationshipIdentifierBean {
    private String id;
    private ClientBean client;
    private RelationshipIdentifierBean relationshipType;
    private String primary;
    private String delete;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property client.
     * 
     * @return client of type ClientBean
     */
    public ClientBean getClient() {
        return client;
    }

    /**
     * Mutator for property client.
     * 
     * @param client of type ClientBean
     */
    public void setClient(ClientBean client) {
        this.client = client;
    }

    /**
     * Accessor for property relationshipType.
     * 
     * @return relationshipType of type RelationshipIdentifierBean
     */
    public RelationshipIdentifierBean getRelationshipType() {
        return relationshipType;
    }

    /**
     * Mutator for property relationshipType.
     * 
     * @param relationshipType of type RelationshipIdentifierBean
     */
    public void setRelationshipType(RelationshipIdentifierBean relationshipType) {
        this.relationshipType = relationshipType;
    }

    /**
     * Accessor for property primary.
     * 
     * @return primary of type String
     */
    public String getPrimary() {
        return primary;
    }

    /**
     * Mutator for property primary.
     * 
     * @param primary of type String
     */
    public void setPrimary(String primary) {
        this.primary = primary != null ? primary : "";
    }

    /**
     * Accessor for property delete.
     * 
     * @return delete of type String
     */
    public String getDelete() {
        return delete;
    }

    /**
     * Mutator for property delete.
     * 
     * @param delete of type String
     */
    public void setDelete(String delete) {
        this.delete = delete;
    }

}
