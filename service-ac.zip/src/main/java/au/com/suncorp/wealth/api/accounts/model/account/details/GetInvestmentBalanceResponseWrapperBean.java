////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

import com.google.gson.annotations.SerializedName;

/**
 * The class {@code GetInvestmentBalanceResponseWrapperBean} does this.
 *
 * @author u201468
 * @since 19Jan.,2018
 * @version 1.0
 */
public class GetInvestmentBalanceResponseWrapperBean {
    @SerializedName("GetInvestmentBalanceResponse")
    private GetInvestmentBalanceResponseBean getInvestmentBalanceResponse;

    /**
     * Accessor for property GetInvestmentBalanceResponse.
     *
     * @return getInvestmentBalanceResponse of type GetInvestmentBalanceResponseBean
     */
    public GetInvestmentBalanceResponseBean getGetInvestmentBalanceResponse() {
        return getInvestmentBalanceResponse;
    }

    /**
     * Mutator for property GetInvestmentBalanceResponse.
     *
     * @param getInvestmentBalanceResponse of type GetInvestmentBalanceResponseBean
     */
    public void setGetInvestmentBalanceResponse(GetInvestmentBalanceResponseBean getInvestmentBalanceResponse) {
        this.getInvestmentBalanceResponse = getInvestmentBalanceResponse;
    }

}
