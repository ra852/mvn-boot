////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.utils;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.ACCEPT;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.BACKEND_SERVER_UNAVAILABLE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_ACCOUNT_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FAILED_ACC_INS_RES;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_FAILED_RES_DETAIL;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_ID_PREFIX;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_INVALID_RESPONSE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_RUNTIME_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.REQUEST_ID_FIELD_NAME;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.VERSION_ID_FIELD_NAME;
import static au.com.suncorp.wealth.api.common.constant.CommonConstants.APPLICATION_JSON_API_VALUE;
import static au.com.suncorp.wealth.api.common.constant.CommonConstants.X_CLIENT_ID_FIELD_NAME;
import static au.com.suncorp.wealth.api.common.constant.CommonConstants.X_CLIENT_VERSION_FIELD_NAME;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.apache.commons.lang.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.gson.JsonSyntaxException;

import au.com.suncorp.wealth.api.accounts.config.properties.AccountServiceProperties;
import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.exception.MainAccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.exception.handler.AccountServiceErrorHandler;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetAccountListDetailsResponseWrapperBean;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetInvestmentBalanceResponseWrapperBean;
import au.com.suncorp.wealth.api.accounts.rest.JwtService;

/**
 * The class {@code AccountUtil} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class AccountUtil {
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(AccountUtil.class);

    /**
     * Call SIL service to retrieve the account details..
     *
     * @param restTemplate
     * @param accountServiceProperties
     * @param formattedUrl
     * @param pb
     * @param accountNumber
     * @return
     */
    public ResponseEntity<JsonNode> retrieveBackendServiceResponse(RestTemplate restTemplate, AccountServiceProperties accountServiceProperties,
            String formattedUrl, String accountNumber, ParameterBean pb) {
        try {
            HttpEntity<String> httpEntity = retrieveHttpEntity(accountServiceProperties);
            restTemplate.setErrorHandler(new AccountServiceErrorHandler());
            ResponseEntity<JsonNode> responseEntity = restTemplate.exchange(formattedUrl, HttpMethod.GET, httpEntity, JsonNode.class);
            if (responseEntity.getBody() == null || responseEntity.getStatusCode() == HttpStatus.REQUEST_TIMEOUT) {
                throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), BACKEND_SERVER_UNAVAILABLE, LBL_FAILED_ACC_INS_RES, pb);
            }
            return responseEntity;
        } catch (ResourceAccessException e) {
            throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), BACKEND_SERVER_UNAVAILABLE, LBL_FAILED_ACC_INS_RES, pb);
        }
    }

    /**
     * Retrieves Http Entity.
     *
     * @param clientServiceProperties
     * @return httpEntity
     */
    public HttpEntity<String> retrieveHttpEntity(AccountServiceProperties clientServiceProperties) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.add(clientServiceProperties.getHeader().getKey(), clientServiceProperties.getHeader().getValue());
        HttpEntity<String> httpEntity = new HttpEntity<String>("parameters", headers);
        return httpEntity;
    }

    /**
     * Get Log Id.
     *
     * @param resourceId
     * @param accountNumber
     * @return
     */
    public String getLogId(String accountNumber) {
        return LBL_ID_PREFIX.replace(LBL_ACCOUNT_ID, accountNumber);
    }

    /**
     * Create Headers.
     *
     * @param pb
     * @return headers
     */
    protected MultiValueMap<String, String> createHeaders(ParameterBean pb) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.set(REQUEST_ID_FIELD_NAME, getRequestId(pb));
        headers.set(VERSION_ID_FIELD_NAME, pb.getApiVersion());
        headers.set(X_CLIENT_ID_FIELD_NAME, pb.getClientId());
        headers.set(X_CLIENT_VERSION_FIELD_NAME, pb.getClientVersion());
        headers.set(ACCEPT, APPLICATION_JSON_API_VALUE);
        return headers;
    }

    /**
     * Create Http headers.
     *
     * @param mae
     * @return headers
     */
    public HttpHeaders createHttpHeaders(MainAccountServiceRuntimeException mae) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(REQUEST_ID_FIELD_NAME, getRequestId(mae.getParameterBean()));
        headers.set(VERSION_ID_FIELD_NAME, mae.getParameterBean().getApiVersion());
        headers.set(X_CLIENT_ID_FIELD_NAME, mae.getParameterBean().getClientId());
        headers.set(X_CLIENT_VERSION_FIELD_NAME, mae.getParameterBean().getClientVersion());
        headers.add(ACCEPT, APPLICATION_JSON_API_VALUE);
        return headers;
    }

    /**
     * Get Request Id.
     *
     * @param pb
     * @return
     */
    private String getRequestId(ParameterBean pb) {
        if (pb.getRequestId() != null) {
            return pb.getRequestId();
        } else {
            return UUID.randomUUID().toString();
        }
    }

    public boolean isSuncorpIdentitySkip(JwtService jwtService) {
        if (jwtService.getSuncorpIdentity() != null && jwtService.getSuncorpIdentity().equalsIgnoreCase("true")) {
            return true;
        }
        return false;
    }

    /**
     * Construct parameters.
     *
     * @param includeParams
     * @param requestId
     * @param apiVersion
     * @return
     */
    public ParameterBean constructParams(List<?> includeParams, String requestId, String apiVersion, String resourceId, String clientId,
            String clientVersion) {
        ParameterBean pb = new ParameterBean();
        pb.setResourceId(resourceId);
        pb.setRequestId(requestId);
        pb.setApiVersion(apiVersion);
        pb.setClientId(clientId);
        pb.setClientVersion(clientVersion);
        pb.setIncludeParams(includeParams);
        return pb;
    }

    /**
     * Converts JSON to Java.
     *
     * @param responseEntity
     * @param accountNumber
     * @param pb
     * @return
     */
    @SuppressWarnings("unchecked")
    public <T> T parseJsonToObj(ResponseEntity<JsonNode> responseEntity, String accountNumber, ParameterBean pb, Class<T> classOfT) {
        log(APP_LOGGER, new StringBuilder("Converting JSON to JAVA for account number -> ").append(accountNumber).toString());
        T responseObject = null;
        try {
            JsonNode responseNode = responseEntity.getBody();
            if (classOfT == GetAccountListDetailsResponseWrapperBean.class) {
                responseObject = (T) new GetAccountDetailsResponseUtil().parse(responseNode);
            } else if (classOfT == GetInvestmentBalanceResponseWrapperBean.class) {
                responseObject = (T) new InvestmentServiceResponseUtil().parse(responseNode);
            }
        } catch (JsonSyntaxException e) {
            throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), LBL_INVALID_RESPONSE, LBL_FAILED_ACC_INS_RES, pb);
        }
        return responseObject;
    }

    /**
     * Does this.
     *
     * @param getAccountDetails
     * @param getAccountDetailsResponse
     * @return
     */
    public <T> T get(CompletableFuture<T> details, String accountNumber, ParameterBean pb) {
        try {
            return details.get();
        } catch (InterruptedException | ExecutionException ex) {
            throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), LBL_INVALID_RESPONSE, LBL_FAILED_RES_DETAIL, pb);
        }
    }

    /**
     * Does this.
     *
     * @param accountDetailendpoint
     */
    public void log(Logger logger, final String message) {
        try {
            Integer.parseInt("Dummy");
        } catch (NumberFormatException nfe) {
            if (logger.isDebugEnabled()) {
                logger.debug(StringEscapeUtils.escapeHtml(message));
            }
        }
    }

}
