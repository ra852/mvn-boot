////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2018, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The class {@code EntitlementInfo} does this.
 *
 * @author U205452
 * @since 23Feb.,2018
 * @version 1.0
 */
public class EntitlementInfo {
    private String iss;
    private String typ;
    private long exp;
    private String sub;
    private String subType;
    private String dataScid;
    private String dataEmpid;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<AccountReference> accountRefs;

    public String getIss() {
        return iss;
    }

    public void setIss(String iss) {
        this.iss = iss;
    }

    public String getTyp() {
        return typ;
    }

    public void setTyp(String typ) {
        this.typ = typ;
    }

    public long getExp() {
        return exp;
    }

    public void setExp(long exp) {
        this.exp = exp;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }
    
    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    @JsonProperty("data.scid")
    public String getDataScid() {
        return dataScid;
    }

    public void setDataScid(String dataScid) {
        this.dataScid = dataScid;
    }

    @JsonProperty("data.empid")
    public String getDataEmpid() {
        return dataEmpid;
    }

    public void setDataEmpid(String dataEmpid) {
        this.dataEmpid = dataEmpid;
    }
    
    @JsonProperty("data.partyrefs")
    public List<AccountReference> getAccountRefs() {
        return accountRefs;
    }

    public void setAccountRefs(List<AccountReference> accountRefs) {
        this.accountRefs = accountRefs;
    }

    
    
}
