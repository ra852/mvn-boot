////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code AccountDetailBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class AccountDetailBean {
    private String commencementDate;
    private String accountDesignation;
    private String dateJoinedParticipant;
    private String eligibleServiceDate;
    private String preventWithdrawal;
    private String staff;
    private String allOwnersToSign;
    private IncludeInRebalancingBean includeInRebalancing;
    private CodeIdentifier statusCode;
    private CodeIdentifier adaStatusCode;
    private CodeIdentifier openReason;

    public String getCommencementDate() {
        return commencementDate;
    }

    public void setCommencementDate(String commencementDate) {
        this.commencementDate = commencementDate;
    }

    public String getAccountDesignation() {
        return accountDesignation;
    }

    public void setAccountDesignation(String accountDesignation) {
        this.accountDesignation = accountDesignation;
    }

    public String getDateJoinedParticipant() {
        return dateJoinedParticipant;
    }

    public void setDateJoinedParticipant(String dateJoinedParticipant) {
        this.dateJoinedParticipant = dateJoinedParticipant;
    }

    public String getEligibleServiceDate() {
        return eligibleServiceDate;
    }

    public void setEligibleServiceDate(String eligibleServiceDate) {
        this.eligibleServiceDate = eligibleServiceDate;
    }

    public String getPreventWithdrawal() {
        return preventWithdrawal;
    }

    public void setPreventWithdrawal(String preventWithdrawal) {
        this.preventWithdrawal = preventWithdrawal;
    }

    public String getStaff() {
        return staff;
    }

    public void setStaff(String staff) {
        this.staff = staff;
    }

    public String getAllOwnersToSign() {
        return allOwnersToSign;
    }

    public void setAllOwnersToSign(String allOwnersToSign) {
        this.allOwnersToSign = allOwnersToSign;
    }

    public IncludeInRebalancingBean getIncludeInRebalancing() {
        return includeInRebalancing;
    }

    public void setIncludeInRebalancing(IncludeInRebalancingBean includeInRebalancing) {
        this.includeInRebalancing = includeInRebalancing;
    }

    public CodeIdentifier getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(CodeIdentifier statusCode) {
        this.statusCode = statusCode;
    }

    public CodeIdentifier getAdaStatusCode() {
        return adaStatusCode;
    }

    public void setAdaStatusCode(CodeIdentifier adaStatusCode) {
        this.adaStatusCode = adaStatusCode;
    }

    public CodeIdentifier getOpenReason() {
        return openReason;
    }

    public void setOpenReason(CodeIdentifier openReason) {
        this.openReason = openReason;
    }

}
