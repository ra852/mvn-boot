////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.links;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.MoreObjects;

/**
 * The class {@code DefaultSelfLinks} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DefaultSelfLinks implements SelfLinks {

    private String self;

    /**
     * Parameterised constructor.
     *
     * @param self
     */
    public DefaultSelfLinks(String self) {
        this.self = self;
    }

    @Override
    public String getSelf() {
        return self;
    }

    @Override
    public void setSelf(String self) {
        this.self = self;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DefaultSelfLinks that = (DefaultSelfLinks) o;
        return Objects.equals(self, that.self);
    }

    @Override
    public int hashCode() {

        return Objects.hash(self);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("self", self)
                .toString();
    }
}
