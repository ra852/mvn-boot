////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.healthcheck.provider;

/**
 * The class {@code ServiceProviderEnvironment} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class ServiceProviderEnvironment {
    private String environmentId;
    private String healthEndpoint;

    /**
     * Parameterised constructor.
     *
     * @param environmentId
     * @param healthEndpoint
     */
    public ServiceProviderEnvironment(String environmentId, String healthEndpoint) {
        this.environmentId = environmentId;
        this.healthEndpoint = healthEndpoint;
    }

    /**
     * Parameterised constructor.
     *
     * @param healthEndpoint
     */
    public ServiceProviderEnvironment(String healthEndpoint) {
        this.healthEndpoint = healthEndpoint;
    }

    public String getHealthEndpoint() {
        return healthEndpoint;
    }

    public String getEnvironmentId() {
        return environmentId;
    }
}
