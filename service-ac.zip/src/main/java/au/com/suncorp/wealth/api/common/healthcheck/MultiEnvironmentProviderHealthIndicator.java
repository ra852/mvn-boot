////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.healthcheck;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import au.com.suncorp.wealth.api.common.healthcheck.provider.MultiEnvironmentServiceProviderConfiguration;
import au.com.suncorp.wealth.api.common.healthcheck.util.HealthCheckUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;

/**
 * The class {@code MultiEnvironmentProviderHealthIndicator} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public abstract class MultiEnvironmentProviderHealthIndicator implements HealthIndicator {
    protected static final Status PARTIALLY_OUT_OF_SERVICE = new Status("PARTIALLY_OUT_OF_SERVICE");
    private MultiEnvironmentServiceProviderConfiguration multiEnvironmentServiceProviderConfigure;
    private final Logger logger;

    /**
     * Paarmeterised constructor.
     *
     * @param multiEnvironmentServiceProviderConfigure
     * @param name
     */
    public MultiEnvironmentProviderHealthIndicator(MultiEnvironmentServiceProviderConfiguration multiEnvironmentServiceProviderConfigure,
            String name) {
        this.multiEnvironmentServiceProviderConfigure = multiEnvironmentServiceProviderConfigure;
        this.logger = LoggerFactory.getLogger(name);
    }

    /**
     * Does this.
     */
    @Override
    public Health health() {
        Health.Builder healthBuilder = Health.unknown();

        List<String> environmentIdList = multiEnvironmentServiceProviderConfigure.getEnvironmentIdList();

        healthBuilder.withDetail("environments", environmentIdList);
        healthBuilder.withDetail("activeEnvironment", multiEnvironmentServiceProviderConfigure.getActiveEnvironment());

        List<Map<String, Object>> healthExceptionList = checkHealth(environmentIdList);

        if (healthExceptionList.isEmpty()) {
            healthBuilder.up();
        } else {
            healthBuilder.withDetail("exceptions", healthExceptionList);

            if (multiEnvironmentServiceProviderConfigure.isBetweenExpectedDowntime()) {
                healthBuilder.unknown();
            } else {
                if (healthExceptionList.size() == environmentIdList.size()) {
                    healthBuilder.outOfService();
                } else {
                    healthBuilder.status(PARTIALLY_OUT_OF_SERVICE);
                }
            }
        }

        return healthBuilder.build();
    }

    /**
     * Checks health.
     *
     * @param environmentIdList
     * @return
     */
    private List<Map<String, Object>> checkHealth(List<String> environmentIdList) {
        List<Map<String, Object>> healthExceptionList = new ArrayList<>();

        for (String environmentId : environmentIdList) {
            try {
                doCheck(environmentId);
            } catch (Exception e) {
                healthExceptionList
                        .add(buildHealthException(environmentId, multiEnvironmentServiceProviderConfigure.getHealthEndpoint(environmentId), e));
            }
        }

        return healthExceptionList;
    }

    protected abstract void doCheck(String environmentId) throws HealthCheckException;

    /**
     * Builds health check exception.
     *
     * @param environment
     * @param healthEndpoint
     * @param e
     * @return
     */
    private Map<String, Object> buildHealthException(String environment, String healthEndpoint, Exception e) {
        Map<String, Object> healthExceptionMap = new HashMap<>();

        if (multiEnvironmentServiceProviderConfigure.isBetweenExpectedDowntime()) {
            logger.warn("(Expected downtime period) " + HealthCheckUtil.formatErrorMessage(environment, healthEndpoint, e), e);
        } else {
            logger.error(HealthCheckUtil.formatErrorMessage(environment, healthEndpoint, e), e);
        }

        Health health = HealthCheckUtil.buildErrorHealth(environment, healthEndpoint, Status.UNKNOWN, e);
        healthExceptionMap.putAll(health.getDetails());

        return healthExceptionMap;
    }
}
