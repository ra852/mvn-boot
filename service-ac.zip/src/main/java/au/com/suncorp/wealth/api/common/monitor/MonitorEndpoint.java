////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.monitor;

import java.util.Collections;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.actuate.endpoint.AbstractEndpoint;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * The class {@code MonitorEndpoint} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@ConfigurationProperties(prefix = "endpoints.monitor", ignoreUnknownFields = false)
@Component
public class MonitorEndpoint extends AbstractEndpoint<Map<String, Object>> {
    private static final String MONITOR_ENDPOINT = "monitor";
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Constructor.
     *
     */
    public MonitorEndpoint() {
        super(MONITOR_ENDPOINT, false, true);

        logger.info("Endpoint registered: " + MONITOR_ENDPOINT);
    }

    @Override
    public Map<String, Object> invoke() {
        return Collections.<String, Object> singletonMap("status", "UP");
    }
}
