////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.common.healthcheck.domain;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * The class {@code HealthVO} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
public class HealthVO implements Serializable {
    private String status;

    /**
     * Accessor for property status.
     *
     * @return status of type String
     */
    public String getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     *
     * @param status of type String
     */
    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
