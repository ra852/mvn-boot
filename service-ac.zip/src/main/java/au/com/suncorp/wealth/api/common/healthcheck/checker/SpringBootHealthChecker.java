////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.healthcheck.checker;

import org.springframework.boot.actuate.health.Health;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestOperations;

import au.com.suncorp.wealth.api.common.healthcheck.HealthCheckException;
import au.com.suncorp.wealth.api.common.healthcheck.domain.HealthVO;

/**
 * The class {@code SpringBootHealthChecker} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class SpringBootHealthChecker {
    private RestOperations restOperations;

    /**
     * Parameterised constructor.
     *
     * @param restOperations
     */
    public SpringBootHealthChecker(RestOperations restOperations) {
        this.restOperations = restOperations;
    }

    public Health check(String healthUrl) throws HealthCheckException {
        return check(healthUrl, new HttpHeaders());
    }

    /**
     * Does this.
     *
     * @param healthUrl
     * @param httpHeaders
     * @return
     * @throws HealthCheckException
     */
    public Health check(String healthUrl, HttpHeaders httpHeaders) throws HealthCheckException {
        Health health;

        HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);

        try {
            ResponseEntity<HealthVO> healthVO = restOperations.exchange(healthUrl, HttpMethod.GET, httpEntity, HealthVO.class);

            health = Health.status(healthVO.getBody().getStatus()).build();
        } catch (RestClientException rce) {
            throw new HealthCheckException(healthUrl, rce);
        }

        return health;
    }
}
