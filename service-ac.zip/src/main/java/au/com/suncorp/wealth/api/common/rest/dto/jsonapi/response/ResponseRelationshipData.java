////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.MoreObjects;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code ResponseRelationshipData} does this.
 *
 * @author u201468
 * @since 12Feb.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
@JsonPropertyOrder({ "type", "id" })
public class ResponseRelationshipData implements Serializable {
    @ApiModelProperty(value = "Relationship resource type", required = false, example = "related resource type for ex:- insurances,product", position = 1)
    private String type;

    @ApiModelProperty(value = "Relationship resource ID", required = false, example = "12346789", position = 2)
    private String id;

    /**
     * Default constructor.
     */
    public ResponseRelationshipData() {
    }

    /**
     * Parameterised constructor.
     *
     * @param type
     * @param id
     */
    public ResponseRelationshipData(String type, String id) {
        this.type = type;
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public String getId() {
        return id;
    }

    protected MoreObjects.ToStringHelper toStringHelper() {
        return MoreObjects.toStringHelper(this).add("type", type).add("id", id);
    }

    @Override
    public String toString() {
        return toStringHelper().toString();
    }
}
