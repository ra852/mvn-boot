////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.healthcheck.checker;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import au.com.suncorp.wealth.api.common.healthcheck.HealthCheckException;

/**
 * The class {@code HttpResponseHealthChecker} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class HttpResponseHealthChecker {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Does this.
     *
     * @param url
     * @throws HealthCheckException
     */
    public void check(String url) throws HealthCheckException {
        check(url, null);
    }

    /**
     * Does this.
     *
     * @param url
     * @param expectedResponseText
     * @throws HealthCheckException
     */
    public void check(String url, String expectedResponseText) throws HealthCheckException {
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse httpResponse = null;
        HttpGet request = new HttpGet(url);

        try {
            httpClient = HttpClients.createDefault();
            httpResponse = httpClient.execute(request);

            checkHttpResponseStatusCode(httpResponse);

            if (StringUtils.isNotEmpty(expectedResponseText)) {
                checkHttpResponseContent(httpResponse, expectedResponseText);
            }
        } catch (Exception e) {
            throw new HealthCheckException(url, e);
        } finally {
            close(httpResponse);
            close(httpClient);
        }
    }

    /**
     * Check http response status code.
     *
     * @param response
     * @throws Exception
     */
    private void checkHttpResponseStatusCode(CloseableHttpResponse response) throws Exception {
        int statusCode = response.getStatusLine().getStatusCode();

        if (statusCode != HttpStatus.SC_OK) {
            throw new Exception("Invalid response HTTP status code: '" + statusCode + "'");
        }
    }

    /**
     * Check http response content.
     *
     * @param response
     * @param expectedText
     * @throws Exception
     */
    private void checkHttpResponseContent(CloseableHttpResponse response, String expectedText) throws Exception {
        String content = getResponseContent(response);

        if (!content.contains(expectedText)) {
            throw new Exception("Invalid response (expected to contain '" + expectedText + "'): '" + content + "'");
        }
    }

    /**
     * Get response content.
     *
     * @param response
     * @return
     * @throws IOException
     */
    private String getResponseContent(CloseableHttpResponse response) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
        StringBuilder content = new StringBuilder();
        String line = in.readLine();

        while (line != null) {
            if (content.length() > 0) {
                content.append("\n");
            }

            content.append(line);

            line = in.readLine();
        }

        return content.toString();
    }

    /**
     * Does this.
     *
     * @param httpResponse
     */
    private void close(CloseableHttpResponse httpResponse) {
        if (httpResponse != null) {
            try {
                httpResponse.close();
            } catch (IOException e) {
                logger.warn("Failed to close http response: ", e.getMessage());
            }
        }
    }

    /**
     * Does this.
     *
     * @param httpClient
     */
    private void close(CloseableHttpClient httpClient) {
        if (httpClient != null) {
            try {
                httpClient.close();
            } catch (IOException e) {
                logger.warn("Failed to close http client: ", e.getMessage());
            }
        }
    }
}
