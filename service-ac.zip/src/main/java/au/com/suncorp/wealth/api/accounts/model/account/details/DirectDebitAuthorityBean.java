////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code DirectDebitAuthorityBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class DirectDebitAuthorityBean {
    private String id;
    private String effectiveDate;
    private CodeIdentifier statusCode;
    private String dateSent;
    private CodeIdentifier reasonCode;

    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property effectiveDate.
     *
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     *
     * @param effectiveDate of type String
     */
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }

    /**
     * Accessor for property statusCode.
     *
     * @return statusCode of type CodeIdentifier
     */
    public CodeIdentifier getStatusCode() {
        return statusCode;
    }

    /**
     * Mutator for property statusCode.
     *
     * @param statusCode of type CodeIdentifier
     */
    public void setStatusCode(CodeIdentifier statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Accessor for property dateSent.
     *
     * @return dateSent of type String
     */
    public String getDateSent() {
        return dateSent;
    }

    /**
     * Mutator for property dateSent.
     *
     * @param dateSent of type String
     */
    public void setDateSent(String dateSent) {
        this.dateSent = dateSent != null ? dateSent : "";
    }

    /**
     * Accessor for property reasonCode.
     *
     * @return reasonCode of type CodeIdentifier
     */
    public CodeIdentifier getReasonCode() {
        return reasonCode;
    }

    /**
     * Mutator for property reasonCode.
     *
     * @param reasonCode of type CodeIdentifier
     */
    public void setReasonCode(CodeIdentifier reasonCode) {
        this.reasonCode = reasonCode;
    }

}
