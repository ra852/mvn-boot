////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.resource;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import au.com.suncorp.wealth.api.accounts.exception.InvalidRequestAccountRuntimeException;
import au.com.suncorp.wealth.api.accounts.exception.JwtAuthAccForbiddenRuntimeException;
import au.com.suncorp.wealth.api.accounts.exception.JwtAuthAccountRuntimeException;
import au.com.suncorp.wealth.api.accounts.exception.NotFoundAccountRuntimeException;
import au.com.suncorp.wealth.api.common.config.properties.ApiCommonProperties;
import au.com.suncorp.wealth.api.common.rest.dto.response.ErrorResponseDTO;
import au.com.suncorp.wealth.api.common.rest.exception.BadRequestException;

/**
 * The class {@code BaseResourceGlobalExceptionHandler} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class BaseResourceGlobalExceptionHandler extends ResponseEntityExceptionHandler {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final ApiCommonProperties apiCommonProperties;

    /**
     * Parameterised constructor.
     *
     * @param apiCommonProperties
     */
    public BaseResourceGlobalExceptionHandler(ApiCommonProperties apiCommonProperties) {
        this.apiCommonProperties = apiCommonProperties;

        logger.info("Registered");
    }

    /**
     * Does this.
     *
     * @param e
     * @param request
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleResourceGlobalException(Exception e, WebRequest request) {
        return handleExceptionInternal(e, null, new HttpHeaders(), exceptionToHttpStatus(e), request);
    }

    /**
     * Does this.
     *
     * @param e
     * @return
     */
    protected HttpStatus exceptionToHttpStatus(Exception e) {
        if (e instanceof OAuth2Exception || e instanceof AuthenticationException || e instanceof JwtAuthAccountRuntimeException) {
            return HttpStatus.UNAUTHORIZED;
        } else if (e instanceof BadRequestException || e instanceof InvalidRequestAccountRuntimeException) {
            return HttpStatus.BAD_REQUEST;
        } else if (e instanceof NotFoundAccountRuntimeException) {
            return HttpStatus.NOT_FOUND;
        } else if (e instanceof JwtAuthAccForbiddenRuntimeException) {
            return HttpStatus.FORBIDDEN;
        } else if (apiCommonProperties.getGlobalErrorResponse().isPropagateHttpStatusOfHttpClientErrorException() &&
                e instanceof HttpClientErrorException) {
            return ((HttpClientErrorException) e).getStatusCode();
        }
        return HttpStatus.INTERNAL_SERVER_ERROR;
    }

    /**
     * Does this.
     *
     * @param e
     * @param body
     * @param headers
     * @param status
     * @param request
     * @return
     */
    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception e, Object body, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ResponseEntity<Object> responseEntity = super.handleExceptionInternal(e, createErrorResponseDTO(e, status), headers, status, request);
        logger.info("Response: " + responseEntity);
        return responseEntity;
    }

    protected ErrorResponseDTO createErrorResponseDTO(Exception e, HttpStatus httpStatus) {
        ErrorResponseDTO errorResponseDTO;

        if (e instanceof MethodArgumentNotValidException) {
            errorResponseDTO = buildErrorResponseDTOForMethodArgumentNotValidException((MethodArgumentNotValidException) e, httpStatus);
        } else if (e instanceof BindException) {
            errorResponseDTO = buildErrorResponseDTOForBindException((BindException) e, httpStatus);
        } else {
            errorResponseDTO = buildErrorResponseDTOForOtherException(e, httpStatus);
        }

        return errorResponseDTO;
    }

    /**
     * Does this.
     *
     * @param e
     * @param httpStatus
     * @return
     */
    private ErrorResponseDTO buildErrorResponseDTOForMethodArgumentNotValidException(MethodArgumentNotValidException e, HttpStatus httpStatus) {
        BindingResult bindingResult = e.getBindingResult();
        return buildErrorResponseDTOFromBindingResult(httpStatus, bindingResult);
    }

    /**
     * Does this.
     *
     * @param e
     * @param httpStatus
     * @return
     */
    private ErrorResponseDTO buildErrorResponseDTOForBindException(BindException e, HttpStatus httpStatus) {
        BindingResult bindingResult = e.getBindingResult();
        return buildErrorResponseDTOFromBindingResult(httpStatus, bindingResult);
    }

    /**
     * Does this.
     *
     * @param httpStatus
     * @param bindingResult
     * @return
     */
    private ErrorResponseDTO buildErrorResponseDTOFromBindingResult(HttpStatus httpStatus, BindingResult bindingResult) {
        ErrorResponseDTO errorResponseDTO = new ErrorResponseDTO();

        for (FieldError fieldError : bindingResult.getFieldErrors()) {
            StringBuilder sb = new StringBuilder();
            sb.append("Field '");
            sb.append(fieldError.getField());
            sb.append("'");

            addErrorResponse(errorResponseDTO, httpStatus, fieldError);
        }

        return errorResponseDTO;
    }

    /**
     * Does this.
     *
     * @param e
     * @param httpStatus
     * @return
     */
    private ErrorResponseDTO buildErrorResponseDTOForOtherException(Exception e, HttpStatus httpStatus) {
        ErrorResponseDTO errorResponseDTO = new ErrorResponseDTO();

        String errorMessage = "Exception occurred: " + e.getMessage();
        Throwable rootCause = ExceptionUtils.getRootCause(e);
        String logMessage = errorMessage;

        if (rootCause == null) {
            addErrorResponse(errorResponseDTO, httpStatus, e);
        } else {
            String rootCauseMessage = ExceptionUtils.getMessage(rootCause);

            if (rootCause instanceof HttpStatusCodeException) {
                String responseBody = ((HttpStatusCodeException) rootCause).getResponseBodyAsString();
                logMessage += ". Caused by: " + rootCauseMessage + ", with response: " + responseBody;

                addErrorResponse(errorResponseDTO, httpStatus, e, rootCause, responseBody);
            } else {
                logMessage += ". Caused by: " + rootCauseMessage;

                addErrorResponse(errorResponseDTO, httpStatus, e, rootCause);
            }
        }

        logExceptionBasedOnHttpStatus(e, httpStatus, logMessage);

        return errorResponseDTO;
    }

    /**
     * Does this.
     *
     * @param errorResponseDTO
     * @param httpStatus
     * @param fieldError
     */
    private void addErrorResponse(ErrorResponseDTO errorResponseDTO, HttpStatus httpStatus, FieldError fieldError) {
        StringBuilder sb = new StringBuilder();
        sb.append("Field '");
        sb.append(fieldError.getField());
        sb.append("'");

        if (apiCommonProperties.getGlobalErrorResponse().isIncludeCause()) {
            sb.append(": ");
            sb.append(fieldError.getDefaultMessage());

            errorResponseDTO.addError(httpStatus.value(), httpStatus.getReasonPhrase() + ": " + sb.toString(), fieldError.toString());
        } else {
            errorResponseDTO.addError(httpStatus.value(), httpStatus.getReasonPhrase() + ": " + sb.toString());
        }
    }

    /**
     * Does this.
     *
     * @param errorResponseDTO
     * @param httpStatus
     * @param e
     */
    private void addErrorResponse(ErrorResponseDTO errorResponseDTO, HttpStatus httpStatus, Exception e) {
        if (apiCommonProperties.getGlobalErrorResponse().isIncludeCause()) {
            errorResponseDTO.addError(httpStatus.value(), httpStatus.getReasonPhrase() + ": " + e.getMessage());
        } else {
            errorResponseDTO.addError(httpStatus.value(), httpStatus.getReasonPhrase());
        }
    }

    /**
     * Does this.
     *
     * @param errorResponseDTO
     * @param httpStatus
     * @param e
     * @param rootCause
     */
    private void addErrorResponse(ErrorResponseDTO errorResponseDTO, HttpStatus httpStatus, Exception e, Throwable rootCause) {
        if (apiCommonProperties.getGlobalErrorResponse().isIncludeCause()) {
            errorResponseDTO.addError(httpStatus.value(), httpStatus.getReasonPhrase() + ": " + e.getMessage(),
                    "Caused by: " + ExceptionUtils.getMessage(rootCause));
        } else {
            errorResponseDTO.addError(httpStatus.value(), httpStatus.getReasonPhrase());
        }
    }

    /**
     * Does this.
     *
     * @param errorResponseDTO
     * @param httpStatus
     * @param e
     * @param rootCause
     * @param response
     */
    private void addErrorResponse(ErrorResponseDTO errorResponseDTO, HttpStatus httpStatus, Exception e, Throwable rootCause, String response) {
        if (apiCommonProperties.getGlobalErrorResponse().isIncludeCause()) {
            errorResponseDTO.addError(httpStatus.value(), httpStatus.getReasonPhrase() + ": " + e.getMessage(),
                    "Caused by: " + ExceptionUtils.getMessage(rootCause) + ", with response: " + response);
        } else {
            errorResponseDTO.addError(httpStatus.value(), httpStatus.getReasonPhrase());
        }
    }

    /**
     * Does this.
     *
     * @param e
     * @param httpStatus
     * @param message
     */
    protected void logExceptionBasedOnHttpStatus(Exception e, HttpStatus httpStatus, String message) {
        if (httpStatus.is5xxServerError()) {
            logger.error(message, e);
        } else if (httpStatus == HttpStatus.UNAUTHORIZED) {
            logger.warn(message, e);
        }
    }
}
