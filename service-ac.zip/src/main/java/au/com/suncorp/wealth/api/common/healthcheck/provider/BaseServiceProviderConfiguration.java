////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.common.healthcheck.provider;

import au.com.suncorp.wealth.api.common.healthcheck.util.HealthCheckUtil;

/**
 * The class {@code BaseServiceProviderConfiguration} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class BaseServiceProviderConfiguration {
    private boolean downtimeEnabled;
    private String downtimePeriod;

    /**
     * Parameterised constructor.
     *
     * @param downtimeEnabled
     * @param downtimePeriod
     */
    public BaseServiceProviderConfiguration(boolean downtimeEnabled, String downtimePeriod) {
        this.downtimeEnabled = downtimeEnabled;
        this.downtimePeriod = downtimePeriod;
    }

    public boolean isDowntimeEnabled() {
        return downtimeEnabled;
    }

    public String getDowntimePeriod() {
        return downtimePeriod;
    }

    public boolean isBetweenExpectedDowntime() {
        return isDowntimeEnabled() && HealthCheckUtil.isBetweenExceptedDowntimePeriod(getDowntimePeriod());
    }
}
