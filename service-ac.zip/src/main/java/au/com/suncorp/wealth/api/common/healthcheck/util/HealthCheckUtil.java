////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.common.healthcheck.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.web.client.HttpStatusCodeException;

import au.com.suncorp.wealth.api.common.util.DateTimeComparator;

/**
 * The class {@code HealthCheckUtil} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public final class HealthCheckUtil {
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(HealthCheckUtil.class);

    /**
     * Default constructor.
     */
    private HealthCheckUtil() {
    }

    /**
     * Builds error health.
     *
     * @param healthEndpoint
     * @param status
     * @param e
     * @return
     */
    public static Health buildErrorHealth(String healthEndpoint, Status status, Exception e) {
        return buildErrorHealth(null, healthEndpoint, status, e);
    }

    /**
     * Does this.
     *
     * @param environment
     * @param healthEndpoint
     * @param status
     * @param e
     * @return
     */
    public static Health buildErrorHealth(String environment, String healthEndpoint, Status status, Exception e) {
        Health.Builder healthBuilder = Health.status(status);

        if (environment != null) {
            healthBuilder.withDetail("environment", environment);
        }

        healthBuilder.withDetail("endpoint", healthEndpoint).withDetail("reason", StringUtils.defaultString(e.getMessage())).withDetail("trace",
                ExceptionUtils.getRootCauseStackTrace(e));

        Throwable rootCause = ExceptionUtils.getRootCause(e);

        if (rootCause != null) {
            healthBuilder.withDetail("rootCause", StringUtils.defaultString(rootCause.getMessage()));

            if (rootCause instanceof HttpStatusCodeException) {
                healthBuilder.withDetail("response", ((HttpStatusCodeException) rootCause).getResponseBodyAsString());
            }
        }

        return healthBuilder.build();
    }

    public static String formatErrorMessage(String healthEndpoint, Exception e) {
        return formatErrorMessage(null, healthEndpoint, e);
    }

    /**
     * Formats error message.
     *
     * @param environment
     * @param healthEndpoint
     * @param e
     * @return
     */
    public static String formatErrorMessage(String environment, String healthEndpoint, Exception e) {
        StringBuilder sb = new StringBuilder();
        sb.append("Healthcheck failed: " + healthEndpoint);

        if (environment != null) {
            sb.append(", env: " + environment);
        }

        sb.append(", with reason: " + e.getMessage());

        Throwable rootCause = ExceptionUtils.getRootCause(e);

        if (rootCause != null) {
            sb.append(", caused by: " + rootCause.getMessage());

            if (rootCause instanceof HttpStatusCodeException) {
                sb.append(", with response: " + ((HttpStatusCodeException) rootCause).getResponseBodyAsString());
            }
        }

        return sb.toString();
    }

    /**
     * Does this.
     *
     * @param downtimePeriodValue
     * @return
     */
    public static boolean isBetweenExceptedDowntimePeriod(String downtimePeriodValue) {
        String[] values = HealthCheckUtil.parseDowntimePeriodValue(downtimePeriodValue);

        String startTime = values[0];
        String endTime = values[1];
        String timeZoneId = values[2];

        DateTime currentTime;

        if (timeZoneId == null) {
            currentTime = DateTime.now();
        } else {
            currentTime = DateTime.now(DateTimeZone.forID(timeZoneId));
        }

        APP_LOGGER.info("Current Time :: " + currentTime);

        return DateTimeComparator.betweenExceptedDuration(currentTime, startTime, endTime);
    }

    /**
     * Parse Downtime period value.
     *
     * @param downtimePeriodValue
     * @return
     */
    protected static String[] parseDowntimePeriodValue(String downtimePeriodValue) {
        String startTime;
        String endTime;
        String timeZoneId;

        String[] values = downtimePeriodValue.split(" ");

        if (values.length == 0 || values.length > 2) {
            throw generateInvalidDowntimeException(downtimePeriodValue);
        }

        if (values.length == 2) {
            timeZoneId = values[1];
        } else {
            timeZoneId = null;
        }

        String[] timeValues = values[0].split("-");
        if (timeValues.length == 2) {
            startTime = timeValues[0];
            endTime = timeValues[1];
        } else {
            throw generateInvalidDowntimeException(downtimePeriodValue);
        }

        return new String[] { startTime, endTime, timeZoneId };
    }

    private static RuntimeException generateInvalidDowntimeException(String downtimeValue) {
        return new RuntimeException(
                "Invalid downtime period value: " + downtimeValue + ". Must be in format of 'HH:mm:ss-HH:mm:ss' or 'HH:mm:ss-HH:mm:ss TimeZoneId'");
    }
}
