////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.common.constant;

/**
 * The class {@code CommonConstants} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public final class CommonConstants {

    public static final String X_CORRELATION_ID_FIELD_NAME = "X-Correlation-Id";
    public static final String X_CLIENT_ID_FIELD_NAME = "X-Client-Id";
    public static final String X_CLIENT_VERSION_FIELD_NAME = "X-Client-Version";
    public static final String ACCEPT_FIELD_NAME = "Accept";
    public static final String CONTENT_TYPE_FIELD_NAME = "Content-Type";
    public static final String ENTITLEMENT_ID_FIELD_NAME = "X-Entitlement-Info";

    public static final String HEALTH_CHECK = "HEALTHCHECK";

    public static final String REST_BASE_URL_PATTERN = "/wealth/v1/accounts";

    public static final String APPLICATION_JSON_API_VALUE = "application/vnd.api+json";
    public static final String ACCEPT_APPLICATION_JSON_API_VALUE = "Accept=" + APPLICATION_JSON_API_VALUE;

    /**
     * Default constructor.
     */
    private CommonConstants() {
    }
}
