////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.common.rest.util.validator.constraint.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import au.com.suncorp.wealth.api.common.rest.util.validator.constraint.AtLeastOneNotBlank;
import org.apache.commons.beanutils.PropertyUtils;

/**
 * The class {@code AtLeastOneNotBlankValidator} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class AtLeastOneNotBlankValidator implements ConstraintValidator<AtLeastOneNotBlank, Object> {
    private String[] fieldNames;

    /**
     * Does this.
     *
     * @param constraintAnnotation
     */
    @Override
    public void initialize(AtLeastOneNotBlank constraintAnnotation) {
        this.fieldNames = constraintAnnotation.fieldNames();
    }

    /**
     * Does this.
     *
     * @param object
     * @param context
     * @return
     */
    @Override
    public boolean isValid(Object object, ConstraintValidatorContext context) {
        if (object == null) {
            return false;
        }
        for (String fieldName : fieldNames) {
            try {
                Object property = PropertyUtils.getProperty(object, fieldName);
                if (!isBlankProperty(property)) {
                    return true;
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return false;

    }

    /**
     * Does this.
     *
     * @param property
     * @return
     */
    private boolean isBlankProperty(Object property) {
        if (property == null) {
            return true;
        }

        if (property instanceof String) {
            String str = (String) property;
            if (str.isEmpty()) {
                return true;
            }
        }

        return false;
    }
}
