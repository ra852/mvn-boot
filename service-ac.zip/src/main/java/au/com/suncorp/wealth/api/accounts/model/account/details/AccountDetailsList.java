////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

import java.util.List;

/**
 * The class {@code AccountDetailsList} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class AccountDetailsList {
    private AccountDetails account;
    private AccountDetailBean accountDetail;
    private ProductDetails product;
    private IdentityIdentifier currentExpenseGroup;
    private List<ClientAccountRelationshipBean> clientAccountRelationships;
    private List<InvestmentProfileDetails> investmentProfiles;
    private String accountBalance;
    private List<ExternalReference> externalReferences;
    private List<RiderDetails> insurances;

    /**
     * Accessor for property account.
     *
     * @return account of type AccountDetails
     */
    public AccountDetails getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     *
     * @param account of type AccountDetails
     */
    public void setAccount(AccountDetails account) {
        this.account = account;
    }

    /**
     * Accessor for property accountDetail.
     *
     * @return accountDetail of type AccountDetailBean
     */
    public AccountDetailBean getAccountDetail() {
        return accountDetail;
    }

    /**
     * Mutator for property accountDetail.
     *
     * @param accountDetail of type AccountDetailBean
     */
    public void setAccountDetail(AccountDetailBean accountDetail) {
        this.accountDetail = accountDetail;
    }

    /**
     * Accessor for property product.
     *
     * @return product of type ProductDetails
     */
    public ProductDetails getProduct() {
        return product;
    }

    /**
     * Mutator for property product.
     *
     * @param product of type ProductDetails
     */
    public void setProduct(ProductDetails product) {
        this.product = product;
    }

    /**
     * Accessor for property currentExpenseGroup.
     *
     * @return currentExpenseGroup of type IdentityIdentifier
     */
    public IdentityIdentifier getCurrentExpenseGroup() {
        return currentExpenseGroup;
    }

    /**
     * Mutator for property currentExpenseGroup.
     *
     * @param currentExpenseGroup of type IdentityIdentifier
     */
    public void setCurrentExpenseGroup(IdentityIdentifier currentExpenseGroup) {
        this.currentExpenseGroup = currentExpenseGroup;
    }

    /**
     * Accessor for property clientAccountRelationships.
     *
     * @return clientAccountRelationships of type List<ClientAccountRelationshipBean>
     */
    public List<ClientAccountRelationshipBean> getClientAccountRelationships() {
        return clientAccountRelationships;
    }

    /**
     * Mutator for property clientAccountRelationships.
     *
     * @param clientAccountRelationships of type List<ClientAccountRelationshipBean>
     */
    public void setClientAccountRelationships(List<ClientAccountRelationshipBean> clientAccountRelationships) {
        this.clientAccountRelationships = clientAccountRelationships;
    }

    /**
     * Accessor for property investmentProfiles.
     *
     * @return investmentProfiles of type List<InvestmentProfileDetails>
     */
    public List<InvestmentProfileDetails> getInvestmentProfiles() {
        return investmentProfiles;
    }

    /**
     * Mutator for property investmentProfiles.
     *
     * @param investmentProfiles of type List<InvestmentProfileDetails>
     */
    public void setInvestmentProfiles(List<InvestmentProfileDetails> investmentProfiles) {
        this.investmentProfiles = investmentProfiles;
    }

    /**
     * Accessor for property accountBalance.
     *
     * @return accountBalance of type String
     */
    public String getAccountBalance() {
        return accountBalance;
    }

    /**
     * Mutator for property accountBalance.
     *
     * @param accountBalance of type String
     */
    public void setAccountBalance(String accountBalance) {
        this.accountBalance = accountBalance;
    }

    /**
     * Accessor for property externalReferences.
     *
     * @return externalReferences of type List<ExternalReference>
     */
    public List<ExternalReference> getExternalReferences() {
        return externalReferences;
    }

    /**
     * Mutator for property externalReferences.
     *
     * @param externalReferences of type List<ExternalReference>
     */
    public void setExternalReferences(List<ExternalReference> externalReferences) {
        this.externalReferences = externalReferences;
    }

    /**
     * Accessor for property insurances.
     *
     * @return insurances of type List<RiderDetails>
     */
    public List<RiderDetails> getInsurances() {
        return insurances;
    }

    /**
     * Mutator for property insurances.
     *
     * @param insurances of type List<RiderDetails>
     */
    public void setInsurances(List<RiderDetails> insurances) {
        this.insurances = insurances;
    }

}
