////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * The class {@code AccountServiceProperties} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@ConfigurationProperties("sil-service")
public class AccountServiceProperties {
    private String hostName;
    private HeaderValues header;
    private int timeout;

    /**
     * Accessor for property hostName.
     *
     * @return hostName of type String
     */
    public String getHostName() {
        return hostName;
    }

    /**
     * Mutator for property hostName.
     *
     * @param hostName of type String
     */

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    /**
     * Accessor for property header.
     *
     * @return header of type HeaderValues
     */
    public HeaderValues getHeader() {
        return header;
    }

    /**
     * Mutator for property header.
     *
     * @param header of type HeaderValues
     */

    public void setHeader(HeaderValues header) {
        this.header = header;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    /**
     * The class {@code HeaderValues} does this.
     *
     * @author u201468
     * @since 9Feb.,2018
     * @version 1.0
     */
    public static class HeaderValues {

        private String username;
        private String password;
        private String key;
        private String value;

        /**
         * Accessor for property username.
         *
         * @return username of type String
         */
        public String getUsername() {
            return username;
        }

        /**
         * Mutator for property username.
         *
         * @param username of type String
         */

        public void setUsername(String username) {
            this.username = username;
        }

        /**
         * Accessor for property.
         *
         * @return type String
         */
        public String getPassword() {
            return password;
        }

        /**
         * Mutator for property.
         *
         * @param type String
         */

        public void setPassword(String password) {
            this.password = password;
        }

        /**
         * Accessor for property key.
         *
         * @return key of type String
         */
        public String getKey() {
            return key;
        }

        /**
         * Mutator for property key.
         *
         * @param key of type String
         */

        public void setKey(String key) {
            this.key = key;
        }

        /**
         * Accessor for property value.
         *
         * @return value of type String
         */
        public String getValue() {
            return value;
        }

        /**
         * Mutator for property value.
         *
         * @param value of type String
         */

        public void setValue(String value) {
            this.value = value;
        }

    }
}
