////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code IncludeInRebalancingBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class IncludeInRebalancingBean {
    private FrequencyIdentifierBean rebalancingFrequency;
    private String nextRebalanceDate;
    private String rebalanceImmediately;
    private String includeInRebalance;
    private CodeIdentifier instructorCategoryCode;

    /**
     * Accessor for property rebalancingFrequency.
     * 
     * @return rebalancingFrequency of type FrequencyIdentifierBean
     */
    public FrequencyIdentifierBean getRebalancingFrequency() {
        return rebalancingFrequency;
    }

    /**
     * Mutator for property rebalancingFrequency.
     * 
     * @param rebalancingFrequency of type FrequencyIdentifierBean
     */
    public void setRebalancingFrequency(FrequencyIdentifierBean rebalancingFrequency) {
        this.rebalancingFrequency = rebalancingFrequency;
    }

    /**
     * Accessor for property nextRebalanceDate.
     * 
     * @return nextRebalanceDate of type String
     */
    public String getNextRebalanceDate() {
        return nextRebalanceDate;
    }

    /**
     * Mutator for property nextRebalanceDate.
     * 
     * @param nextRebalanceDate of type String
     */
    public void setNextRebalanceDate(String nextRebalanceDate) {
        this.nextRebalanceDate = nextRebalanceDate != null ? nextRebalanceDate : "";
    }

    /**
     * Accessor for property rebalanceImmediately.
     * 
     * @return rebalanceImmediately of type String
     */
    public String getRebalanceImmediately() {
        return rebalanceImmediately;
    }

    /**
     * Mutator for property rebalanceImmediately.
     * 
     * @param rebalanceImmediately of type String
     */
    public void setRebalanceImmediately(String rebalanceImmediately) {
        this.rebalanceImmediately = rebalanceImmediately != null ? rebalanceImmediately : "";
    }

    /**
     * Accessor for property includeInRebalance.
     * 
     * @return includeInRebalance of type String
     */
    public String getIncludeInRebalance() {
        return includeInRebalance;
    }

    /**
     * Mutator for property includeInRebalance.
     * 
     * @param includeInRebalance of type String
     */
    public void setIncludeInRebalance(String includeInRebalance) {
        this.includeInRebalance = includeInRebalance != null ? includeInRebalance : "";
    }

    /**
     * Accessor for property instructorCategoryCode.
     * 
     * @return instructorCategoryCode of type CodeIdentifier
     */
    public CodeIdentifier getInstructorCategoryCode() {
        return instructorCategoryCode;
    }

    /**
     * Mutator for property instructorCategoryCode.
     * 
     * @param instructorCategoryCode of type CodeIdentifier
     */
    public void setInstructorCategoryCode(CodeIdentifier instructorCategoryCode) {
        this.instructorCategoryCode = instructorCategoryCode;
    }

}
