////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model;

import java.io.Serializable;
import java.util.List;

import org.beanio.annotation.Record;
import org.beanio.annotation.Segment;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code Account} does this.
 *
 * @author u201468
 * @since 15Jan.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
@Record(minOccurs = 0, name = "Account")
@JsonInclude(Include.NON_EMPTY)
public class Account implements Serializable {
    @JsonIgnore
    private String accountNumber;
    @ApiModelProperty(position = 2, example = "Suspened")
    private String accountStatus;
    @ApiModelProperty(position = 3, example = "2018-02-12")
    private String startDate;
    @ApiModelProperty(position = 4, example = "BPAY")
    private String bpayCustomerRefNumber;
    @ApiModelProperty(position = 5)
    @Segment(name = "accountBalance")
    private Amount accountBalance;
    @ApiModelProperty(position = 6)
    @Segment(name = "billerCodes")
    private List<BillerCode> billerCodes;
    @JsonIgnore
    private Product productDetails;
    @JsonIgnore
    private List<RiderInfo> insurances;
    @ApiModelProperty(position = 9)
    @Segment(name = "investmentSummary")
    private List<InvestmentMix> investmentSummary;

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getBpayCustomerRefNumber() {
        return bpayCustomerRefNumber;
    }

    public void setBpayCustomerRefNumber(String bpayCustomerRefNumber) {
        this.bpayCustomerRefNumber = bpayCustomerRefNumber;
    }

    public Amount getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(Amount accountBalance) {
        this.accountBalance = accountBalance;
    }

    public List<BillerCode> getBillerCodes() {
        return billerCodes;
    }

    public void setBillerCodes(List<BillerCode> billerCodes) {
        this.billerCodes = billerCodes;
    }

    public Product getProductDetails() {
        return productDetails;
    }

    public void setProductDetails(Product productDetails) {
        this.productDetails = productDetails;
    }

    public List<RiderInfo> getInsurances() {
        return insurances;
    }

    public void setInsurances(List<RiderInfo> insurances) {
        this.insurances = insurances;
    }

    public List<InvestmentMix> getInvestmentSummary() {
        return investmentSummary;
    }

    public void setInvestmentSummary(List<InvestmentMix> investmentSummary) {
        this.investmentSummary = investmentSummary;
    }

}
