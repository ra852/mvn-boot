////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.stub;

import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;

import java.io.File;
import java.net.URL;

import org.apache.commons.io.FileUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The class {@code JsonToObjectMapper} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 * @param <T>
 */
public class JsonToObjectMapper<T> {
    private final Class<T> typeClass;

    /**
     * Parameterised constructor.
     *
     * @param typeClass
     */
    public JsonToObjectMapper(Class<T> typeClass) {
        this.typeClass = typeClass;
    }

    /**
     * Map from string
     *
     * @param content
     * @return
     */
    public T mapFromString(String content) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.findAndRegisterModules();

        try {
            return mapper.readValue(content, typeClass);
        } catch (Exception e) {
            throw new RuntimeException("Failed to map " + typeClass + " from: " + content);
        }
    }

    /**
     * Does this.
     *
     * @param filename
     * @return
     */
    public T mapFromFile(String filename) {
        return mapFromString(readJsonFile(filename));
    }

    /**
     * Reads JSON from file.
     *
     * @param filename
     * @return
     */
    private String readJsonFile(String filename) {
        URL url = this.getClass().getResource(filename);

        try {
            File file = new File(url.toURI());
            // return FileUtils.readFileToString(file, Charset.defaultCharset());
            return FileUtils.readFileToString(file);
        } catch (Exception e) {
            throw new RuntimeException("Failed to read file: " + filename);
        }
    }
}
