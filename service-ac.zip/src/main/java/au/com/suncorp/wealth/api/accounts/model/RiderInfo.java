////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model;

import org.beanio.annotation.Record;
import org.beanio.annotation.Segment;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code RiderInfo} is a java bean consisting of properties related to RiderDetails.
 * 
 * @author u385424
 * @since 05/05/2016
 * @version 1.0
 */
@Record(minOccurs = 1, name = "RiderInfo")
@JsonInclude(Include.NON_EMPTY)
public class RiderInfo {
    @JsonIgnore
    private String id;
    @ApiModelProperty(position = 2, example = "Life Cover")
    private String insuranceType;
    @ApiModelProperty(position = 3, example = "DETH")
    private String insuranceTypeId;
    private InsuranceStatus insuranceStatus;
    @ApiModelProperty(position = 4, example = "2008-07-23")
    private String lastRenewalDate;
    @ApiModelProperty(position = 5, example = "25 years")
    private String benefitPeriod;
    @ApiModelProperty(position = 6, example = "28 days")
    private String waitPeriod;
    @ApiModelProperty(position = 7)
    @Segment(name = "coverAmount")
    private Amount coverAmount;
    @ApiModelProperty(position = 8)
    @Segment(name = "annualPremium")
    private Amount annualPremium;
    @ApiModelProperty(position = 9)
    @Segment(name = "monthlyPremium")
    private Amount monthlyPremium;
    @ApiModelProperty(position = 10, example = "70")
    private String expiryAge;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getInsuranceType() {
        return insuranceType;
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    public String getInsuranceTypeId() {
        return insuranceTypeId;
    }

    public void setInsuranceTypeId(String insuranceTypeId) {
        this.insuranceTypeId = insuranceTypeId;
    }

    public InsuranceStatus getInsuranceStatus() {
        return insuranceStatus;
    }

    public void setInsuranceStatus(InsuranceStatus insuranceStatus) {
        this.insuranceStatus = insuranceStatus;
    }

    public String getLastRenewalDate() {
        return lastRenewalDate;
    }

    public void setLastRenewalDate(String lastRenewalDate) {
        this.lastRenewalDate = lastRenewalDate;
    }

    public String getBenefitPeriod() {
        return benefitPeriod;
    }

    public void setBenefitPeriod(String benefitPeriod) {
        this.benefitPeriod = benefitPeriod;
    }

    public String getWaitPeriod() {
        return waitPeriod;
    }

    public void setWaitPeriod(String waitPeriod) {
        this.waitPeriod = waitPeriod;
    }

    public Amount getCoverAmount() {
        return coverAmount;
    }

    public void setCoverAmount(Amount coverAmount) {
        this.coverAmount = coverAmount;
    }

    public Amount getAnnualPremium() {
        return annualPremium;
    }

    public void setAnnualPremium(Amount annualPremium) {
        this.annualPremium = annualPremium;
    }

    public Amount getMonthlyPremium() {
        return monthlyPremium;
    }

    public void setMonthlyPremium(Amount monthlyPremium) {
        this.monthlyPremium = monthlyPremium;
    }

    public String getExpiryAge() {
        return expiryAge;
    }

    public void setExpiryAge(String expiryAge) {
        this.expiryAge = expiryAge;
    }

}
