////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.config;

import javax.servlet.Filter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import au.com.suncorp.wealth.api.common.filter.LoggingFilter;

/**
 * The class {@code FilterConfiguration} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@Configuration
public class FilterConfiguration {

    /**
     * Does this.
     */
    @Bean
    public FilterRegistrationBean loggingFilterRegistrationBean() {
        return getFilterRegistrationBean(new LoggingFilter(), FilterRegistrationBean.HIGHEST_PRECEDENCE);
    }

    /**
     * Get FilterRegistrationBean.
     *
     * @param filter
     * @param order
     * @return
     */
    private FilterRegistrationBean getFilterRegistrationBean(Filter filter, int order) {
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();

        filterRegistrationBean.setFilter(filter);
        filterRegistrationBean.setOrder(order);

        return filterRegistrationBean;
    }
}
