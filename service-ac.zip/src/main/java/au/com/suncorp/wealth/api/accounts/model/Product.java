////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model;

import org.beanio.annotation.Record;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code Product} does this.
 *
 * @author u201468
 * @since 15Jan.,2018
 * @version 1.0
 */
@Record(minOccurs = 1, name = "Product")
@JsonInclude(Include.NON_EMPTY)
public class Product {
    @JsonIgnore
    private String id;
    @ApiModelProperty(position = 2, example = "Suncorp Brighter Super")
    private String name;
    @ApiModelProperty(position = 3, example = "Brighter Super")
    private String shortName;
    @ApiModelProperty(position = 4, example = "Suncorp")
    private String brand;
    @ApiModelProperty(position = 5, example = "Brighter Super")
    private String productFamilyName;
    @ApiModelProperty(position = 6, example = "SCSP")
    private String productTypeCode;
    @ApiModelProperty(position = 7, example = "98350952022")
    private String abn;
    @ApiModelProperty(position = 8, example = "98350952022123")
    private String usi;
    @ApiModelProperty(position = 9, example = "everydaysuper@suncorp.com.au")
    private String customerCareEmail;
    @ApiModelProperty(position = 10, example = "Suncorp Brighter Super for business")
    private String description;
    @ApiModelProperty(position = 11, example = "Wealth")
    private String domain;
    @ApiModelProperty(position = 12, example = "40000001")
    private String productSystemProductSubCode;
    @ApiModelProperty(position = 13, example = "400000")
    private String productSystemProductCode;
    @ApiModelProperty(position = 14, example = "SNT")
    private String productSystemCode;
    @ApiModelProperty(position = 15, example = "Superannuation")
    private String marketplaceProductType;

    public Product() {
    }

    /**
     * Does this.
     *
     * @param id
     * @param name
     * @param shortName
     * @param abn
     * @param usi
     */
    public Product(String id, String name, String shortName, String brand, String productFamilyName, String productTypeCode, String abn, String usi,
            String customerCareEmail) {
        super();
        this.id = id;
        this.name = name;
        this.shortName = shortName;
        this.brand = brand;
        this.productFamilyName = productFamilyName;
        this.productTypeCode = productTypeCode;
        this.abn = abn;
        this.usi = usi;
        this.customerCareEmail = customerCareEmail;
    }

    public Product(String id, String name, String shortName, String brand, String productFamilyName, String productTypeCode, String abn, String usi,
            String customerCareEmail, String description, String domain, String productSystemProductSubCode, String productSystemProductCode,
            String productSystemCode, String marketplaceProductType) {
        super();
        this.id = id;
        this.name = name;
        this.shortName = shortName;
        this.brand = brand;
        this.productFamilyName = productFamilyName;
        this.productTypeCode = productTypeCode;
        this.abn = abn;
        this.usi = usi;
        this.customerCareEmail = customerCareEmail;
        this.description = description;
        this.domain = domain;
        this.productSystemProductSubCode = productSystemProductSubCode;
        this.productSystemProductCode = productSystemProductCode;
        this.productSystemCode = productSystemCode;
        this.marketplaceProductType = marketplaceProductType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getProductFamilyName() {
        return productFamilyName;
    }

    public void setProductFamilyName(String productFamilyName) {
        this.productFamilyName = productFamilyName;
    }

    public String getProductTypeCode() {
        return productTypeCode;
    }

    public void setProductTypeCode(String productTypeCode) {
        this.productTypeCode = productTypeCode;
    }

    public String getAbn() {
        return abn;
    }

    public void setAbn(String abn) {
        this.abn = abn;
    }

    public String getUsi() {
        return usi;
    }

    public void setUsi(String usi) {
        this.usi = usi;
    }

    public String getCustomerCareEmail() {
        return customerCareEmail;
    }

    public void setCustomerCareEmail(String customerCareEmail) {
        this.customerCareEmail = customerCareEmail;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getProductSystemProductSubCode() {
        return productSystemProductSubCode;
    }

    public void setProductSystemProductSubCode(String productSystemProductSubCode) {
        this.productSystemProductSubCode = productSystemProductSubCode;
    }

    public String getProductSystemProductCode() {
        return productSystemProductCode;
    }

    public void setProductSystemProductCode(String productSystemProductCode) {
        this.productSystemProductCode = productSystemProductCode;
    }

    public String getProductSystemCode() {
        return productSystemCode;
    }

    public void setProductSystemCode(String productSystemCode) {
        this.productSystemCode = productSystemCode;
    }

    public String getMarketplaceProductType() {
        return marketplaceProductType;
    }

    public void setMarketplaceProductType(String marketplaceProductType) {
        this.marketplaceProductType = marketplaceProductType;
    }
}
