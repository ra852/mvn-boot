////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.exception;

import org.springframework.http.HttpStatus;

import au.com.suncorp.wealth.api.accounts.model.ParameterBean;

/**
 * The class {@code MainAccountServiceRuntimeException} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public abstract class MainAccountServiceRuntimeException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private final String id;
    private final String title;
    private final String detail;
    private final ParameterBean parameterBean;

    /**
     * Constructor.
     */
    public MainAccountServiceRuntimeException() {
        super();
        this.id = null;
        this.title = null;
        this.detail = null;
        this.parameterBean = null;
    }

    /**
     * Parameterised constructor.
     *
     * @param cause
     */
    public MainAccountServiceRuntimeException(Throwable cause) {
        super(cause);
        this.id = null;
        this.title = null;
        this.detail = null;
        this.parameterBean = null;
    }

    /**
     * Parameterised constructor.
     *
     * @param message
     */
    public MainAccountServiceRuntimeException(String message) {
        super(message);
        this.id = null;
        this.title = null;
        this.detail = null;
        this.parameterBean = null;
    }

    /**
     * Parameterised constructor for MainAccountServiceRuntimeException.
     *
     * @param id
     * @param title
     * @param detail
     */
    public MainAccountServiceRuntimeException(String id, String title, String detail) {
        super();
        this.id = id;
        this.title = title;
        this.detail = detail;
        this.parameterBean = null;
    }

    /**
     * Parameterised constructor for MainAccountServiceRuntimeException.
     *
     * @param id
     * @param title
     * @param detail
     * @param parameterBean
     */
    public MainAccountServiceRuntimeException(String id, String title, String detail, ParameterBean parameterBean) {
        super();
        this.id = id;
        this.title = title;
        this.detail = detail;
        this.parameterBean = parameterBean;
    }

    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Accessor for property title.
     *
     * @return title of type String
     */
    public String getTitle() {
        return title;
    }

    /**
     * Accessor for property detail.
     *
     * @return detail of type String
     */
    public String getDetail() {
        return detail;
    }

    /**
     * Accessor for property parameterBean.
     *
     * @return parameterBean of type ParameterBean
     */
    public ParameterBean getParameterBean() {
        return parameterBean;
    }

    /**
     * Accessor for property title.
     *
     * @return title
     */
    @Override
    public String getMessage() {
        return title;
    }

    public abstract HttpStatus getHttpStatus();
}
