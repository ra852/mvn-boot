////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.rest;

import static au.com.suncorp.wealth.api.common.constant.CommonConstants.REST_BASE_URL_PATTERN;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import au.com.suncorp.wealth.api.accounts.config.properties.RestClientProperties;

/**
 * The class {@code UriHelperService} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@Component
public class UriHelperService {

    private RestClientProperties restClientProperties;

    /**
     * Parameterised constructor.
     *
     * @param restClientProperties
     */
    @Autowired
    public UriHelperService(RestClientProperties restClientProperties) {
        this.restClientProperties = restClientProperties;
    }

    /**
     * Get Uri For Wealth API.
     */
    public URI getUriForWealthAPI() {
        return UriComponentsBuilder.fromHttpUrl(restClientProperties.getWealthApiBaseUrl()).path(restClientProperties.getContextPath()).build()
                .toUri();
    }

    /**
     * Builds Parent Resource Link.
     *
     * @param baseUri
     * @param accountResourceType
     * @return
     */
    public static UriComponents buildParentResourceLink(URI baseUri, String accountResourceType) {
        return UriComponentsBuilder.fromUri(baseUri).path(REST_BASE_URL_PATTERN).build();
    }

    /**
     * Builds Resource Link By Id.
     *
     * @param baseUri
     * @param accountResourceType
     * @param accountNumber
     * @return
     */
    public static UriComponents buildResourceLinkById(URI baseUri, String accountResourceType, String accountNumber) {
        return UriComponentsBuilder.fromUri(buildParentResourceLink(baseUri, accountResourceType).toUri()).pathSegment(accountNumber).build();
    }

    /**
     * Builds Resource Link With Relationships.
     *
     * @param baseUri
     * @param accountResourceType
     * @param accountNumber
     * @param segments
     * @return
     */
    public static UriComponents buildResourceLinkWithRelationships(URI baseUri, String accountResourceType, String accountNumber,
            String... segments) {
        return UriComponentsBuilder.fromUri(buildResourceLinkById(baseUri, accountResourceType, accountNumber).toUri()).pathSegment(segments).build();
    }
}
