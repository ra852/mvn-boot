////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2018, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.config;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Sets.newHashSet;
import static springfox.documentation.builders.PathSelectors.regex;
import static springfox.documentation.schema.AlternateTypeRules.newRule;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.async.DeferredResult;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.classmate.TypeResolver;
import com.google.common.base.Predicate;

import au.com.suncorp.wealth.api.accounts.config.properties.SwaggerProperties;
import au.com.suncorp.wealth.api.common.constant.CommonConstants;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ImplicitGrantBuilder;
import springfox.documentation.builders.OAuthBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.WildcardType;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Contact;
import springfox.documentation.service.GrantType;
import springfox.documentation.service.LoginEndpoint;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.paths.AbstractPathProvider;
import springfox.documentation.spring.web.paths.Paths;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.ApiKeyVehicle;
import springfox.documentation.swagger.web.SecurityConfiguration;
import springfox.documentation.swagger.web.UiConfiguration;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * The class {@code SwaggerConfiguration} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@Configuration
@EnableConfigurationProperties(SwaggerProperties.class)
@EnableSwagger2
public class SwaggerConfiguration {
    private static final String DEFAULT_INCLUDE_PATTERN = CommonConstants.REST_BASE_URL_PATTERN + ".*";

    @Autowired
    private SwaggerProperties swaggerProperties;

    @Autowired
    private TypeResolver typeResolver;

    @Value("${server.context-path}")
    private String contextPath;

    /**
     * 
     * Does this.
     *
     * @return
     */
    private String getContextPath() {
        return contextPath;
    }

    /**
     * Does this.
     */
    @Bean
    public Docket Api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .protocols(newHashSet("http", "https"))
                .apiInfo(apiInfo()).select()
                .apis(RequestHandlerSelectors.any())
                .paths(apiPaths())
                .build().pathMapping("/")
                .pathProvider(new BasePathAwareRelativePathProvider("/wealth/v1/accounts"))
                .genericModelSubstitutes(ResponseEntity.class)
                .alternateTypeRules(
                        newRule(typeResolver.resolve(DeferredResult.class, typeResolver.resolve(ResponseEntity.class, WildcardType.class)),
                                typeResolver.resolve(WildcardType.class)))
                .useDefaultResponseMessages(false)
                .securitySchemes(newArrayList(oauth()))
                .securityContexts(newArrayList(securityContext()))
                .enableUrlTemplating(false);
    }

    class BasePathAwareRelativePathProvider extends AbstractPathProvider {
        private String basePath;

        BasePathAwareRelativePathProvider(String basePath) {
            this.basePath = basePath;
        }

        @Override
        protected String applicationPath() {
            return getContextPath() + basePath;
        }

        @Override
        protected String getDocumentationPath() {
            return "/";
        }

        @Override
        public String getOperationPath(String operationPath) {
            UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromPath("");
            return Paths.removeAdjacentForwardSlashes(uriComponentsBuilder.path(operationPath.replaceFirst(basePath, "")).build().toString());
        }
    }

    /**
     * Builds oAuth.
     */
    @Bean
    SecurityScheme oauth() {
        return new OAuthBuilder().name("wealth_auth").grantTypes(grantTypes()).scopes(scopes()).build();
    }

    /**
     * Used to define oAuth.
     */
    List<AuthorizationScope> scopes() {
        return newArrayList(new AuthorizationScope("wealth:write", "Write information about the wealth data."),
                new AuthorizationScope("wealth:read", "Read information about the wealth data."));
    }

    /**
     * Path for oAuth.
     */
    List<GrantType> grantTypes() {
        GrantType grantType = new ImplicitGrantBuilder().loginEndpoint(new LoginEndpoint("http://api-nonprod.int.corp.sun/oauth2/token")).build();
        return newArrayList(grantType);
    }

    /**
     * Optional swagger-ui security configuration for oauth and apiKey settings.
     */
    @Bean
    public SecurityConfiguration security() {
        return new SecurityConfiguration("test-app-client-id", "test-app-client-secret", "test-app-realm", "test-app", "apiKey", ApiKeyVehicle.HEADER,
                "api_key", ",");
    }

    /**
     * Optional swagger-ui ui configuration currently only supports the validation url.
     */
    @Bean
    public UiConfiguration uiConfig() {
        return new UiConfiguration(null);
    }

    /**
     * Get details like title, description, contact etc. for swagger.
     */
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder().title(swaggerProperties.getTitle())
                .description(swaggerProperties.getDescription())
                .termsOfServiceUrl(swaggerProperties.getTermsOfServiceUrl())
                .contact(new Contact(swaggerProperties.getContact().getName(), swaggerProperties.getContact().getUrl(),
                        swaggerProperties.getContact().getEmail()))
                .license(swaggerProperties.getLicense())
                .licenseUrl(swaggerProperties.getLicenseUrl())
                .version(swaggerProperties.getVersion())
                .build();
    }

    /**
     * Allows selection of Path's using a predicate. The example here uses an `any predicate (default).
     */
    private Predicate<String> apiPaths() {
        return regex(DEFAULT_INCLUDE_PATTERN);
    }

    /**
     * Provides a way to globally set up security contexts for operation. The idea here is that we provide a way to select operations to be protected
     * by one of the specified security schemes.
     */
    private SecurityContext securityContext() {
        return SecurityContext.builder()
                .securityReferences(defaultAuth())
                .forPaths(regex("/anyPath.*")) // Selector for the paths this
                .build();
    }

    /**
     * Used for Authorization Scope.
     */
    private List<SecurityReference> defaultAuth() {
        AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;
        return newArrayList(new SecurityReference("mykey", authorizationScopes));
    }
}
