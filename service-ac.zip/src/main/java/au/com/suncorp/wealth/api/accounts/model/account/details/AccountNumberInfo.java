////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code AccountDetails} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class AccountNumberInfo {
    private String accountNo;
    private String productName;

    /**
     * Accessor for property accountNo.
     * 
     * @return accountNo of type String
     */
    public String getAccountNo() {
        return accountNo;
    }

    /**
     * Mutator for property accountNo.
     * 
     * @param accountNo of type String
     */
    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo != null ? accountNo : "";
    }

    /**
     * Accessor for property productName.
     * 
     * @return productName of type String
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Mutator for property productName.
     * 
     * @param productName of type String
     */
    public void setProductName(String productName) {
        this.productName = productName != null ? productName : "";
    }

}
