////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.provider;

import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_INVALID_RESPONSE;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.LBL_RUNTIME_ID;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.FALIED_RES_HEALTH_MSG;
import static au.com.suncorp.wealth.api.accounts.constant.Constants.HEALTH;

import java.net.URI;
import java.util.AbstractMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;

import au.com.suncorp.wealth.api.accounts.config.properties.AccountServiceProperties;
import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.model.Account;
import au.com.suncorp.wealth.api.accounts.model.AccountRelationships;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import au.com.suncorp.wealth.api.accounts.model.Product;
import au.com.suncorp.wealth.api.accounts.model.RiderInfo;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetAccountDetailsResponse;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetInvestmentBalanceResponseBean;
import au.com.suncorp.wealth.api.accounts.provider.mapper.AccountMapper;
import au.com.suncorp.wealth.api.accounts.rest.DomainApiService;
import au.com.suncorp.wealth.api.accounts.rest.dto.response.AccountResponseDTO;
import au.com.suncorp.wealth.api.accounts.rest.dto.response.InsuranceResponseDTO;
import au.com.suncorp.wealth.api.accounts.rest.dto.response.ProductResponseDTO;
import au.com.suncorp.wealth.api.accounts.utils.AccountUtil;
import au.com.suncorp.wealth.api.accounts.utils.GetAccountDetailsUtil;
import au.com.suncorp.wealth.api.accounts.utils.InvestmentServiceUtil;

/**
 * The class {@code AccountService} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class AccountService extends AccountUtil {
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(AccountService.class);

    private final RestTemplate restTemplate;
    private final AccountServiceProperties accountServiceProperties;

    /**
     * Parameterised constructor.
     *
     * @param restTemplate
     * @param accountServiceProperties
     */
    public AccountService(RestTemplate restTemplate, AccountServiceProperties accountServiceProperties) {
        this.restTemplate = restTemplate;
        this.accountServiceProperties = accountServiceProperties;
    }

    /**
     * Account service.
     *
     * @param baseUrl
     * @param accountNumber
     * @param pb
     * @return
     */
    public ResponseEntity<AccountResponseDTO> accounts(URI baseUrl, String accountNumber, DomainApiService domainApiService,
            GetAccountDetailsResponse getAccountDetailsResponse, GetInvestmentBalanceResponseBean getInvestmentBalanceResponse, ParameterBean pb) {
        log(APP_LOGGER, new StringBuilder("Entering accounts() -> ").append(accountNumber).toString());
        AccountMapper accountMapper = new AccountMapper();
        Map.Entry<Account, AccountRelationships> accountEntry =
                new AbstractMap.SimpleImmutableEntry<>(accountMapper.map(getAccountDetailsResponse, accountNumber, getInvestmentBalanceResponse),
                        accountMapper.mapRelationships(getAccountDetailsResponse));
        AccountResponseDTO accountResponseDTO =
                new AccountResponseDTO(baseUrl, accountEntry, getAccountDetailsResponse, restTemplate, domainApiService, accountNumber, pb);
        ResponseEntity<AccountResponseDTO> responseEntity = new ResponseEntity<>(accountResponseDTO, createHeaders(pb), HttpStatus.OK);
        log(APP_LOGGER, new StringBuilder("Returning response to consumer -> ").append(accountNumber).append("with following headers: ")
                .append(createHeaders(pb)).toString());
        return responseEntity;
    }

    /**
     * Insurance service.
     *
     * @param accountNumber
     * @param pb
     * @return
     */
    public ResponseEntity<InsuranceResponseDTO> insurances(String accountNumber, GetAccountDetailsResponse getAccountDetailsResponse,
            ParameterBean pb) {
        log(APP_LOGGER, new StringBuilder("Entering insurances() -> ").append(accountNumber).toString());
        AccountMapper accountMapper = new AccountMapper();
        List<RiderInfo> insuranceList = accountMapper.mapInsurance(getAccountDetailsResponse);
        InsuranceResponseDTO insuranceResponseDTO = new InsuranceResponseDTO(insuranceList);
        ResponseEntity<InsuranceResponseDTO> responseEntity = new ResponseEntity<>(insuranceResponseDTO, createHeaders(pb), HttpStatus.OK);
        log(APP_LOGGER, new StringBuilder("Returning response to consumer -> ").append(accountNumber).append("with following headers: ")
                .append(createHeaders(pb)).toString());
        return responseEntity;
    }

    /**
     * Product service.
     *
     * @param accountNumber
     * @param pb
     * @return
     */
    public ResponseEntity<ProductResponseDTO> products(String accountNumber, GetAccountDetailsResponse getAccountDetailsResponse, ParameterBean pb,
            DomainApiService domainApiService) {
        log(APP_LOGGER, new StringBuilder("Entering products() -> ").append(accountNumber).toString());
        AccountMapper accountMapper = new AccountMapper();
        Product product = accountMapper.mapProduct(getAccountDetailsResponse);
        ProductResponseDTO productResponseDTO = new ProductResponseDTO(product, pb, restTemplate, domainApiService, accountNumber);
        ResponseEntity<ProductResponseDTO> responseEntity = new ResponseEntity<>(productResponseDTO, createHeaders(pb), HttpStatus.OK);
        log(APP_LOGGER, new StringBuilder("Returning response to consumer -> ").append(accountNumber).append("with following headers: ")
                .append(createHeaders(pb)).toString());
        return responseEntity;
    }

    /**
     * Does this.
     *
     * @param accountNumber
     * @param pb
     * @return
     */
    @Async("threadPoolTaskExecutor")
    public CompletableFuture<GetAccountDetailsResponse> getAccountDetails(String accountNumber, ParameterBean pb) {
        GetAccountDetailsResponse getAccountDetailsResponse =
                new GetAccountDetailsUtil().callAccountDetailsService(restTemplate, accountServiceProperties, accountNumber, pb);
        return CompletableFuture.completedFuture(getAccountDetailsResponse);
    }

    /**
     * Does this.
     *
     * @param accountNumber
     * @param pb
     * @return
     */
    @Async("threadPoolTaskExecutor")
    public CompletableFuture<GetInvestmentBalanceResponseBean> getInvestmentDetails(String accountNumber, ParameterBean pb) {
        GetInvestmentBalanceResponseBean getInvestmentBalanceResponse =
                new InvestmentServiceUtil().callInvestmentService(restTemplate, accountServiceProperties, accountNumber, pb);
        return CompletableFuture.completedFuture(getInvestmentBalanceResponse);
    }

    /**
     * Does this.
     *
     * @param uriForWealthAPI
     * @return
     */
    public ResponseEntity<JsonNode> health(URI uriForWealthAPI) {
        String welathUri = uriForWealthAPI.toString();
        final String healthUrl = welathUri + HEALTH;
        try {
            ResponseEntity<JsonNode> responseEntity = restTemplate.exchange(healthUrl, HttpMethod.GET, null, JsonNode.class);
            return responseEntity;
        } catch (RestClientException rce) {
            throw new AccountServiceRuntimeException(getLogId(LBL_RUNTIME_ID), LBL_INVALID_RESPONSE, FALIED_RES_HEALTH_MSG, new ParameterBean());
        }
    }
}
