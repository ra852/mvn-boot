////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.common.util;

import static java.lang.Integer.parseInt;

import org.joda.time.DateTime;

/**
 * The class {@code DateTimeComparator} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public final class DateTimeComparator {

    /**
     * Default constructor.
     *
     */
    private DateTimeComparator() {
    }

    /**
     * Does this.
     *
     * @param currentTime
     * @param startTimeStr
     * @param endTimeStr
     * @return
     */
    public static boolean betweenExceptedDuration(DateTime currentTime, String startTimeStr, String endTimeStr) {
        DateTime startTime = parseDateTime(currentTime, startTimeStr);
        DateTime endTime = parseDateTime(currentTime, endTimeStr);

        if (endTime.isAfter(startTime)) {
            return !(currentTime.isBefore(startTime) || currentTime.isAfter(endTime));
        } else {
            return !currentTime.isBefore(startTime) || !currentTime.isAfter(endTime);
        }
    }

    /**
     * Parse date and time.
     *
     * @param currentTime
     * @param dateTimeStr
     * @return
     */
    private static DateTime parseDateTime(DateTime currentTime, String dateTimeStr) {
        String[] dateTimeStrList = dateTimeStr.split(":");
        int hour = parseInt(dateTimeStrList[0]);
        int minute = parseInt(dateTimeStrList[1]);
        int second = parseInt(dateTimeStrList[2]);

        return currentTime.withTime(hour, minute, second, 0);
    }
}
