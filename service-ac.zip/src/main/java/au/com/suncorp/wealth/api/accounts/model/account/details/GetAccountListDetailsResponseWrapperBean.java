////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

import com.google.gson.annotations.SerializedName;

/**
 * The class {@code GetAccountListDetailsResponseWrapperBean} is wrapper bean the GetAccountDetailsResponse.
 *
 * @author U383847
 * @since 13/09/2016
 * @version 1.0
 */
public class GetAccountListDetailsResponseWrapperBean {
    @SerializedName("GetAccountDetailsResponse")
    private GetAccountDetailsResponse getAccountDetailsResponse;

    /**
     * Accessor for property getAccountDetailsResponse.
     *
     * @return getAccountDetailsResponse of type GetAccountDetailsResponse
     */
    public GetAccountDetailsResponse getGetAccountDetailsResponse() {
        return getAccountDetailsResponse;
    }

    /**
     * Mutator for property getAccountDetailsResponse.
     *
     * @param getAccountDetailsResponse of type GetAccountDetailsResponse
     */
    public void setGetAccountDetailsResponse(GetAccountDetailsResponse getAccountDetailsResponse) {
        this.getAccountDetailsResponse = getAccountDetailsResponse;
    }

}
