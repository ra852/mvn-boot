////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.utils.security;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import org.apache.commons.io.FileUtils;




/**
 * KeyUtil provides methods to easily convert keyfiles to Java keys.
 * <p>
 * Static initializer will initialize the KeyUtil with enhanced security provider (BouncyCastle)
 *
 * @author u204544
 */
public final class KeyUtil {

    public static final String ALGORITHM = "RSA";

    static {
        java.security.Security.addProvider(
                new org.bouncycastle.jce.provider.BouncyCastleProvider()
        );
    }

    private KeyUtil() {
        // no-op - prevent instantiation of the class
    }

    /**
     * Creates a {@link PublicKey} when given a public RSA key file.
     *
     * @param keyFile key file generated from openssl
     * @return public key file in java
     * @throws IOException              when a file can not be found
     * @throws InvalidKeySpecException  when the key file is invalid
     * @throws NoSuchAlgorithmException when the algorithm specified is invalid
     */
    public static PublicKey getPublicKeyFromFile(File keyFile) throws IOException, InvalidKeySpecException, NoSuchAlgorithmException {

        String encodedKey = sanitizeKeyFile(FileUtils.readFileToString(keyFile, StandardCharsets.UTF_8));
        byte[] decodedKey = Base64.getDecoder().decode(encodedKey);

        X509EncodedKeySpec ks = new X509EncodedKeySpec(decodedKey);
        KeyFactory kf = KeyFactory.getInstance(ALGORITHM);
        return kf.generatePublic(ks);
    }

    /**
     * Creates a {@link PrivateKey} when given a private RSA key file (signing key).
     *
     * @param keyFile key file generated from openssl
     * @return private key file in java
     * @throws IOException              when a file can not be found
     * @throws InvalidKeySpecException  when the key file is invalid
     * @throws NoSuchAlgorithmException when the algorithm specified is invalid
     */
    public static PrivateKey getPrivateKeyFromFile(File keyFile) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {

        String encodedKey = sanitizeKeyFile(FileUtils.readFileToString(keyFile, StandardCharsets.UTF_8));
        byte[] decodedKey = Base64.getDecoder().decode(encodedKey);

        PKCS8EncodedKeySpec ks = new PKCS8EncodedKeySpec(decodedKey);
        KeyFactory kf = KeyFactory.getInstance(ALGORITHM);
        return kf.generatePrivate(ks);
    }

    /**
     * Remove header/footer from Key files and any whitespaces.
     *
     * @param input decoded key file string
     * @return sanitized key string
     */
    private static String sanitizeKeyFile(String input) {
        return input.replaceAll("-----.* KEY-----", "")
                .replaceAll("\\s", "");
    }
}
