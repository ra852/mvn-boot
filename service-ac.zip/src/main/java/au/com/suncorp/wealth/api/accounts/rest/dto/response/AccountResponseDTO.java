////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.rest.dto.response;

import java.io.Serializable;
import java.net.URI;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude;

import au.com.suncorp.wealth.api.accounts.cache.ProductDefCacheData;
import au.com.suncorp.wealth.api.accounts.enums.AccountParams;
import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.model.Account;
import au.com.suncorp.wealth.api.accounts.model.AccountRelationships;
import au.com.suncorp.wealth.api.accounts.model.ParameterBean;
import au.com.suncorp.wealth.api.accounts.model.Product;
import au.com.suncorp.wealth.api.accounts.model.account.details.GetAccountDetailsResponse;
import au.com.suncorp.wealth.api.accounts.provider.mapper.AccountMapper;
import au.com.suncorp.wealth.api.accounts.rest.DomainApiService;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response.ResponseCompoundData;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response.ResponseCompoundResource;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response.ResponseData;
import au.com.suncorp.wealth.api.common.rest.dto.response.AccountRelationshipsDTO;

/**
 * The class {@code AccountResponseDTO} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AccountResponseDTO extends ResponseCompoundResource<Account, AccountRelationshipsDTO, Product> implements Serializable {
    private static final String ACCOUNTS_RESOURCE = "accounts";
    private static final String PRODUCTS_RESOURCE = "products";
    private static final String PRODUCTS_DEF_RESOURCE = "productDefinition";
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountResponseDTO.class);

    /**
     * Parameterised constructor.
     *
     * @param baseUrl
     * @param accountEntry
     * @param getAccountDetailsResponse
     * @param pb
     */
    public AccountResponseDTO(URI baseUrl, Map.Entry<Account, AccountRelationships> accountEntry, GetAccountDetailsResponse getAccountDetailsResponse,
            RestTemplate restTemplate, DomainApiService domainApiService, String accountNumber, ParameterBean pb) {
        ResponseCompoundData<Account, AccountRelationshipsDTO> accountData =
                new ResponseCompoundData<>(ACCOUNTS_RESOURCE, accountEntry.getKey().getAccountNumber(), accountEntry.getKey());

        AccountRelationshipsDTO accountRelationshipsDTO =
                new AccountRelationshipsDTO(baseUrl, accountEntry.getKey().getAccountNumber(), ACCOUNTS_RESOURCE, accountEntry.getValue());
        if (accountRelationshipsDTO.hasInsurances() || accountRelationshipsDTO.hasProduct() || accountRelationshipsDTO.hasOwners()) {
            accountData.setRelationships(accountRelationshipsDTO);
        }
        setData(accountData);

        setIncluded(getAccountDetailsResponse, restTemplate, domainApiService, accountNumber, pb);
    }

    private void setIncluded(GetAccountDetailsResponse getAccountDetailsResponse, RestTemplate restTemplate, DomainApiService domainApiService,
            String accountNumber, ParameterBean pb) {
        if (pb.getIncludeParams() != null && !pb.getIncludeParams().isEmpty()) {
            Product p = new AccountMapper().mapProduct(getAccountDetailsResponse);
            setProducts(pb, p);
            setProductDefinition(restTemplate, domainApiService, accountNumber, pb, p);
        }
    }

    private void setProducts(ParameterBean pb, Product p) {
        if (pb.getIncludeParams().contains(AccountParams.products)) {
            ResponseData<Product> product = new ResponseData<Product>(PRODUCTS_RESOURCE, p.getId(), p);
            addIncluded(product);
        }
    }

    private void setProductDefinition(RestTemplate restTemplate, DomainApiService domainApiService, String accountNumber, ParameterBean pb,
            Product p) {
        if (pb.getIncludeParams().contains(AccountParams.productDefinition)) {
            String productId = p.getId();
            try {
                Product productDefData =
                        new ProductDefCacheData().getProductDefinitionDetails(restTemplate, domainApiService, productId, accountNumber, pb);
                ResponseData<Product> productDefResData = new ResponseData<Product>(PRODUCTS_DEF_RESOURCE, productDefData.getId(), productDefData);
                addIncluded(productDefResData);
            } catch (AccountServiceRuntimeException ae) {
                ae.printStackTrace();
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("Exception while calling Product Definition service");
                }
            }
        }
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
