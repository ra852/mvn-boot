////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code InvestmentProfileDetails} does this.
 * 
 * @author U383847
 * @since 28/01/2016
 * @version 1.0
 */
public class InvestmentProfileDetails {
    private String sameAsDefaultInvestmentProfile;
    private CodeIdentifier patternMethod;
    private CodeIdentifier overrideCode;
    private String totalAmount;
    private String clearAllFunds;
    private String deleteFlag;

    /**
     * Accessor for property sameAsDefaultInvestmentProfile.
     *
     * @return sameAsDefaultInvestmentProfile of type String
     */
    public String getSameAsDefaultInvestmentProfile() {
        return sameAsDefaultInvestmentProfile;
    }

    /**
     * Mutator for property sameAsDefaultInvestmentProfile.
     *
     * @param sameAsDefaultInvestmentProfile of type String
     */

    public void setSameAsDefaultInvestmentProfile(String sameAsDefaultInvestmentProfile) {
        this.sameAsDefaultInvestmentProfile = sameAsDefaultInvestmentProfile;
    }

    /**
     * Accessor for property patternMethod.
     *
     * @return patternMethod of type CodeIdentifier
     */
    public CodeIdentifier getPatternMethod() {
        return patternMethod;
    }

    /**
     * Mutator for property patternMethod.
     *
     * @param patternMethod of type CodeIdentifier
     */

    public void setPatternMethod(CodeIdentifier patternMethod) {
        this.patternMethod = patternMethod;
    }

    /**
     * Accessor for property overrideCode.
     *
     * @return overrideCode of type CodeIdentifier
     */
    public CodeIdentifier getOverrideCode() {
        return overrideCode;
    }

    /**
     * Mutator for property overrideCode.
     *
     * @param overrideCode of type CodeIdentifier
     */

    public void setOverrideCode(CodeIdentifier overrideCode) {
        this.overrideCode = overrideCode;
    }

    /**
     * Accessor for property totalAmount.
     *
     * @return totalAmount of type String
     */
    public String getTotalAmount() {
        return totalAmount;
    }

    /**
     * Mutator for property totalAmount.
     *
     * @param totalAmount of type String
     */

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    /**
     * Accessor for property clearAllFunds.
     *
     * @return clearAllFunds of type String
     */
    public String getClearAllFunds() {
        return clearAllFunds;
    }

    /**
     * Mutator for property clearAllFunds.
     *
     * @param clearAllFunds of type String
     */

    public void setClearAllFunds(String clearAllFunds) {
        this.clearAllFunds = clearAllFunds;
    }

    /**
     * Accessor for property deleteFlag.
     *
     * @return deleteFlag of type String
     */
    public String getDeleteFlag() {
        return deleteFlag;
    }

    /**
     * Mutator for property deleteFlag.
     *
     * @param deleteFlag of type String
     */

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

}
