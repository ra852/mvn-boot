////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

import java.util.HashMap;
import java.util.Map;

/**
 * The class {@code AccountStatusInfo} does this.
 *
 * @author u201468
 * @since 25Jan.,2018
 * @version 1.0
 */
public final class AccountStatusInfo {
    private static final Map<String, String> STATUS_MAP = new HashMap<String, String>();

    private AccountStatusInfo() {
    }

    /**
     * Accessor for property statusMap.
     *
     * @return statusmap of type Map<String,String>
     */
    public static Map<String, String> getStatusmap() {
        STATUS_MAP.put("ACTV", "Active");
        STATUS_MAP.put("SUSP", "Suspended");
        STATUS_MAP.put("ESTO", "Inactive");
        STATUS_MAP.put("CLOS", "Closed");
        STATUS_MAP.put("PEND", "Pending");
        return STATUS_MAP;
    }

}
