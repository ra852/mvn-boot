////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model;

import java.math.BigDecimal;

import org.beanio.annotation.Record;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code AccountBalance} does this.
 *
 * @author u201468
 * @since 25Jan.,2018
 * @version 1.0
 */
@Record(minOccurs = 1, name = "Amount")
@JsonInclude(Include.NON_EMPTY)
public class Amount {
    @ApiModelProperty(position = 1, example = "4231.12")
    private BigDecimal amount;
    @ApiModelProperty(position = 2, example = "AUD")
    private String currency;

    /**
     * Accessor for property amount.
     *
     * @return amount of type BigDecimal
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * Mutator for property amount.
     *
     * @param amount of type BigDecimal
     */
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    /**
     * Accessor for property currency.
     *
     * @return currency of type String
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Mutator for property currency.
     *
     * @param currency of type String
     */

    public void setCurrency(String currency) {
        this.currency = currency;
    }

}
