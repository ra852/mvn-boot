////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.resource;

import java.util.concurrent.CompletionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import au.com.suncorp.wealth.api.accounts.exception.MainAccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.utils.AccountUtil;
import au.com.suncorp.wealth.api.common.config.properties.ApiCommonProperties;
import au.com.suncorp.wealth.api.common.rest.dto.response.ErrorResponseDTO;

/**
 * The class {@code ResourceGlobalExceptionHandler} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@ControllerAdvice
@EnableConfigurationProperties(ApiCommonProperties.class)
public class ResourceGlobalExceptionHandler extends BaseResourceGlobalExceptionHandler {

    /**
     * Parameterised constructor.
     *
     * @param apiCommonProperties
     */
    @Autowired
    public ResourceGlobalExceptionHandler(ApiCommonProperties apiCommonProperties) {
        super(apiCommonProperties);
    }

    /**
     * Does this.
     *
     * @param e
     * @param request
     * @return
     */
    @Override
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleResourceGlobalException(Exception e, WebRequest request) {
        if (e instanceof MainAccountServiceRuntimeException) {
            MainAccountServiceRuntimeException mae = (MainAccountServiceRuntimeException) e;
            return handleExceptionInternal(e, null, new AccountUtil().createHttpHeaders(mae), exceptionToHttpStatus(mae), request);
        } else if (e instanceof CompletionException) {
            MainAccountServiceRuntimeException mae = (MainAccountServiceRuntimeException) e.getCause();
            return handleExceptionInternal(mae, null, new AccountUtil().createHttpHeaders(mae), exceptionToHttpStatus(mae), request);
        } else {
            return handleExceptionInternal(e, null, new HttpHeaders(), exceptionToHttpStatus(e), request);
        }
    }

    /**
     * Create error response DTO.
     *
     * @param e
     * @param httpStatus
     * @return
     */
    @Override
    protected ErrorResponseDTO createErrorResponseDTO(Exception e, HttpStatus httpStatus) {
        if (e instanceof MainAccountServiceRuntimeException) {
            ErrorResponseDTO dto = new ErrorResponseDTO();
            MainAccountServiceRuntimeException mae = (MainAccountServiceRuntimeException) e;
            dto.addError(mae.getId(), mae.getHttpStatus().value(), null, e.getMessage(), mae.getDetail());
            logExceptionBasedOnHttpStatus(mae, httpStatus, mae.getMessage());
            return dto;
        } else {
            return super.createErrorResponseDTO(e, httpStatus);
        }
    }
}
