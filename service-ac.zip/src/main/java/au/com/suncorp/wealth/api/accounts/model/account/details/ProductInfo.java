////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

import java.util.HashMap;
import java.util.Map;

import au.com.suncorp.wealth.api.accounts.model.Product;

/**
 * The class {@code ProductInfo} does this.
 *
 * @author u201468
 * @since 22Jan.,2018
 * @version 1.0
 */
public final class ProductInfo {
    private static final Map<String, Product> PRODUCT_MAP = new HashMap<String, Product>();

    private ProductInfo() {
    }

    /**
     * Accessor for property productMap.
     *
     * @return productmap of type Map<String,Object>
     */
    public static Map<String, Product> getProductmap() {
        PRODUCT_MAP.put("40000022", new Product("40000022", "Suncorp Everyday Super pension", "EDS Pension", "Suncorp", "Everyday Super", "SCPN",
                "98350952022", "98350952022321", "super@suncorp.com.au"));
        PRODUCT_MAP.put("40000030", new Product("40000030", "Suncorp Brighter Super Term Allocated Pension", "BrighterTAP", "Suncorp",
                "Brighter Super", "SCTP", "98350952022", "98350952022321", "super@suncorp.com.au"));
        PRODUCT_MAP.put("40000026", new Product("40000026", "Suncorp Brighter Super", "Brighter Super", "Suncorp", "Brighter Super", "SCSP",
                "98350952022", "98350952022123", "super@suncorp.com.au"));
        PRODUCT_MAP.put("41000022", new Product("41000022", "Suncorp Allocated Annuity", "Allocated Annuity", "Suncorp", "N/A", "SCPN", "98350952022",
                "87073979530", "super@suncorp.com.au"));
        PRODUCT_MAP.put("40000023", new Product("40000023", "Suncorp Everyday Super", "EDS Super", "Suncorp", "Everyday Super", "SCSP", "98350952022",
                "98350952022123", "super@suncorp.com.au"));
        PRODUCT_MAP.put("40000021", new Product("40000021", "Suncorp Brighter Super pension", "BrighterPension", "Suncorp", "Brighter Super", "SCPN",
                "98350952022", "98350952022321", "super@suncorp.com.au"));
        PRODUCT_MAP.put("41000021", new Product("41000021", "Suncorp Classic Pension", "Classic Pension", "Suncorp", "N/A", "SCTP", "N/A",
                "98350952022321", "super@suncorp.com.au"));
        PRODUCT_MAP.put("40000028", new Product("40000028", "Suncorp Employee Superannuation Plan", "SESP", "Suncorp", "SESP", "SCSP", "98350952022",
                "98350952022123", "Staff.super@suncorp.com.au"));
        PRODUCT_MAP.put("40000001", new Product("40000001", "Suncorp Brighter Super for business", "BrighterSupBus", "Suncorp", "Brighter Super",
                "SCSP", "98350952022", "98350952022123", "super@suncorp.com.au"));
        PRODUCT_MAP.put("41000001", new Product("41000001", "Suncorp Pooled Superannuation Trust", "Suncorp PST", "Suncorp", "N/A", "SCPS", "N/A",
                "N/A", "super@suncorp.com.au"));
        return PRODUCT_MAP;
    }

}
