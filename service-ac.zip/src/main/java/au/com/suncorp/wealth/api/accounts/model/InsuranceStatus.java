////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model;

import org.beanio.annotation.Record;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code InsuranceStatus} does this.
 *
 * @author u201468
 * @since 31Jan.,2018
 * @version 1.0
 */
@Record(minOccurs = 1, name = "InsuranceStatus")
@JsonInclude(Include.NON_EMPTY)
public class InsuranceStatus {
    @ApiModelProperty(position = 1, example = "IF")
    private String code;
    @ApiModelProperty(position = 2, example = "In Force")
    private String value;

    /**
     * Accessor for property code.
     *
     * @return code of type String
     */
    public String getCode() {
        return code;
    }

    /**
     * Mutator for property code.
     *
     * @param code of type String
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Accessor for property value.
     *
     * @return value of type String
     */
    public String getValue() {
        return value;
    }

    /**
     * Mutator for property value.
     *
     * @param value of type String
     */
    public void setValue(String value) {
        this.value = value;
    }

}
