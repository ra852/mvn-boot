////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.provider;

/**
 * The class {@code ProviderEnvironmentContext} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public enum ProviderEnvironmentContext {
    CLAIM_CENTER("X-CC-Env", "ccEnv"),
    CUSTOMER("X-Customer-Env", "customerEnv"),
    GROUP_PROTECT("X-GP-Env", "gpEnv"),
    ORACLE_ACCESS_MANAGER("X-OAM-Env", "oamEnv");

    private final String headerKey;
    private final String contextKey;

    /**
     * Parameterised constructor.
     *
     * @param headerKey
     * @param contextKey
     */
    ProviderEnvironmentContext(String headerKey, String contextKey) {
        this.headerKey = headerKey;
        this.contextKey = contextKey;
    }

    public String getHeaderKey() {
        return headerKey;
    }

    public String getContextKey() {
        return contextKey;
    }
}
