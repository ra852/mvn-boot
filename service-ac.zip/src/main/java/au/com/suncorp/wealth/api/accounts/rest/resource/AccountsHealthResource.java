////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.rest.resource;

import static au.com.suncorp.wealth.api.common.constant.CommonConstants.ACCEPT_APPLICATION_JSON_API_VALUE;
import static au.com.suncorp.wealth.api.common.constant.CommonConstants.APPLICATION_JSON_API_VALUE;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

import au.com.suncorp.wealth.api.accounts.exception.AccountServiceRuntimeException;
import au.com.suncorp.wealth.api.accounts.provider.AccountService;
import au.com.suncorp.wealth.api.accounts.rest.UriHelperService;

/**
 * The class {@code AccountsHealthResource} does this.
 *
 * @author u201468
 * @since 22May,2018
 * @version 1.0
 */
@RestController
@RequestMapping("/wealth/v1")
public class AccountsHealthResource {
    private final AccountService accountService;
    private final UriHelperService uriHelperService;

    @Autowired
    public AccountsHealthResource(AccountService accountService, UriHelperService uriHelperService) {
        this.accountService = accountService;
        this.uriHelperService = uriHelperService;
    }

    @RequestMapping(value = "accounts/health", method = RequestMethod.GET, headers = ACCEPT_APPLICATION_JSON_API_VALUE, produces = APPLICATION_JSON_API_VALUE)
    public ResponseEntity<JsonNode> apiHealth() {
        try {
            return accountService.health(uriHelperService.getUriForWealthAPI());
        } catch (AccountServiceRuntimeException ex) {
            throw ex;
        }
    }
}
