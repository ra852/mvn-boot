////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.enums;

/**
 * The class {@code ProductDefinition} does this.
 *
 * @author u201468
 * @since 30Mar.,2018
 * @version 1.0
 */
public enum ProductDefinition {
    productDefinition;
}
