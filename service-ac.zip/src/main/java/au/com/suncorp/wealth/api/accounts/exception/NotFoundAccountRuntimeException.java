////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.suncorp.wealth.api.accounts.model.ParameterBean;

/**
 * The class {@code NotFoundAccountRuntimeException} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class NotFoundAccountRuntimeException extends MainAccountServiceRuntimeException {
    private static final long serialVersionUID = 1L;

    /**
     * Parameterised constructor for NotFoundAccountRuntimeException.
     *
     * @param id
     * @param title
     * @param detail
     */
    public NotFoundAccountRuntimeException(String id, String title, String detail) {
        super(id, title, detail);
    }

    /**
     * Parameterised constructor for NotFoundAccountRuntimeException.
     *
     * @param id
     * @param title
     * @param detail
     * @param pb
     */
    public NotFoundAccountRuntimeException(String id, String title, String detail, ParameterBean pb) {
        super(id, title, detail, pb);
    }

    /**
     * Http error code.
     */
    @Override
    public HttpStatus getHttpStatus() {
        return HttpStatus.NOT_FOUND;
    }
}
