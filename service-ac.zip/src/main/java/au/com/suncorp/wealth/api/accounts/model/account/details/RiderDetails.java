////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.model.account.details;

/**
 * The class {@code RiderDetails} is a java bean consisting of properties related to RiderDetails.
 * 
 * @author u385424
 * @since 05/05/2016
 * @version 1.0
 */
public class RiderDetails {
    private String id;
    private RiderTemplate riderTemplate;
    private RiderTemplateDetails riderTemplateDetails;
    private String dateOfBirth;
    private CodeIdentifier status;
    private CodeIdentifier sex;
    private String sumInsured;
    private CodeIdentifier coverReason;
    private String futureInsure;
    private CodeIdentifier smokeStatus;
    private CodeIdentifier occupationCategory;
    private String riskCommenceDate;
    private String nextReviewDate;
    private String riskCeaseDate;
    private String isAgeAdjusted;
    private String benefitPeriod;
    private String waitPeriod;
    private String riskTerm;
    private String premiumTerm;
    private String riskTermAge;
    private String premiumTermAge;
    private String totalLoadings;
    private String annualPremium;
    private String instalmentPremium;
    private String annualPremiumExLoadings;
    private String lastRenewalDate;
    private String salaryFactor;
    private String unitsOfSI;
    private String employmentSalary;
    private String insuranceSalary;
    private CodeIdentifier riskRule;
    private String revPercentageRate;
    private String reviewAmount;
    private String riderRatio;
    private String modalPremium;
    private String isQuote;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public RiderTemplate getRiderTemplate() {
        return riderTemplate;
    }

    public void setRiderTemplate(RiderTemplate riderTemplate) {
        this.riderTemplate = riderTemplate;
    }

    public RiderTemplateDetails getRiderTemplateDetails() {
        return riderTemplateDetails;
    }

    public void setRiderTemplateDetails(RiderTemplateDetails riderTemplateDetails) {
        this.riderTemplateDetails = riderTemplateDetails;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public CodeIdentifier getStatus() {
        return status;
    }

    public void setStatus(CodeIdentifier status) {
        this.status = status;
    }

    public CodeIdentifier getSex() {
        return sex;
    }

    public void setSex(CodeIdentifier sex) {
        this.sex = sex;
    }

    public String getSumInsured() {
        return sumInsured;
    }

    public void setSumInsured(String sumInsured) {
        this.sumInsured = sumInsured;
    }

    public CodeIdentifier getCoverReason() {
        return coverReason;
    }

    public void setCoverReason(CodeIdentifier coverReason) {
        this.coverReason = coverReason;
    }

    public String getFutureInsure() {
        return futureInsure;
    }

    public void setFutureInsure(String futureInsure) {
        this.futureInsure = futureInsure;
    }

    public CodeIdentifier getSmokeStatus() {
        return smokeStatus;
    }

    public void setSmokeStatus(CodeIdentifier smokeStatus) {
        this.smokeStatus = smokeStatus;
    }

    public CodeIdentifier getOccupationCategory() {
        return occupationCategory;
    }

    public void setOccupationCategory(CodeIdentifier occupationCategory) {
        this.occupationCategory = occupationCategory;
    }

    public String getRiskCommenceDate() {
        return riskCommenceDate;
    }

    public void setRiskCommenceDate(String riskCommenceDate) {
        this.riskCommenceDate = riskCommenceDate;
    }

    public String getNextReviewDate() {
        return nextReviewDate;
    }

    public void setNextReviewDate(String nextReviewDate) {
        this.nextReviewDate = nextReviewDate;
    }

    public String getRiskCeaseDate() {
        return riskCeaseDate;
    }

    public void setRiskCeaseDate(String riskCeaseDate) {
        this.riskCeaseDate = riskCeaseDate;
    }

    public String getIsAgeAdjusted() {
        return isAgeAdjusted;
    }

    public void setIsAgeAdjusted(String isAgeAdjusted) {
        this.isAgeAdjusted = isAgeAdjusted;
    }

    public String getBenefitPeriod() {
        return benefitPeriod;
    }

    public void setBenefitPeriod(String benefitPeriod) {
        this.benefitPeriod = benefitPeriod;
    }

    public String getWaitPeriod() {
        return waitPeriod;
    }

    public void setWaitPeriod(String waitPeriod) {
        this.waitPeriod = waitPeriod;
    }

    public String getRiskTerm() {
        return riskTerm;
    }

    public void setRiskTerm(String riskTerm) {
        this.riskTerm = riskTerm;
    }

    public String getPremiumTerm() {
        return premiumTerm;
    }

    public void setPremiumTerm(String premiumTerm) {
        this.premiumTerm = premiumTerm;
    }

    public String getRiskTermAge() {
        return riskTermAge;
    }

    public void setRiskTermAge(String riskTermAge) {
        this.riskTermAge = riskTermAge;
    }

    public String getPremiumTermAge() {
        return premiumTermAge;
    }

    public void setPremiumTermAge(String premiumTermAge) {
        this.premiumTermAge = premiumTermAge;
    }

    public String getTotalLoadings() {
        return totalLoadings;
    }

    public void setTotalLoadings(String totalLoadings) {
        this.totalLoadings = totalLoadings;
    }

    public String getAnnualPremium() {
        return annualPremium;
    }

    public void setAnnualPremium(String annualPremium) {
        this.annualPremium = annualPremium;
    }

    public String getInstalmentPremium() {
        return instalmentPremium;
    }

    public void setInstalmentPremium(String instalmentPremium) {
        this.instalmentPremium = instalmentPremium;
    }

    public String getAnnualPremiumExLoadings() {
        return annualPremiumExLoadings;
    }

    public void setAnnualPremiumExLoadings(String annualPremiumExLoadings) {
        this.annualPremiumExLoadings = annualPremiumExLoadings;
    }

    public String getLastRenewalDate() {
        return lastRenewalDate;
    }

    public void setLastRenewalDate(String lastRenewalDate) {
        this.lastRenewalDate = lastRenewalDate;
    }

    public String getSalaryFactor() {
        return salaryFactor;
    }

    public void setSalaryFactor(String salaryFactor) {
        this.salaryFactor = salaryFactor;
    }

    public String getUnitsOfSI() {
        return unitsOfSI;
    }

    public void setUnitsOfSI(String unitsOfSI) {
        this.unitsOfSI = unitsOfSI;
    }

    public String getEmploymentSalary() {
        return employmentSalary;
    }

    public void setEmploymentSalary(String employmentSalary) {
        this.employmentSalary = employmentSalary;
    }

    public String getInsuranceSalary() {
        return insuranceSalary;
    }

    public void setInsuranceSalary(String insuranceSalary) {
        this.insuranceSalary = insuranceSalary;
    }

    public CodeIdentifier getRiskRule() {
        return riskRule;
    }

    public void setRiskRule(CodeIdentifier riskRule) {
        this.riskRule = riskRule;
    }

    public String getRevPercentageRate() {
        return revPercentageRate;
    }

    public void setRevPercentageRate(String revPercentageRate) {
        this.revPercentageRate = revPercentageRate;
    }

    public String getReviewAmount() {
        return reviewAmount;
    }

    public void setReviewAmount(String reviewAmount) {
        this.reviewAmount = reviewAmount;
    }

    public String getRiderRatio() {
        return riderRatio;
    }

    public void setRiderRatio(String riderRatio) {
        this.riderRatio = riderRatio;
    }

    public String getModalPremium() {
        return modalPremium;
    }

    public void setModalPremium(String modalPremium) {
        this.modalPremium = modalPremium;
    }

    public String getIsQuote() {
        return isQuote;
    }

    public void setIsQuote(String isQuote) {
        this.isQuote = isQuote;
    }

}
