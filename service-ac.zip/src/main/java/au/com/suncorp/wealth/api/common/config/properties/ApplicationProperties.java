////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * The class {@code ApplicationProperties} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@ConfigurationProperties(prefix = "application")
public class ApplicationProperties {
    private String id;
    private String version;

    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     *
     * @param id of type String
     */

    public void setId(String id) {
        this.id = id;
    }

    /**
     * Accessor for property version.
     *
     * @return version of type String
     */
    public String getVersion() {
        return version;
    }

    /**
     * Mutator for property version.
     *
     * @param version of type String
     */

    public void setVersion(String version) {
        this.version = version;
    }

}
