////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import au.com.suncorp.wealth.api.accounts.config.properties.AccountServiceProperties;
import au.com.suncorp.wealth.api.accounts.provider.AccountService;
import au.com.suncorp.wealth.api.accounts.stub.AccountServiceStub;

/**
 * The class {@code AccountServiceConfiguration} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@Configuration
@EnableConfigurationProperties(AccountServiceProperties.class)
@RefreshScope
public class AccountServiceConfiguration {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AccountServiceProperties accountServiceProperties;

    @Autowired
    private RestTemplate restTemplate;

    /**
     * Used to call account service class.
     */
    @Bean
    @Profile("!accountServiceStub")
    public AccountService AccountService() {
        logger.debug("App will call Product Config");
        restTemplate.setRequestFactory(clientHttpRequestFactory());
        return new AccountService(restTemplate, accountServiceProperties);
    }
    
    private ClientHttpRequestFactory clientHttpRequestFactory() {
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
        factory.setReadTimeout(accountServiceProperties.getTimeout());
        factory.setConnectTimeout(accountServiceProperties.getTimeout());
        return factory;
    }

    /**
     * Does this.
     */
    @Bean
    @Profile("accountServiceStub")
    public AccountService accountServiceStub() {
        logger.debug("App will mock Product Config calls by returning static json result");
        return new AccountService(new AccountServiceStub(), accountServiceProperties);
    }
}
