////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api;

import java.io.IOException;
import java.util.Arrays;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.core.env.Environment;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;

import au.com.suncorp.api.identity.spring.EnableSuncorpIdentity;

/**
 * The class {@code Application} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@SpringBootApplication
@EnableRetry
@EnableCircuitBreaker
@EnableSuncorpIdentity
@EnableAsync
public class Application extends SpringBootServletInitializer {
    private static final Logger LOGGER = LoggerFactory.getLogger(Application.class);

    @Autowired
    private Environment env;

    /**
     * Main method, used to run the application (Only for gradle bootRun).
     */
    public static void main(String[] args) {
        buildApp(new SpringApplicationBuilder()).run(args);
    }

    /**
     * To run in a servlet context.
     *
     * @param application
     * @return
     */
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return buildApp(application);
    }

    private static SpringApplicationBuilder buildApp(SpringApplicationBuilder builder) {
        return builder.bannerMode(Banner.Mode.CONSOLE).sources(Application.class);
    }

    /**
     * Initializes application.
     * <p>
     * Spring profiles can be configured with a program arguments --spring.profiles.active=active-profile
     * <p>
     */
    @PostConstruct
    public void initApplication() throws IOException {
        if (env.getActiveProfiles().length == 0) {
            LOGGER.warn("No Spring profile configured, running with default configuration");
        } else {
            LOGGER.info("Running with Spring profile(s) : {}", Arrays.toString(env.getActiveProfiles()));
        }
    }
}
