////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.links.Links;
import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code ResponseCompoundResource} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 * @param <T>
 * @param <V>
 * @param <Z>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "data", "included" })
public abstract class ResponseCompoundResource<T extends Object, V extends Object, Z extends Object> extends ResponseBase {
    @ApiModelProperty(value = "Data", required = false)
    private ResponseCompoundData<T, V> data;

    @ApiModelProperty(value = "Included resources", required = false)
    private List<ResponseData<Z>> included;

    @ApiModelProperty(value = "Data links", required = false)
    private Links links;

    public ResponseCompoundData<T, V> getData() {
        return data;
    }

    public void setData(ResponseCompoundData<T, V> data) {
        this.data = data;
    }

    public List<ResponseData<Z>> getIncluded() {
        return included;
    }

    public void addIncluded(ResponseData<Z> data) {
        if (this.included == null) {
            this.included = new ArrayList<>();
        }

        included.add(data);
    }

    public void setIncluded(List<ResponseData<Z>> included) {
        this.included = included;
    }

    public Links getLinks() {
        return links;
    }

    public void setLinks(Links links) {
        this.links = links;
    }
}
