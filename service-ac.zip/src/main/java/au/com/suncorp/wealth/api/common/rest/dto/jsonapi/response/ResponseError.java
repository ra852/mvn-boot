////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.MoreObjects;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code ResponseError} does this.
 *
 * @author u201468
 * @since 12Feb.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "status", "code", "title", "details" })
public class ResponseError implements Serializable {
    @ApiModelProperty(value = "Error ID", required = false)
    private final String id;

    @ApiModelProperty(value = "Error HTTP status code", required = false)
    private final String status;

    @ApiModelProperty(value = "Error code", required = false)
    private final String code;

    @ApiModelProperty(value = "Error short description", required = false)
    private final String title;

    @ApiModelProperty(value = "Error details", required = false)
    private final String details;

    /**
     * Parameterised constructor.
     *
     * @param title
     */
    public ResponseError(String title) {
        this(null, null, null, title, null);
    }

    /**
     * Parameterised constructor.
     *
     * @param statusCode
     * @param title
     */
    public ResponseError(Integer statusCode, String title) {
        this(null, statusCode, null, title, null);
    }

    /**
     * Parameterised constructor.
     *
     * @param title
     * @param details
     */
    public ResponseError(String title, String details) {
        this(null, null, null, title, details);
    }

    /**
     * Parameterised constructor.
     *
     * @param statusCode
     * @param title
     * @param details
     */
    public ResponseError(Integer statusCode, String title, String details) {
        this(null, statusCode, null, title, details);
    }

    /**
     * Parameterised constructor.
     *
     * @param id
     * @param statusCode
     * @param code
     * @param title
     * @param details
     */
    public ResponseError(String id, Integer statusCode, String code, String title, String details) {
        this.id = id;
        this.status = (statusCode != null ? statusCode.toString() : null);
        this.code = code;
        this.title = title;
        this.details = details;
    }

    public String getId() {
        return id;
    }

    public String getStatus() {
        return status;
    }

    public String getCode() {
        return code;
    }

    public String getTitle() {
        return title;
    }

    public String getDetails() {
        return details;
    }

    protected MoreObjects.ToStringHelper toStringHelper() {
        return MoreObjects.toStringHelper(this)
                .add("id", id)
                .add("status", status)
                .add("code", code)
                .add("title", title)
                .add("details", details);
    }

    @Override
    public String toString() {
        return toStringHelper().toString();
    }
}
