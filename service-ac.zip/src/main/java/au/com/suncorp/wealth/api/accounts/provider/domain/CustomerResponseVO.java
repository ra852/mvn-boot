////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.provider.domain;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * The class {@code CustomerResponseVO} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@SuppressWarnings("serial")
public class CustomerResponseVO implements Serializable {
    private String id;
    private String firstName;
    private String surname;

    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     *
     * @param id of type String
     */

    public void setId(String id) {
        this.id = id;
    }

    /**
     * Accessor for property firstName.
     *
     * @return firstName of type String
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator for property firstName.
     *
     * @param firstName of type String
     */

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Accessor for property surname.
     *
     * @return surname of type String
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Mutator for property surname.
     *
     * @param surname of type String
     */

    public void setSurname(String surname) {
        this.surname = surname;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
