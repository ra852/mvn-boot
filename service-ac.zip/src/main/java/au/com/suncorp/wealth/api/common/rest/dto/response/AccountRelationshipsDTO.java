////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.response;

import java.io.Serializable;
import java.net.URI;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonInclude;

import au.com.suncorp.wealth.api.accounts.model.AccountRelationships;
import au.com.suncorp.wealth.api.accounts.rest.UriHelperService;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.links.DefaultRelatedLinks;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response.ResponseRelationships;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response.ResponseRelationship;
import au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response.ResponseRelationshipData;

/**
 * The class {@code AccountRelationshipsDTO} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AccountRelationshipsDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final String INSURANCES_RESOURCE = "insurances";
    private static final String PRODUCTS_RESOURCE = "products";
    private static final String OWNERS_RESOURCE = "clients";
    private ResponseRelationships insurances;
    private ResponseRelationship products;
    private ResponseRelationship owners;

    /**
     * Parameterised constructor.
     *
     * @param baseUrl
     * @param accountNumber
     * @param accountResourceType
     * @param accountRelationships
     */
    public AccountRelationshipsDTO(URI baseUrl, String accountNumber, String accountResourceType, AccountRelationships accountRelationships) {

        addInsurancesData(baseUrl, accountNumber, accountResourceType, accountRelationships);

        addProductsData(baseUrl, accountNumber, accountResourceType, accountRelationships);
        
        addOwnersData(accountRelationships);
    }

    /**
     * Does this.
     *
     * @param baseUrl
     * @param accountNumber
     * @param accountResourceType
     * @param accountRelationships
     */
    private void addOwnersData(AccountRelationships accountRelationships) {
        if (accountRelationships.getOwners() != null) {
            owners = new ResponseRelationship();
            String clientId = accountRelationships.getOwners();
            owners.setData(new ResponseRelationshipData(OWNERS_RESOURCE, clientId));
        }
        
        Optional.ofNullable(accountRelationships)
                .ifPresent(o -> Optional.ofNullable(o.getOwners())
                        .filter(strings -> !strings.isEmpty())
                        .ifPresent(accountsOwners -> {
                            owners = new ResponseRelationship();
                            owners.setData(new ResponseRelationshipData(OWNERS_RESOURCE, o.getOwners()));
                        }));
    }

    /**
     * Adds insurance data.
     *
     * @param baseUrl
     * @param accountNumber
     * @param accountResourceType
     * @param accountRelationships
     */
    private void addInsurancesData(URI baseUrl, String accountNumber, String accountResourceType, AccountRelationships accountRelationships) {
        if (accountRelationships != null && accountRelationships.getInsurances() != null && accountRelationships.getInsurances().size() > 0) {
            insurances = new ResponseRelationships();
            for (String insuranceId : accountRelationships.getInsurances()) {
                insurances.addData(new ResponseRelationshipData(INSURANCES_RESOURCE, insuranceId));
            }
        }

        DefaultRelatedLinks relatedLinks = new DefaultRelatedLinks(
                UriHelperService.buildResourceLinkWithRelationships(baseUrl, accountResourceType, accountNumber, INSURANCES_RESOURCE).toString());

        Optional.ofNullable(accountRelationships)
                .ifPresent(p -> Optional.ofNullable(p.getInsurances())
                        .filter(strings -> !strings.isEmpty())
                        .ifPresent(accountsInsurances -> {
                    insurances = new ResponseRelationships();
                    insurances.setLinks(relatedLinks);
                    accountsInsurances.stream()
                    .filter(s -> !s.trim().isEmpty())
                            .map(insuranceId -> new ResponseRelationshipData(INSURANCES_RESOURCE, insuranceId))
                            .forEach(insurances::addData);
                }));
    }

    /**
     * Adds product data.
     *
     * @param baseUrl
     * @param accountNumber
     * @param accountResourceType
     * @param accountRelationships
     */
    private void addProductsData(URI baseUrl, String accountNumber, String accountResourceType, AccountRelationships accountRelationships) {
        if (accountRelationships.getProducts() != null) {
            products = new ResponseRelationship();
            String productId = accountRelationships.getProducts();
                products.setData(new ResponseRelationshipData(PRODUCTS_RESOURCE, productId));
        }

        DefaultRelatedLinks relatedLinks = new DefaultRelatedLinks(
                UriHelperService.buildResourceLinkWithRelationships(baseUrl, accountResourceType, accountNumber, PRODUCTS_RESOURCE).toString());

        Optional.ofNullable(accountRelationships)
                .ifPresent(p -> Optional.ofNullable(p.getProducts())
                        .filter(strings -> !strings.isEmpty())
                        .ifPresent(accountsProducts -> {
                    products = new ResponseRelationship();
                    products.setLinks(relatedLinks);
                    products.setData(new ResponseRelationshipData(PRODUCTS_RESOURCE, p.getProducts()));
                }));
    }

    public ResponseRelationships getInsurances() {
        return insurances;
    }

    public ResponseRelationship getProducts() {
        return products;
    }

    public ResponseRelationship getOwners() {
        return owners;
    }
    
    public boolean hasInsurances() {
        return getInsurances() != null && !getInsurances().getData().isEmpty();
    }
    
    public boolean hasProduct() {
        return getProducts() != null && !getProducts().getData().getId().isEmpty();
    }
    
    public boolean hasOwners() {
        return getOwners() != null && !getOwners().getData().getId().isEmpty();
    }
}
