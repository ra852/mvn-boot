////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.healthcheck.provider;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The class {@code MultiEnvironmentServiceProviderConfiguration} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public class MultiEnvironmentServiceProviderConfiguration extends BaseServiceProviderConfiguration {
    private static final int FIRST_ONE = 0;
    private String activeEnvironment;
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(MultiEnvironmentServiceProviderConfiguration.class);

    private List<ServiceProviderEnvironment> serviceProviderEnvironments = Collections.emptyList();

    /**
     * Parameterised constructor.
     *
     * @param serviceProviderEnvironments
     * @param activeEnvironmentOptional
     */
    public MultiEnvironmentServiceProviderConfiguration(List<ServiceProviderEnvironment> serviceProviderEnvironments,
            Optional<String> activeEnvironmentOptional) {
        this(false, "", serviceProviderEnvironments, activeEnvironmentOptional);
    }

    /**
     * Parameterised constructor.
     *
     * @param serviceProviderEnvironments
     */
    public MultiEnvironmentServiceProviderConfiguration(List<ServiceProviderEnvironment> serviceProviderEnvironments) {
        this(serviceProviderEnvironments, Optional.empty());
    }

    /**
     * Parameterised constructor.
     *
     * @param downtimeEnabled
     * @param downtimePeriod
     * @param serviceProviderEnvironments
     * @param activeEnvironmentOptional
     */
    public MultiEnvironmentServiceProviderConfiguration(boolean downtimeEnabled, String downtimePeriod,
            List<ServiceProviderEnvironment> serviceProviderEnvironments, Optional<String> activeEnvironmentOptional) {
        super(downtimeEnabled, downtimePeriod);
        if (serviceProviderEnvironments.size() < 1) {
            throw new RuntimeException("Should has at least one environment");
        }
        this.serviceProviderEnvironments = serviceProviderEnvironments;
        if (activeEnvironmentOptional.isPresent()) {
            String activeEnvironment = activeEnvironmentOptional.get();
            Optional<ServiceProviderEnvironment> matchedEnvironment =
                    serviceProviderEnvironments.stream().filter(environment -> environment.getEnvironmentId().equals(activeEnvironment)).findFirst();
            APP_LOGGER.info(matchedEnvironment.toString());
            if (matchedEnvironment.isPresent()) {
                this.activeEnvironment = activeEnvironment;
            } else {
                throw new RuntimeException("Unknown environment: " + activeEnvironmentOptional);
            }
        } else {
            this.activeEnvironment = serviceProviderEnvironments.get(FIRST_ONE).getEnvironmentId();
        }
    }

    public List<ServiceProviderEnvironment> getServiceProviderEnvironments() {
        return Collections.unmodifiableList(serviceProviderEnvironments);
    }

    public String getHealthEndpoint(String environmentId) {
        return serviceProviderEnvironments.stream().filter(environment -> environmentId.equals(environment.getEnvironmentId())).findFirst().get()
                .getHealthEndpoint();
    }

    public List<String> getEnvironmentIdList() {
        return getServiceProviderEnvironments().stream().map(environment -> environment.getEnvironmentId()).collect(Collectors.toList());
    }

    public String getActiveEnvironment() {
        return activeEnvironment;
    }
}
