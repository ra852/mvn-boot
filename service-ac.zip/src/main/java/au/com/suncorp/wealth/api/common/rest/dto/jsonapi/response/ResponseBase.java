////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.rest.dto.jsonapi.response;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import io.swagger.annotations.ApiModelProperty;

/**
 * The class {@code ResponseBase} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public abstract class ResponseBase {
    @ApiModelProperty(value = "Errors", required = false)
    private List<ResponseError> errors;

    /**
     * Build error response.
     *
     * @param title
     */
    public void addError(String title) {
        initErrors();
        errors.add(new ResponseError(title));
    }

    /**
     * Build error response.
     *
     * @param statusCode
     * @param title
     */
    public void addError(int statusCode, String title) {
        initErrors();
        errors.add(new ResponseError(statusCode, title));
    }   

    /**
     * Build error response.
     *
     * @param title
     * @param details
     */
    public void addError(String title, String details) {
        initErrors();
        errors.add(new ResponseError(title, details));
    }

    /**
     * Build error response.
     *
     * @param statusCode
     * @param title
     * @param details
     */
    public void addError(int statusCode, String title, String details) {
        initErrors();
        errors.add(new ResponseError(statusCode, title, details));
    }

    /**
     * Build error response.
     *
     * @param id
     * @param statusCode
     * @param code
     * @param title
     * @param details
     */
    public void addError(String id, Integer statusCode, String code, String title, String details) {
        initErrors();
        errors.add(new ResponseError(id, statusCode, code, title, details));
    }

    public List<ResponseError> getErrors() {
        return errors;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }

    private void initErrors() {
        if (errors == null) {
            errors = new ArrayList<>();
        }
    }
}
