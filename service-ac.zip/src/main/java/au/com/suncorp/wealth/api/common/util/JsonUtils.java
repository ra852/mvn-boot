////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2016, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.common.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.IntFunction;

import org.apache.commons.io.IOUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

/**
 * The class {@code JsonUtils} does this.
 *
 * @author u201468
 * @since 9Feb.,2018
 * @version 1.0
 */
public final class JsonUtils {

    /**
     * Default constructor.
     */
    private JsonUtils() {
    }
    
    /**
     * Does this.
     *
     * @param filename
     * @return
     * @throws IOException
     */
    public static String getJsonStringFromFile(String filename) throws IOException {
        ClassLoader classLoader = JsonUtils.class.getClassLoader();
        String jsonStringFromFile = null;
        if (classLoader != null) {
            InputStream resourceStream = classLoader.getResourceAsStream(filename);
            try {
                jsonStringFromFile = IOUtils.toString(resourceStream, "UTF-8");
            } catch (IOException ioe) {
                throw ioe;
            } finally {
                if (resourceStream != null) {
                    resourceStream.close();
                }
            }
        }
        return jsonStringFromFile;
    }


    /**
     * Does this.
     *
     * @param filename
     * @return
     * @throws IOException
     */
    public static JsonNode getJsonNodeFromFile(String filename) throws IOException {
        String contents = getJsonStringFromFile(filename);
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readTree(contents);
    }


    /**
     * Does this.
     *
     * @param json
     * @return
     * @throws IOException
     */
    public static JsonNode getJsonNodeFromString(String json) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readTree(json);
    }
    
    /**
     * Does this.
     *
     * @param node
     * @return
     */
    public static String nodeToString(JsonNode node) {
        return nodeToString(node, "");
    }

    /**
     * Does this.
     *
     * @param node
     * @param spacer
     * @return
     */
    public static String nodeToString(JsonNode node, String spacer) {
        return nodeToString(node, spacer, "");
    }

    /**
     * Does this.
     *
     * @param node
     * @param spacer
     * @param built
     * @return
     */
    public static String nodeToString(JsonNode node, String spacer, String built) {
        String builtString = built;
        if (node.isArray()) {
            return nodeToString((ArrayNode) node, spacer, built);
        }
        Iterator<Entry<String, JsonNode>> fields = node.fields();
        while (fields.hasNext()) {
            Entry<String, JsonNode> field = fields.next();
            JsonNode value = field.getValue();
            if (value.isObject()) {
                builtString = nodeToString(value, spacer, built);
            } else {
                builtString = builtString.concat("," + spacer + "\"" + field.getKey() + "\": \"" + value.asText() + "\"");
            }
        }
        return builtString;
    }
    
    /**
     * Does this.
     *
     * @param object
     * @return
     * @throws JsonProcessingException
     */
    public static String convertObjectToString(Object object) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(object);
    }

    /**
     * Does this.
     *
     * @param node
     * @param spacer
     * @param built
     * @return
     */
    public static String nodeToString(ArrayNode node, String spacer, String built) {
        String builtString = built;
        for (int i = 0; i < node.size(); i++) {
            builtString = nodeToString(node.get(i), spacer, built);
        }
        return builtString;
    }

    /**
     * Does this.
     *
     * @param requestJson
     * @param wildcard
     * @return
     * @throws IOException
     */
    public static List<Map.Entry<String, JsonNode>> getWildcardNodes(JsonNode requestJson, String wildcard) throws IOException {
        List<Map.Entry<String, JsonNode>> allFields = flattenToJsonValueNodeList(requestJson, new LinkedList<>()); 
        List<Map.Entry<String, JsonNode>> matchingFields = Arrays.asList(
                allFields.stream().filter(items -> items.getKey().matches(wildcard))
                .toArray(new IntFunction<Map.Entry<String, JsonNode>[]>() {
            @SuppressWarnings("unchecked")
            @Override
            public Map.Entry<String, JsonNode>[] apply (int size) {
                return (Map.Entry<String, JsonNode>[]) new Map.Entry[size];
            }
        }));
        return matchingFields;
    }
    
    /**
     * Does this.
     *
     * @param requestJson
     * @param allNodes
     * @return
     * @throws IOException
     */
    public static List<Map.Entry<String, JsonNode>> flattenToJsonValueNodeList(JsonNode requestJson, 
            List<Map.Entry<String, JsonNode>> allNodes) throws IOException {
        if (requestJson.isArray()) {
            Iterator<JsonNode> arrayNodes = requestJson.elements();
            while (arrayNodes.hasNext()) {
                JsonNode node = arrayNodes.next();
                flattenToJsonValueNodeList(node, allNodes);
            }
        }
        Iterator<Map.Entry<String, JsonNode>> allFields = requestJson.fields();
        while (allFields.hasNext()) {
            Map.Entry<String, JsonNode> jsonField = allFields.next();
            if (jsonField.getValue().isContainerNode()) {
                flattenToJsonValueNodeList(jsonField.getValue(), allNodes);
               } else {
                   allNodes.add(jsonField);
               }
        }
        return allNodes;
    }
}
