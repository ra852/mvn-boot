package au.com.suncorp.wealth.api.accounts.pact.provider;

import static org.junit.Assert.fail;

import java.net.URL;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import com.atlassian.oai.validator.pact.PactProviderValidationResults;
import com.atlassian.oai.validator.pact.PactProviderValidator;

import au.com.dius.pact.provider.junit.loader.PactFolder;

/**
 * Validate all the consumer pacts against the Wealth Domain API swagger
 *
 * Additional consumers can be added as needed.
 */
/**
 * The class {@code PactToSwaggerValidationTest} does this.
 *
 * @author U205452
 * @since 4Apr.,2018
 * @version 1.0
 */
public class PactToSwaggerValidationTest {
    private static final ClassPathResource SWAGGER_URL = new ClassPathResource("swagger.yaml");
    private static final String MARKETPLACE_PACT_URL =
            "http://pi-pact-broker/pacts/provider/wealth-account-domain-api/consumer/marketplace-portfolio-mobile-experience-api/latest";

   
    /**
     * Does this.
     *
     * @throws Exception
     */
    @Ignore
    @Test
    public void validatePactsAgainstSwagger() throws Exception {
        final PactProviderValidator validator = PactProviderValidator
                .createFor(SWAGGER_URL.getFilename())
                .withConsumer("Marketplace API", new URL(MARKETPLACE_PACT_URL))
                //.withConsumer("Another consumer", new URL("path to consumer pact"))
                .build();

        final PactProviderValidationResults results = validator.validate();
        if (results.hasErrors()) {
            fail(results.getValidationFailureReport());
        } else {
            System.out.println((results.getConsumerResults().toString()));
        }
    }
} 

