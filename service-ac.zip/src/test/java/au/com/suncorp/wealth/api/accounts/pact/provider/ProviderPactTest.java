package au.com.suncorp.wealth.api.accounts.pact.provider;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.boot.SpringApplication;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.context.ConfigurableWebApplicationContext;

import au.com.dius.pact.provider.junit.PactRunner;
import au.com.dius.pact.provider.junit.Provider;
import au.com.dius.pact.provider.junit.State;
import au.com.dius.pact.provider.junit.loader.PactFolder;
import au.com.dius.pact.provider.junit.target.HttpTarget;
import au.com.dius.pact.provider.junit.target.Target;
import au.com.dius.pact.provider.junit.target.TestTarget;
import au.com.suncorp.wealth.api.Application;
import lombok.extern.slf4j.Slf4j;

/**
 * Provider tests for the Marketplace Wealth API
 *
 * Any states used in the Marketplace Wealth API PACT tests will need to be configured in this test. The states are handled by mocking all external
 * dependencies with WireMock and providing stubbed responses
 */
/**
 * The class {@code ProviderPactTest} does this.
 *
 * @author U205452
 * @since 4Apr.,2018
 * @version 1.0
 */
@Slf4j
@RunWith(PactRunner.class)
@PactFolder("src/test/resources/pacts")
@Provider("accounts_provider")
@ActiveProfiles("test")
public class ProviderPactTest {
    @TestTarget
    public final Target target = new HttpTarget("http", "localhost", 10080, "/wealth-accounts-service");

    private static ConfigurableWebApplicationContext applicationPact;

    /**
     * Does this.
     *
     */
    @BeforeClass
    public static void start() {
        System.setProperty("spring.profiles.active", "test");
        applicationPact = (ConfigurableWebApplicationContext) SpringApplication.run(Application.class);
    }

    /**
     * Does this.
     *
     */
    @State("Test GET accounts")
    public void toTestGetAccount() {
    }

}
