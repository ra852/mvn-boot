////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.utils;

import static com.google.common.collect.Lists.newArrayList;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Map;
import java.io.UnsupportedEncodingException;
import java.security.KeyPair;
import java.util.Base64;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;

import au.com.suncorp.wealth.api.accounts.model.AccountReference;
import au.com.suncorp.wealth.api.accounts.model.EntitlementInfo;
import au.com.suncorp.wealth.api.accounts.utils.security.KeyUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Header;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class JwtTestUtils {
    private static final ClassPathResource PUBLIC_KEY = new ClassPathResource("jwt_local.key.pub");
    private static final ClassPathResource PRIVATE_KEY = new ClassPathResource("jwt_local.key");
    private static final Logger APP_LOGGER = LoggerFactory.getLogger(JwtTestUtils.class);
    private static final String SECRET = "why";
    private static final long EXPIRY_PLUS_ONE_DAY = LocalDateTime.now().plusDays(1).atZone(ZoneOffset.systemDefault()).toEpochSecond();
    private static final long EXPIRY_PLUS_ONE_YEAR = LocalDateTime.now().plusYears(1).atZone(ZoneOffset.systemDefault()).toEpochSecond();
    private static final String BRAND_SUNCORP = "Suncorp";
    private static final String PRODUCT_TYPE = "Super";
    private static final String SYSTEM_ID_SNT = "SNT";
    private static final String PRODUCT_NUMBER = "40000028";
    private static ObjectMapper mapper = new ObjectMapper();
    

    private static KeyPair keyPair;
    
    static {
        try {
            keyPair = new KeyPair(KeyUtil.getPublicKeyFromFile(PUBLIC_KEY.getFile()), KeyUtil.getPrivateKeyFromFile(PRIVATE_KEY.getFile()));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public JwtTestUtils() {
    }

    public static String generateValidStubToken() throws Exception {
        EntitlementInfo entitlementInfo = createDefaultEntitlementInfo();
        AccountReference accountRef = createDefaultAccountReference();
        accountRef.setProductSystemPartyId("1000");
        entitlementInfo.setAccountRefs(Lists.newArrayList(accountRef));
        return generateToken(getHeader(), mapper.writeValueAsString(entitlementInfo));
    }

    private static EntitlementInfo createDefaultEntitlementInfo() {
        return createDefaultEntitlementInfo(EXPIRY_PLUS_ONE_DAY);
    }

    private static EntitlementInfo createDefaultEntitlementInfo(long expiryPlusOneDay) {
        EntitlementInfo entitlementInfo;

        entitlementInfo = new EntitlementInfo();
        entitlementInfo.setIss("suncorp_identity");
        entitlementInfo.setTyp("customer_entitlements");
        entitlementInfo.setExp(expiryPlusOneDay);
        entitlementInfo.setSub("97312464-5ff0-4e10-8482-8141ba4328bd");
        entitlementInfo.setDataScid("12345678");
        entitlementInfo.setDataEmpid("u123456");
        entitlementInfo.setAccountRefs(Lists.newArrayList(createDefaultAccountReference()));
        return entitlementInfo;
    }

    private static AccountReference createDefaultAccountReference() {
        return new AccountReference(BRAND_SUNCORP, PRODUCT_TYPE, SYSTEM_ID_SNT, "100009656",PRODUCT_NUMBER);
    }

    public String generateValidToken() throws Exception {
        return generateValidToken("100009656");
    }

 

    public static String generateValidTokenWithoutASLPartyReference() throws Exception {
        EntitlementInfo entitlementInfo = createDefaultEntitlementInfo();
        AccountReference accountRef = createDefaultAccountReference();
        accountRef.setProductSystemId("SNT");
        entitlementInfo.setAccountRefs(Lists.newArrayList(accountRef));
        return generateToken(getHeader(), mapper.writeValueAsString(entitlementInfo));
    }

    public static String generateValidTokenWithEmptyPartyReference() throws Exception {
        EntitlementInfo entitlementInfo = createDefaultEntitlementInfo();
        AccountReference emptyAccountRef = createDefaultAccountReference();
        entitlementInfo.setAccountRefs(Lists.newArrayList(emptyAccountRef));
        return generateToken(getHeader(), mapper.writeValueAsString(entitlementInfo));
    }
    public static String generateTokenWithNoPartyReference() throws Exception {
        EntitlementInfo entitlementInfo = createDefaultEntitlementInfo();
        entitlementInfo.setAccountRefs(null);
        return generateToken(getHeader(), mapper.writeValueAsString(entitlementInfo));
    }

    public static String generateValidTokenWithoutPartyReference() throws Exception {
        EntitlementInfo entitlementInfo = createDefaultEntitlementInfo();
        entitlementInfo.setAccountRefs(null);
        return generateToken(getHeader(), mapper.writeValueAsString(entitlementInfo));
    }

    public static String generateValidToken(String partyNumber) throws Exception {
        return generateValidToken(newArrayList(partyNumber), createDefaultEntitlementInfo());
    }

    public static String generateValidToken(ArrayList<String> partyNumberList) throws Exception {
        return generateValidToken(partyNumberList, createDefaultEntitlementInfo());
    }
    private static String generateValidToken(ArrayList<String> partyNumberList, EntitlementInfo entitlementInfo) throws Exception {
        ArrayList<AccountReference> accountReferenceList = new ArrayList<>();

        for (String partyNumber : partyNumberList) {
            accountReferenceList.add(createAccountReference(partyNumber));
        }
        entitlementInfo.setAccountRefs(accountReferenceList);

        return generateToken(getHeader(), mapper.writeValueAsString(entitlementInfo));
    }

    private static AccountReference createAccountReference(String partyNumber) {
        AccountReference accountRef = new AccountReference(BRAND_SUNCORP, PRODUCT_TYPE, SYSTEM_ID_SNT, partyNumber,PRODUCT_NUMBER);
        return accountRef;
    }
    public static Claims tokenToClaim(String token) {
        return Jwts.parser().setSigningKey(keyPair.getPublic()).parseClaimsJws(token).getBody();
    }
    
    @Test
    public void shouldGenerateValidTokenWithOneYearValidity() throws Exception {
        // Given
        EntitlementInfo entitlementInfo = createDefaultEntitlementInfo(EXPIRY_PLUS_ONE_YEAR);
        String validPartyNumber = "100009656";

        // Get the bytes of the public and private keys
        byte[] privateKeyBytes = keyPair.getPrivate().getEncoded();
        byte[] publicKeyBytes = keyPair.getPublic().getEncoded();

        System.out.println("Private Key : " + Base64.getEncoder().encodeToString(privateKeyBytes));
        System.out.println("Public Key : " + Base64.getEncoder().encodeToString(publicKeyBytes));

        // When
        String validStubToken = generateValidStubToken();
        String validToken = generateValidToken(Lists.newArrayList(validPartyNumber), entitlementInfo);

        // Then
        System.out.println("Valid Stub Token with party ref id 1000: " + validStubToken);
        System.out.println("Valid Stub Token with party ref id " + validPartyNumber + ": " + validToken);

        Jwts.parser().setSigningKey(keyPair.getPublic()).parseClaimsJws(validToken);

    }
    private static String generateToken(Header header, String payload) throws UnsupportedEncodingException {
        @SuppressWarnings("unchecked")
        Map<String, Object> headerMap = (Map<String, Object>) header;

        return Jwts.builder()
                .setHeader(headerMap)
                .setPayload(payload)
                .signWith(SignatureAlgorithm.RS256, keyPair.getPrivate())
                .compact();
    }

 
    private static Header getHeader() {
        Header header = Jwts.header();
        header.setType("JWT");
        return header;
    }

}   
