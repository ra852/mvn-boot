////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2018, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package au.com.suncorp.wealth.api.accounts.utils;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.springframework.util.StreamUtils.copyToString;

import java.io.IOException;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Map;

import org.assertj.core.util.Lists;
import org.hamcrest.MatcherAssert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;

import com.auth0.jwt.algorithms.Algorithm;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;

import au.com.suncorp.api.identity.properties.IdentityProperties;
import au.com.suncorp.api.identity.utils.RSAKeyUtils;
import au.com.suncorp.api.identity.verifier.IssuerAwareSignatureVerifier;
import au.com.suncorp.wealth.api.accounts.model.AccountReference;
import au.com.suncorp.wealth.api.accounts.model.EntitlementInfo;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Header;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

/**
 * The class {@code RSAKeyUtilsTest} does this.
 *
 * @author u201468
 * @since 5Apr.,2018
 * @version 1.0
 */
@Slf4j
public class RSAKeyUtilsTest {

    private IssuerAwareSignatureVerifier verifier;
    private Algorithm signingAlgorithm;
    private static final long EXPIRY_PLUS_ONE_DAY = LocalDateTime.now().plusDays(1).atZone(ZoneOffset.systemDefault()).toEpochSecond();
    private static final String BRAND_SUNCORP = "Suncorp";
    private static final String PRODUCT_TYPE = "Super";
    private static final String SYSTEM_ID_SNT = "SNT";
    private static final String PRODUCT_NUMBER = "40000028";
    private static ObjectMapper mapper = new ObjectMapper();

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Before
    public void init() {
        IdentityProperties properties = IdentityProperties.builder()
            .verificationKeys(ImmutableMap.of(
                "api-nonprod.exttest.lab", RSAKeyUtils.parseX509PublicKey(getAxwayPublicKeyAsString()),
                "api-testing", RSAKeyUtils.parseX509PublicKey(getXApiPublicKeyAsString())
            ))
            .build();
        //verifier = new IssuerAwareSignatureVerifier();
        signingAlgorithm = Algorithm.RSA256(null, RSAKeyUtils.parsePKCS8PrivateKey(getXApiPrivateKeyAsString()));
    }

    private EntitlementInfo createDefaultEntitlementInfo(long expiryPlusOneDay) {
        EntitlementInfo entitlementInfo = new EntitlementInfo();
        entitlementInfo.setIss("api-nonprod.exttest.lab");
        entitlementInfo.setTyp("customer_entitlements");
        entitlementInfo.setExp(expiryPlusOneDay);
        entitlementInfo.setSub("2cb0cd89-b13a-4fe2-9c01-d58d8a49bbdf");
        entitlementInfo.setSubType("user");
        entitlementInfo.setDataScid("12345678");
        entitlementInfo.setDataEmpid("u123456");
        return entitlementInfo;
    }
    
    private String generateValidToken(ArrayList<String> partyNumberList, EntitlementInfo entitlementInfo) throws Exception {
        ArrayList<AccountReference> accountReferenceList = new ArrayList<>();

        for (String partyNumber : partyNumberList) {
            accountReferenceList.add(createAccountReference(partyNumber));
        }
        entitlementInfo.setAccountRefs(accountReferenceList);

        return generateToken(getHeader(), mapper.writeValueAsString(entitlementInfo));
    }
    
    private AccountReference createAccountReference(String partyNumber) {
        AccountReference accountRef = new AccountReference(BRAND_SUNCORP, PRODUCT_TYPE, SYSTEM_ID_SNT, partyNumber,PRODUCT_NUMBER);
        return accountRef;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private String generateToken(Header header, String payload) {
        Map<String, Object> headerMap = (Map<String, Object>) header;
        return Jwts.builder()
                .setHeader(headerMap)
                .setPayload(payload)
                .signWith(SignatureAlgorithm.RS256, RSAKeyUtils.parsePKCS8PrivateKey(getXApiPrivateKeyAsString()))
                .compact();
    }

    @SuppressWarnings("rawtypes")
    private Header getHeader() {
        Header header = Jwts.header();
        header.setType("JWT");
        return header;
    }
    
    @Test
    @Ignore
    public void parseX509PublicKeyReturnsNullForNullString() {
        MatcherAssert.assertThat(RSAKeyUtils.parseX509PublicKey(null), nullValue());
    }

    @Test
    @Ignore
    public void parseX509PublicKeyReturnsExceptionWithInvalidKey() {
        expectedException.expect(IllegalArgumentException.class);
        RSAKeyUtils.parseX509PublicKey("testing");
    }

    @Test
    @Ignore
    public void parsePKCS8PrivateKeyReturnsNullForNullString() {
        MatcherAssert.assertThat(RSAKeyUtils.parsePKCS8PrivateKey(null), nullValue());
    }

    @Test
    @Ignore
    public void parsePKCS8PrivateKeyReturnsExceptionWithInvalidKey() {
        expectedException.expect(IllegalArgumentException.class);
        RSAKeyUtils.parsePKCS8PrivateKey("testing");
    }

    @Test
    @Ignore
    public void verifyExpiredSTSSignedKey() {
        String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhcGktbm9ucHJvZC5leHR0ZXN0LmxhYiIsInR5cCI6ImN1c3RvbWVyX2VudGl0bGVtZW50cyIsImV4cCI6MTUyMjIxMDczOCwic3ViIjoiOTczMTI0NjQtNWZmMC00ZTEwLTg0ODItODE0MWJhNDMyOGJkIiwiZGF0YS5zY2lkIjoiMTIzNDU2NzgiLCJkYXRhLmVtcGlkIjoidTEyMzQ1NiIsImRhdGEucGFydHlSZWZzIjpbeyJicmFuZCI6IlN1bmNvcnAiLCJwcm9kdWN0VHlwZSI6IlN1cGVyIiwicHJvZHVjdFN5c3RlbUlkIjoiU05UIiwicHJvZHVjdFN5c3RlbVBhcnR5SWQiOiIxMDAwIiwicHJvZHVjdE51bWJlciI6IjQwMDAwMDI4In1dfQ.6LhNXv8XCdfUfpkJ-HNv78RHmoufOyMvyUV7WWjIAoI";

        expectedException.expect(ExpiredJwtException.class);
        expectedException.expectMessage("JWT expired at 2018-11-24");
        JwtHelper.decodeAndVerify(token, verifier);
    }

    @Test
    @Ignore
    public void createTokenAndVerifyIt() {
        EntitlementInfo entitlementInfo = createDefaultEntitlementInfo(EXPIRY_PLUS_ONE_DAY);
        String validPartyNumber = "100009656";
        
        String token = null;
        try {
            token = generateValidToken(Lists.newArrayList(validPartyNumber), entitlementInfo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(token);
        Jwt jwt = JwtHelper.decodeAndVerify(token, verifier);
        assertThat(jwt, notNullValue());
    }

    @Test
    @Ignore
    public void parseMissingX509PublicKey() {
        expectedException.expect(IOException.class);
        RSAKeyUtils.parseX509PublicKeyFromResource(new ClassPathResource("/missing.pem"));
    }

    @Test
    @Ignore
    public void parseMissingPKCS8PrivateKey() {
        expectedException.expect(IOException.class);
        RSAKeyUtils.parsePKCS8PrivateKeyFromResource(new ClassPathResource("/missing.p12"));
    }

    public static String getAxwayPublicKeyAsString() {
        return getClasspathResource("/keys/api-nonprod.exttest.lab.pem");
    }

    public static String getXApiPublicKeyAsString() {
        return getClasspathResource("/public_key.pem");
    }

    public static String getXApiPrivateKeyAsString() {
        return getClasspathResource("/private_key.p12");
    }

    @SneakyThrows
    private static String getClasspathResource(String resourceName) {
    	String str= null;
        try {
        	str = copyToString(new ClassPathResource(resourceName).getInputStream(), Charset.defaultCharset());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return str;
    }

}
