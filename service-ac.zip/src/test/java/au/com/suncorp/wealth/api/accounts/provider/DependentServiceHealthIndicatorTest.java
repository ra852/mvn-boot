////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package au.com.suncorp.wealth.api.accounts.provider;

import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.MockitoAnnotations.initMocks;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.boot.actuate.health.Health;

import au.com.suncorp.wealth.api.common.healthcheck.HealthCheckException;
import au.com.suncorp.wealth.api.common.healthcheck.checker.SpringBootHealthChecker;
import au.com.suncorp.wealth.api.common.healthcheck.provider.SingleEnvironmentServiceProviderConfiguration;

public class DependentServiceHealthIndicatorTest {
    public static final String HEALTH_ENDPOINT = "http://health";
    private DependentServiceHealthIndicator dependentServiceHealthIndicator;

    @Mock
    private SingleEnvironmentServiceProviderConfiguration providerConfiguration;
    @Mock
    private SpringBootHealthChecker mockSpringBootHealthChecker;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        dependentServiceHealthIndicator = new DependentServiceHealthIndicator(providerConfiguration,
                "dependentServiceHealthCheck", mockSpringBootHealthChecker);
    }

    @Test
    public void shouldReturnHealthStatusUpIfTheServiceIsUp() throws HealthCheckException {
        // given
        given(providerConfiguration.getHealthEndpoint()).willReturn(HEALTH_ENDPOINT);
        given(mockSpringBootHealthChecker.check(any(String.class))).willReturn(Health.up().build());

        // when
        dependentServiceHealthIndicator.doCheck();

        // then
        verify(mockSpringBootHealthChecker, times(1)).check(HEALTH_ENDPOINT);
    }
}