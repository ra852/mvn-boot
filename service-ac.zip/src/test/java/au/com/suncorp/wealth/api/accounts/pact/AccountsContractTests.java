package au.com.suncorp.wealth.api.accounts.pact;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////


import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Rule;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import au.com.suncorp.wealth.api.accounts.constant.Constants;
import au.com.suncorp.wealth.api.common.constant.CommonConstants;

/**
 * The class {@code AccountsContractTests} does this.
 *
 * @author U205452
 * @since 4Apr.,2018
 * @version 1.0
 */
public class AccountsContractTests {


    private static Logger LOG = LoggerFactory.getLogger(AccountsContractTests.class);

    @Rule
    public PactProviderRuleMk2 mockProvider = new PactProviderRuleMk2("accounts_provider","localhost" ,8080, this);

    private static String AUTH_TOKEN;

    static {
        try {
            AUTH_TOKEN = "tt";
        } catch (Exception e) {
            LOG.error("Unable to create AUTH_TOKEN", e);
        }
    }


    /**
     * Does this.
     *
     * @param builder
     * @return
     */
    @Pact(consumer = "accounts_consumer")
    public RequestResponsePact createPact(PactDslWithProvider builder) {
        Map<String, String> requestHeaders = new HashMap<>();
        requestHeaders.put(HttpHeaders.ACCEPT, CommonConstants.APPLICATION_JSON_API_VALUE);
        requestHeaders.put(HttpHeaders.AUTHORIZATION, AUTH_TOKEN);
        requestHeaders.put(Constants.ENTITLEMENT_ID_FIELD_NAME, AUTH_TOKEN);
        requestHeaders.put(Constants.REQUEST_ID_FIELD_NAME, "Authorization");
        requestHeaders.put(Constants.VERSION_ID_FIELD_NAME, "1.0");
        

        Map<String, String> responseHeaders = new HashMap<>();
        responseHeaders.put(HttpHeaders.CONTENT_TYPE, "application/vnd.api+json;charset=UTF-8");

        //@formatter:off
        RequestResponsePact pact = builder
                .given("Test GET accounts")
                .uponReceiving("GET /accounts/{accountNumber} ")
                    .path("/wealth/v1/accounts/900000001")
                    .method("GET")
                    .headers(requestHeaders)
                .willRespondWith()
                    .status(HttpStatus.OK.value())
                    .headers(responseHeaders)
                    .body(expectedBodyForAccounts())
                    .toPact();
        //@formatter:on

        return pact;
    }
   
    /**
     * Does this.
     *
     * @throws URISyntaxException
     * @throws IOException
     */
    @Test
    @PactVerification()
    public void given_GetPartiesRequest_shouldReturn200WithHeaderAndBody() throws URISyntaxException, IOException {

        //given
        HttpEntity<String> reqEntity = new HttpEntity<>("parameters", commonHeaderForRequest());

        //when
        ResponseEntity<String> responseForAccounts
                = new RestTemplate().exchange(mockProvider.getUrl() + "/wealth/v1/accounts/900000001", HttpMethod.GET, reqEntity, String.class);

        //then
        assertThat(responseForAccounts.getStatusCode().value()).isEqualTo(200);
        assertThat(responseForAccounts.getHeaders().get(HttpHeaders.CONTENT_TYPE).contains("application/vnd.api+json;charset=UTF-8")).isTrue();
        assertThat(responseForAccounts.getBody()).isNotBlank();

    }

    /**
     * Does this.
     *
     * @return
     */
    private HttpHeaders commonHeaderForRequest() {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.ACCEPT, CommonConstants.APPLICATION_JSON_API_VALUE);
        headers.add(HttpHeaders.AUTHORIZATION, AUTH_TOKEN);
        headers.add(Constants.ENTITLEMENT_ID_FIELD_NAME, AUTH_TOKEN);
        headers.add(Constants.REQUEST_ID_FIELD_NAME, "Authorization");
        headers.add(Constants.VERSION_ID_FIELD_NAME, "1.0");
        return headers;
    }

    /**
     * This method will return the expected response body for /api/wealth
     *
     * @return Json body for validation in pact
     */
    private PactDslJsonBody expectedBodyForAccounts() {
        PactDslJsonBody response = new PactDslJsonBody();

        //@formatter:off
        response.object("data")
                    .stringValue("type", "accounts")
                    .stringMatcher("id", "^[0-9 ]{0,30}$", "900000001")
                    .object("attributes")
                        .stringMatcher("accountStatus", "^[a-zA-Z ]{0,99}$", "Active")
                        .date("startDate","2016-06-17")
                        .stringMatcher("bpayCustomerRefNumber", "^[0-9]{0,30}$","9000000019")
                        .object("accountBalance")
                            .decimalType("amount", (double) 0)
                            .stringMatcher("currency", "^[a-zA-Z]{0,30}$","AUD")
                        .closeObject()
                        .minArrayLike("billerCodes", 5)
                            .stringType("billerCode")
                            .stringType("bpayContributionType")
                            .closeObject().closeArray()
                    .closeObject()
                    .object("relationships")
                        .object("products")
                            .object("data")
                                .stringValue("type", "products")
                                .stringMatcher("id", "^[0-9 ]{0,30}$", "40000026")
                            .closeObject()
                            .object("links")
                                 .stringValue("related", "http://localhost:10080/wealth-accounts-service/wealth/v1/accounts/900000001/products")
                            .closeObject()
                        .closeObject()
                        .object("owners")
                            .object("data")
                                .stringValue("type", "clients")
                                .stringMatcher("id", "^[0-9 ]{0,30}$", "100009656")
                            .closeObject()
                        .closeObject()
                   .closeObject()
                   /*.minArrayLike("included", 1)
                       .stringValue("type", "products")
                       .stringMatcher("id", "^[a-zA-Z0-9 ]{0,30}$", "40000026")
                              .object("attributes")
                              .stringMatcher("name", "^[a-zA-Z ]{0,99}$", "Suncorp Brighter Super")
                              .stringMatcher("shortName", "^[a-zA-Z ]{0,99}$", "Brighter Super")
                              .stringMatcher("brand", "^[a-zA-Z ]{0,99}$", "Suncorp")
                              .stringMatcher("productFamilyName", "^[a-zA-Z ]{0,99}$", "Brighter Super")
                              .stringMatcher("productTypeCode", "^[a-zA-Z ]{0,99}$", "SCSP")
                              .stringMatcher("abn", "^[a-zA-Z0-9 ]{0,30}$", "98350952022")
                              .stringMatcher("usi", "^[a-zA-Z0-9 ]{0,30}$", "98350952022123")
                              .or("email", "super@suncorp.com.au", PM.stringMatcher(REGEX_EMAIL), PM.nullValue())
                              .closeObject()
                 .closeArray()*/
               .closeObject();
        
        //@formatter:on

        return response;
    }
}
