package au.com.suncorp.wealth.api.accounts.actuator;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

import java.io.InputStream;
import java.net.URL;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import au.com.suncorp.wealth.api.accounts.constant.Constants;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = RANDOM_PORT)
@TestPropertySource(properties = { "management.security.enabled=false" })
@ActiveProfiles({ Constants.SPRING_PROFILE_TEST })
public class ActuatorEndpointsWithManagementSecurityDisabledTest {
    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Value("${server.context-path}")
    private String contextPath;

    @Before
    public void setUp() {
    }

    @Test
    public void testInfoWithoutCredential() {
        //when
        ResponseEntity<String> response = testRestTemplate.getForEntity("/info", String.class);

        //then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).contains("\"env\":\"TEST\"");
    }

    @Test
    public void testHealthWithoutCredential() {
        //when
        ResponseEntity<String> response = testRestTemplate.getForEntity("/health", String.class);

        //then
        assertThat(response.getStatusCode()).isIn(HttpStatus.OK, HttpStatus.SERVICE_UNAVAILABLE);
        assertThat(response.getBody()).contains("status");
        assertThat(response.getBody()).contains("diskSpace");
        assertThat(response.getBody()).contains("hystrix");
        //assertThat(response.getBody()).contains("HealthCheck");
    }

    @Test
    public void testEnvWithoutCredential() {
        //when
        ResponseEntity<String> response = testRestTemplate.getForEntity("/env", String.class);

        //then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).contains("config/application-test.yml");
    }

    @Test
    public void testMetricsWithoutCredential() {
        //when
        ResponseEntity<String> response = testRestTemplate.getForEntity("/metrics", String.class);

        //then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).contains("mem");
        assertThat(response.getBody()).contains("uptime");
    }

    @Test
    public void testLogFileWithoutCredential() {
        //when
        ResponseEntity<String> response = testRestTemplate.getForEntity("/logfile", String.class);

        //then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).contains("Tomcat started");
    }

    @Test
    public void testSwaggerUIWithoutCredential() {
        //when
        ResponseEntity<String> response = testRestTemplate.getForEntity("/swagger-ui.html", String.class);

        //then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    public void shouldAccessHystrixStreamWithoutCredential() throws Exception {
        //given
        String url = "http://localhost:" + port + contextPath;
        ResponseEntity<String> response = new TestRestTemplate().getForEntity(url + "/health", String.class);

        //when
        URL hystrixUrl = new URL(url + "/hystrix.stream");
        InputStream in = hystrixUrl.openStream();
        byte[] buffer = new byte[256];
        in.read(buffer);
        String contents = new String(buffer);
        in.close();

        //then
        assertThat(contents.contains("data") || contents.contains("ping")).isTrue();
    }
}
