SSP Wealth Account Service
===================================
An API that represents a Suncorp Wealth customer details.

This broker service will:
1. This is wealth account service accept request from marketplace and it responds back.

Local build
-----------
`$ mvn clean package` OR `$ mvn clean checkstyle:checkstyle package` (Build with check style reports) 

How to run it locally
---------------------
`$ mvn spring-boot:run`
Check if everything is fine by invoking from browser: `http://localhost:10080/ssp-wealth-account-service/info`

Include the following in the HTTP request headers:<br/>
- Accept: application/vnd.api+json<br/>
- X-Correlation-Id: CORR1234567<br/>
- X-Client-Id: CLIENTID<br/>
- X-Client-Version: 1.0.0<br/>

Note: server port is configured using the `server.port` property in the `config/application-local.yml` file

Useful endpoints
----------------
* Build info: `/info`
* Healthcheck: `/health`
* Environment: `/env`
* Metrics: `/metrics`


API documentation
-----------------
* Static HTML: `/index.html`
* Swagger UI: `/swagger-ui.html`
* Swagger JSON Schema: `/v2/api-docs`
