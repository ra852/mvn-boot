CURRENT_DIRECTORY=`pwd`
SHARED_PLAYBOOKS=$CURRENT_DIRECTORY/../../deployment-automation

export ANSIBLE_CONFIG=$SHARED_PLAYBOOKS/ansible.cfg
export ANSIBLE_LIBRARY=$SHARED_PLAYBOOKS/library:$ANSIBLE_LIBRARY

# configure script requires the following extra-vars:
# hostname: The name (or IP) of the host to configure
# shared_playbooks: The location of all shared playbooks.
# 
# policy-finder/configure-common.yml requires the following variables:
# env_config_file: File that contains environment specific configuration for this app, eg. domain, instance type etc.
# build_pipeline_number: The version of the app to deploy. This actually substitutes into the URLs in the env_config_file

source /apps/ansible-1.7.2/hacking/env-setup

ansible-playbook "configure-instance.yml" --extra-vars="hostname=$1 branch_name=$2 build_pipeline_number=$3 env_config_file='$CURRENT_DIRECTORY/env/$4.yml' version=$5 shared_playbooks='$SHARED_PLAYBOOKS'" -i "$SHARED_PLAYBOOKS/hosts" "${@:6}"

