CURRENT_DIRECTORY=`pwd`
SHARED_PLAYBOOKS=$CURRENT_DIRECTORY/../../deployment-automation

export ANSIBLE_CONFIG=$SHARED_PLAYBOOKS/ansible.cfg
export ANSIBLE_LIBRARY=$SHARED_PLAYBOOKS/library:$ANSIBLE_LIBRARY

source /apps/ansible-1.7.2/hacking/env-setup

# NOTE: The first parameter for the playbook - 'branch_name' -, is truncated to the last path element using an external Linux command.
#       The operation was inlined to make the script more self-contained. Similar wrapper scripts have their parameters striped by the
#       caller (either through the Jenkinsfile or Gradle).
#       e.g.: /blah/blah/feature/SSP-1111-build-infrastructure
ansible-playbook create-instance.yml --extra-vars="branch_name=`basename $1` build_pipeline_number=$2 env_config_file='$CURRENT_DIRECTORY/env/$3.yml' version=$4 shared_playbooks='$SHARED_PLAYBOOKS'" -i "$SHARED_PLAYBOOKS/hosts" "${@:5}"
