set -e

CURRENT_DIRECTORY=`pwd`
SHARED_PLAYBOOKS=$CURRENT_DIRECTORY/../../deployment-automation

# configure script requires the following extra-vars:
# hostname: The name (or IP) of the host to configure
# shared_playbooks: The location of all shared playbooks.
#
# policy-finder/configure-common.yml requires the following variables:
# env_config_file: File that contains environment specific configuration for this app, eg. domain, instance type etc.
# build_pipeline_number: The version of the app to deploy. This actually substitutes into the URLs in the env_config_file

source /apps/ansible-1.7.2/hacking/env-setup

export ANSIBLE_CONFIG=$SHARED_PLAYBOOKS/ansible.cfg
export ANSIBLE_LIBRARY=$SHARED_PLAYBOOKS/library:$ANSIBLE_LIBRARY

# environment variable is required:
# $BLUE_GREEN_USERNAME
# $BLUE_GREEN_PASSWORD

ansible-playbook "./blue-green-deployment/blue-green-deployment-switch.yml" --extra-vars="host_list=$1 branch_name=$2 build_pipeline_number=$3 env_config_file='$CURRENT_DIRECTORY/env/$4.yml' shared_playbooks='$SHARED_PLAYBOOKS' version_number=$5" -i "$SHARED_PLAYBOOKS/hosts" "${@:6}"
